#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{

	public class BarsRequestTestIndicator : Indicator
	{
		//dOES BARS REQUEST OF THE CHART ITS APPLIED TO, SAME BARS PERIOD, SESSION TEMPLATE, ETC.
		
		
		private NinjaTrader.Data.BarsRequest barsReq;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BarsRequestTestIndicator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Realtime)
			{
				if (CurrentBar < 10)
					return;

/////TWO OPTIONS
		//Does custom range.			
			//	barsReq = new NinjaTrader.Data.BarsRequest(Instrument.GetInstrument(Instrument.FullName.ToString()),DateTime.Now.AddDays(-5),DateTime.Now.AddDays(-1) )
		//Does BR to today.
			barsReq = new NinjaTrader.Data.BarsRequest(Instrument.GetInstrument(Instrument.FullName.ToString()), 10)

				{

		
					MergePolicy = Instrument.MasterInstrument.MergePolicy,		
					BarsPeriod = new BarsPeriod() { BarsPeriodType = Bars.BarsPeriod.BarsPeriodType, Value = Bars.BarsPeriod.Value},

					TradingHours	= TradingHours.Get(Bars.TradingHours.Name)
				};
				
				//barsReq.Update += BROnBarUpdate;

				double[] closeValue = new double[10];

				barsReq.Request(new Action<NinjaTrader.Data.BarsRequest, ErrorCode, string>((bars, errorCode, errorMessage) =>
				{
					if (errorCode != ErrorCode.NoError)
					{
						// Handle any errors in requesting bars here
						NinjaTrader.Code.Output.Process(string.Format("Error on requesting bars: {0}, {1}",
														errorCode, errorMessage), PrintTo.OutputTab1);
						return;
					}

					// Output the bars we requested. Note: The last returned bar may be a currently in-progress bar
					//for (int i = bars.Bars.Count - 1; i >= 0; i--)
					for (int i = 0; i < 10; i++)
					{
						// Output the bars
						Print(string.Format("Time: {0} | {1} | Open: {2}, High: {3}, Low: {4}, Close: {5}, Volume: {6}",
								bars.Bars.GetTime(i),
								bars.Bars.Instrument.FullName,
								bars.Bars.GetOpen(i),
								bars.Bars.GetHigh(i),
								bars.Bars.GetLow(i),
								bars.Bars.GetClose(i),
								bars.Bars.GetVolume(i)
							));

						closeValue[i] = bars.Bars.GetClose(i);
					}

					// If requesting real-time bars, but there are currently no connections
					lock (Connection.Connections)
						if (Connection.Connections.FirstOrDefault() == null)
							NinjaTrader.Code.Output.Process("No connection for real-time data", PrintTo.OutputTab1);
				}));
			}
			else if (State == State.Terminated)
			{
				if (barsReq != null)
				{
					barsReq.Update -= BROnBarUpdate;
       				barsReq.Dispose();
				}
			}
		}
		
		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		private void BROnBarUpdate(object sender, BarsUpdateEventArgs e)
		{
			
		}
		
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BarsRequestTestIndicator[] cacheBarsRequestTestIndicator;
		public BarsRequestTestIndicator BarsRequestTestIndicator()
		{
			return BarsRequestTestIndicator(Input);
		}

		public BarsRequestTestIndicator BarsRequestTestIndicator(ISeries<double> input)
		{
			if (cacheBarsRequestTestIndicator != null)
				for (int idx = 0; idx < cacheBarsRequestTestIndicator.Length; idx++)
					if (cacheBarsRequestTestIndicator[idx] != null &&  cacheBarsRequestTestIndicator[idx].EqualsInput(input))
						return cacheBarsRequestTestIndicator[idx];
			return CacheIndicator<BarsRequestTestIndicator>(new BarsRequestTestIndicator(), input, ref cacheBarsRequestTestIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BarsRequestTestIndicator BarsRequestTestIndicator()
		{
			return indicator.BarsRequestTestIndicator(Input);
		}

		public Indicators.BarsRequestTestIndicator BarsRequestTestIndicator(ISeries<double> input )
		{
			return indicator.BarsRequestTestIndicator(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BarsRequestTestIndicator BarsRequestTestIndicator()
		{
			return indicator.BarsRequestTestIndicator(Input);
		}

		public Indicators.BarsRequestTestIndicator BarsRequestTestIndicator(ISeries<double> input )
		{
			return indicator.BarsRequestTestIndicator(input);
		}
	}
}

#endregion
