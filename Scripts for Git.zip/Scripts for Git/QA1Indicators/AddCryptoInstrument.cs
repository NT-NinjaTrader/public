#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.QA1
{
	public class AddCryptoInstrument : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AddCryptoInstrument";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
			else if(State == State.DataLoaded)
			{
			
				string SymWithNoExpiration = "DOGDOG";

		

						

					MasterInstrument masterInstrument;
					
					TradingHours th =   NinjaTrader.Data.TradingHours.Get("Default 24 x 7");

					string[] providerNames = new string[Enum.GetValues(typeof(Provider)).Length - 1];       // don't need .Unknown
					for (int i = 0; i < providerNames.Length; i++)
						providerNames[i] = SymWithNoExpiration;

					masterInstrument = new MasterInstrument
					{
						Currency = Currency.UsDollar,
						Description = SymWithNoExpiration,
						Exchanges = { Exchange.Gdax },
						InstrumentType = InstrumentType.CryptoCurrency,
						Name = SymWithNoExpiration,
						ProviderNames = providerNames,
						PointValue = 50,
						TickSize =1,

					
						TradingHours = th,
					

						Url = new Uri("http://www.cme.com"),
					};



//					DateTime contractMonth1 = new DateTime(2030, 1, 1);
//					DateTime contractMonth2 = new DateTime(2029, 1, 1);
//					DateTime dateToRollToThatContract1 = new DateTime(2020, 1, 1);
//					DateTime dateToRollToThatContract2 = new DateTime(2028, 1, 1);

			
//					DateTime dateToRollToThatContract = new DateTime(1800, 1, 1);

		
//					masterInstrument.RolloverCollection.Add(new Rollover { ContractMonth = contractMonth1, Offset = Double.NaN, WasEdited = true, Date = dateToRollToThatContract1 });

//					masterInstrument.RolloverCollection.Add(new Rollover { ContractMonth = contractMonth2, Offset = Double.NaN, WasEdited = true, Date = dateToRollToThatContract2 });

					masterInstrument.DbAdd(true);
	
//					new Instrument { Exchange = Exchange.Gdax, Expiry = contractMonth1, MasterInstrument = masterInstrument, OptionRight = OptionRight.Unknown, StrikePrice = 0 }.DbAdd();
//					new Instrument { Exchange = Exchange.Globex, Expiry = contractMonth2, MasterInstrument = masterInstrument, OptionRight = OptionRight.Unknown, StrikePrice = 0 }.DbAdd();
			

					Print("DONE");			
				
						
			}
		
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private QA1.AddCryptoInstrument[] cacheAddCryptoInstrument;
		public QA1.AddCryptoInstrument AddCryptoInstrument()
		{
			return AddCryptoInstrument(Input);
		}

		public QA1.AddCryptoInstrument AddCryptoInstrument(ISeries<double> input)
		{
			if (cacheAddCryptoInstrument != null)
				for (int idx = 0; idx < cacheAddCryptoInstrument.Length; idx++)
					if (cacheAddCryptoInstrument[idx] != null &&  cacheAddCryptoInstrument[idx].EqualsInput(input))
						return cacheAddCryptoInstrument[idx];
			return CacheIndicator<QA1.AddCryptoInstrument>(new QA1.AddCryptoInstrument(), input, ref cacheAddCryptoInstrument);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.QA1.AddCryptoInstrument AddCryptoInstrument()
		{
			return indicator.AddCryptoInstrument(Input);
		}

		public Indicators.QA1.AddCryptoInstrument AddCryptoInstrument(ISeries<double> input )
		{
			return indicator.AddCryptoInstrument(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.QA1.AddCryptoInstrument AddCryptoInstrument()
		{
			return indicator.AddCryptoInstrument(Input);
		}

		public Indicators.QA1.AddCryptoInstrument AddCryptoInstrument(ISeries<double> input )
		{
			return indicator.AddCryptoInstrument(input);
		}
	}
}

#endregion
