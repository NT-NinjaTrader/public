//
// Copyright (C) 2017, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows;
using System.Xml.Serialization;
using System;
#endregion

//This namespace holds strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	
	
	//AP NOTES TO AP
	//I MODIFIED THIS TO MAKE A SIMPLER EXAMPLE ON HOW TO GRAY OUT PROPERTIES WHEN 1 IS SELECTED.
		// i COMBINED METHODS INTO 1
		
	
	//BUT I STILL DON'T UNDERSTAND WHAT TRIGGERS THE CHANGE, WHEN I CLICK READONLY TOGGLE, WHERE IS THE LOGIC WHICH CHANGES IT?
	/////////////////////
	
    // Notes:
    // Helper classes and type converters are defined below the indicator, separated by use case
    // Property definitions are documented as necessary in the Properties region
    // Debugging issues will likely require compiling NS in debug mode and attaching VS to ninjatrader.exe
    // Setting breakpoints to examine values and seeing debug output that NT creates is helpful

    // Apply the TypeConverter attribute using the fully qualified name of your converter
    [TypeConverter("NinjaTrader.NinjaScript.Indicators.MyConverter")]
    public class SampleIndicatorTypeConverterAP : Indicator
    {
	
		
		
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Demonstrating using type converters to customize the Indicator property grid";
                Name = "Sample Indicator TypeConverter";
                IsOverlay = true;

                
                ReadOnlyToggle = false;
             
                ReadOnlyInt = 10;
                ReadOnlyDouble = .25;
           
            }
        }

        protected override void OnBarUpdate()
        {
          Print("ReadOnlyInt"+ReadOnlyInt.ToString());
			 Print("ReadOnlyDouble"+ReadOnlyDouble.ToString());
        }



        #region Use Case #2: Disable/enable properties based on secondary input
        [RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
        [Display(Name = "Toggle read only", Order = 1, GroupName = "Use Case #2")]
        public bool ReadOnlyToggle
        { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Read only int", Order = 2, GroupName = "Use Case #2")]
        public int ReadOnlyInt
        { get; set; }

        [Range(0, double.MaxValue)]
        [Display(Name = "Read only double", Order = 3, GroupName = "Use Case #2")]
        public double ReadOnlyDouble
        { get; set; }

        #endregion

    
    }

    // TypeConvetor/Property Descriptor logic to define how properties behave for each of defined use cases

    #region Use Case #1/#2: Show/hide properties based on secondary input & Disable/enable properties based on secondary input

    // This custom TypeConverter is applied ot the entire indicator object and handles two of our use cases
    // IMPORTANT: Inherit from IndicatorBaseConverter so we get default NinjaTrader property handling logic
    // IMPORTANT: Not doing this will completely break the property grids!
    // If targeting a "Strategy", use the "StrategyBaseConverter" base type instead
    public class MyConverter : IndicatorBaseConverter // or StrategyBaseConverter
    {
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
            // we need the indicator instance which actually exists on the grid
            SampleIndicatorTypeConverterAP indicator = component as SampleIndicatorTypeConverterAP;

            // base.GetProperties ensures we have all the properties (and associated property grid editors)
            // NinjaTrader internal logic determines for a given indicator
            PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
                                                                        ? base.GetProperties(context, component, attrs)
                                                                        : TypeDescriptor.GetProperties(component, attrs);

            if (indicator == null || propertyDescriptorCollection == null)
                return propertyDescriptorCollection;


            // These two values are will be disabled/enabled (grayed out) based on the indicator's "ShowHideToggle" bool value
            // The PropertyDescriptor type does not contain our desired custom behavior, so we must implement that ourselves
            PropertyDescriptor readOnlyInt = propertyDescriptorCollection["ReadOnlyInt"];
            PropertyDescriptor readOnlyDouble = propertyDescriptorCollection["ReadOnlyDouble"];

            // We must first remove the default implentation of the property (which does not yet contain our custom behavior)
            // Otherwise we would have two versions of the same property on the grid which is not desired
            propertyDescriptorCollection.Remove(readOnlyInt);
            propertyDescriptorCollection.Remove(readOnlyDouble);

            // This custom "ReadOnlyDescriptor" property descriptor (defined in the class below) toggles read-only mode based on a property in the indicator
            // So re-assign them from a "PropertyDescriptor" to new "ReadOnlyDescriptor" which handles our custom action
            readOnlyInt = new OneMethod(indicator, readOnlyInt, "Int");
            readOnlyDouble = new OneMethod(indicator, readOnlyDouble, "Double");

            // This re-adds the properties to the grid under their new "ReadOnlyDescriptor" type behavior
            propertyDescriptorCollection.Add(readOnlyInt);
            propertyDescriptorCollection.Add(readOnlyDouble);

            #endregion

            return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        { return true; }
    }

  
	    // This is a custom PropertyDescriptor class which will handle setting our desired properties to read only
    public class OneMethod : PropertyDescriptor
    {
        // Need the instance on the property grid to check the show/hide toggle value
        private SampleIndicatorTypeConverterAP indicatorInstance;

        private PropertyDescriptor property;

		private bool IntNotDouble=false;
        // The base instance constructor helps store the default Name and Attributes (Such as DisplayAttribute.Name, .GroupName, .Order)
        // Otherwise those details would be lost when we converted the PropertyDescriptor to the new custom ReadOnlyDescriptor
        public OneMethod(SampleIndicatorTypeConverterAP indicator, PropertyDescriptor propertyDescriptor, string Type) : base(propertyDescriptor.Name, propertyDescriptor.Attributes.OfType<Attribute>().ToArray())
        {
            indicatorInstance = indicator;
            property = propertyDescriptor;
			
			if(Type == "Int")
				IntNotDouble =true;
        }

        // Stores the current value of the property on the indicator
        public override object GetValue(object component)
        {
            SampleIndicatorTypeConverterAP targetInstance = component as SampleIndicatorTypeConverterAP;
            if (targetInstance == null)
                return null;
            switch (property.Name)
            {
                case "ReadOnlyDouble":
                    return targetInstance.ReadOnlyDouble;
					
				case "ReadOnlyInt":
                    return targetInstance.ReadOnlyInt;
            }
            return null;
        }

        // Updates the current value of the property on the indicator
        public override void SetValue(object component, object value)
        {
            SampleIndicatorTypeConverterAP targetInstance = component as SampleIndicatorTypeConverterAP;
            if (targetInstance == null)
                return;

            switch (property.Name)
            {
                case "ReadOnlyDouble":
                    targetInstance.ReadOnlyDouble = (double)value;
                    break;
					
					   
					
				case "ReadOnlyInt":
                    targetInstance.ReadOnlyInt = (int) value;
                    break;
            }
        }

        // set the PropertyDescriptor to "read only" based on the indicator instance input
        public override bool IsReadOnly
        { get { return indicatorInstance.ReadOnlyToggle; } }

        // IsReadOnly is the relevant interface member we need to use to obtain our desired custom behavior
        // but applying a custom property descriptor requires having to handle a bunch of other operations as well.
        // I.e., the below methods and properties are required to be implemented, otherwise it won't compile.
        public override bool CanResetValue(object component)
        { return true; }

        public override Type ComponentType
        { get { return typeof(SampleIndicatorTypeConverterAP); } }

        public override Type PropertyType
        { 
			get
				
			{ 
				if(IntNotDouble)
					return typeof(int);
					
				else
					return typeof(double);
					
				
			} }
		
        public override void ResetValue(object component)
        { }

        public override bool ShouldSerializeValue(object component)
        { return true; }
    }
}


//	#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SampleIndicatorTypeConverterAP[] cacheSampleIndicatorTypeConverterAP;
		public SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP()
		{
			return SampleIndicatorTypeConverterAP(Input);
		}

		public SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP(ISeries<double> input)
		{
			if (cacheSampleIndicatorTypeConverterAP != null)
				for (int idx = 0; idx < cacheSampleIndicatorTypeConverterAP.Length; idx++)
					if (cacheSampleIndicatorTypeConverterAP[idx] != null &&  cacheSampleIndicatorTypeConverterAP[idx].EqualsInput(input))
						return cacheSampleIndicatorTypeConverterAP[idx];
			return CacheIndicator<SampleIndicatorTypeConverterAP>(new SampleIndicatorTypeConverterAP(), input, ref cacheSampleIndicatorTypeConverterAP);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP()
		{
			return indicator.SampleIndicatorTypeConverterAP(Input);
		}

		public Indicators.SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP(ISeries<double> input )
		{
			return indicator.SampleIndicatorTypeConverterAP(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP()
		{
			return indicator.SampleIndicatorTypeConverterAP(Input);
		}

		public Indicators.SampleIndicatorTypeConverterAP SampleIndicatorTypeConverterAP(ISeries<double> input )
		{
			return indicator.SampleIndicatorTypeConverterAP(input);
		}
	}
}

#endregion
