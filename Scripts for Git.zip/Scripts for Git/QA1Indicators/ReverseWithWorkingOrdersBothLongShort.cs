#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class ReverseWithWorkingOrdersBothLongShort : Strategy
    {
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "ReverseWithWorkingOrdersBothLongShort";
                Calculate = Calculate.OnBarClose;
                TraceOrders = true;
                AllowHistorical = false;
            }
        }

        protected override void OnBarUpdate()
        {
            if (!AllowHistorical && State != State.Realtime)
                return;
            //Print("BarsSince"+BarsSinceEntryExecution().ToString());
            if (Position.MarketPosition == MarketPosition.Flat)
            {
                EnterLong("entry");
                //	Print("Called EnterLong");
                //	Print("BarsSince"+BarsSinceEntryExecution().ToString());
            }
            else if (Position.MarketPosition == MarketPosition.Long && BarsSinceEntryExecution() > 1)
                EnterShort("reversalshort");

        }



        protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, Cbi.MarketPosition marketPosition, string orderId, DateTime time)
        {
            Print(Position.MarketPosition + "___" + execution.Order.Name);


            if ((Position.MarketPosition + "___" + execution.Order.Name).Equals("Long___Close position"))
            {
                Print("------------------------------------------------");
                Print(NinjaTrader.Core.Globals.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                Print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                Print("----------------   ISSUE REPLICATED-------------------" + Instrument.FullName + DateTime.Now.ToString());


                Print(" Close Position execution came after reversalshort, causing PT/SL to not be submitted for reversal order");
                Print("------------------------------------------------");
            }

            if ((Position.MarketPosition + "___" + execution.Order.Name).Equals("Short___Close position"))
            {
                Print("------------------------------------------------");
                Print(NinjaTrader.Core.Globals.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                Print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                Print("----------------   ISSUE REPLICATED-------------------" + Instrument.FullName + DateTime.Now.ToString());


                Print(" Close Position execution came after reversalshort, causing PT/SL to not be submitted for reversal order");
                Print("------------------------------------------------");

            }

            if (execution.Order.Name == "entry")
            {
                ExitLongLimit(0, true, quantity, Position.AveragePrice + 8 * TickSize, "target", "entry");
                ExitLongStopMarket(0, true, quantity, Position.AveragePrice - 8 * TickSize, "stop", "entry");
            }
            else if (execution.Order.Name == "reversalshort")
            {
                ExitShortLimit(0, true, quantity, Position.AveragePrice - 8 * TickSize, "shorttarget", "reversalshort");
                ExitShortStopMarket(0, true, quantity, Position.AveragePrice + 8 * TickSize, "shortstop", "reversalshort");
            }
        }

        //		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
        //		{
        //			if (marketPosition == MarketPosition.Long)
        //			{
        //				ExitLongLimit(0, true, quantity, averagePrice + 30 * TickSize, "target", "entry");
        //				ExitLongStopMarket(0, true, quantity, averagePrice - 30 * TickSize, "stop", "entry");
        //			}

        //			if (marketPosition == MarketPosition.Short)
        //			{
        //				ExitShortLimit(0, true, quantity, averagePrice - 30 * TickSize, "shorttarget", "reversalshort");
        //				ExitShortStopMarket(0, true, quantity, averagePrice + 30 * TickSize, "shortstop", "reversalshort");
        //			}
        //		}

        [NinjaScriptProperty]
        public bool AllowHistorical
        { get; set; }
    }
}
