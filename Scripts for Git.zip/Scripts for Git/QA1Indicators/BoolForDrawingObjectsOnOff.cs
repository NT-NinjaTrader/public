#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BoolForDrawingObjectsOnOff : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BoolForDrawingObjectsOnOff";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
						PlotAll=false;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar<10) return;
			
			if(PlotAll==true)
			Draw.ArrowDown(this, "this"+CurrentBar, true, 0, High[0],Brushes.Red);
		}
		
		
		
			[NinjaScriptProperty]
		[Display(Name="PlotAll", Description="PlotAll", Order=1, GroupName="VisualParameters")]
		public bool PlotAll
		{ get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BoolForDrawingObjectsOnOff[] cacheBoolForDrawingObjectsOnOff;
		public BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(bool plotAll)
		{
			return BoolForDrawingObjectsOnOff(Input, plotAll);
		}

		public BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(ISeries<double> input, bool plotAll)
		{
			if (cacheBoolForDrawingObjectsOnOff != null)
				for (int idx = 0; idx < cacheBoolForDrawingObjectsOnOff.Length; idx++)
					if (cacheBoolForDrawingObjectsOnOff[idx] != null && cacheBoolForDrawingObjectsOnOff[idx].PlotAll == plotAll && cacheBoolForDrawingObjectsOnOff[idx].EqualsInput(input))
						return cacheBoolForDrawingObjectsOnOff[idx];
			return CacheIndicator<BoolForDrawingObjectsOnOff>(new BoolForDrawingObjectsOnOff(){ PlotAll = plotAll }, input, ref cacheBoolForDrawingObjectsOnOff);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(bool plotAll)
		{
			return indicator.BoolForDrawingObjectsOnOff(Input, plotAll);
		}

		public Indicators.BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(ISeries<double> input , bool plotAll)
		{
			return indicator.BoolForDrawingObjectsOnOff(input, plotAll);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(bool plotAll)
		{
			return indicator.BoolForDrawingObjectsOnOff(Input, plotAll);
		}

		public Indicators.BoolForDrawingObjectsOnOff BoolForDrawingObjectsOnOff(ISeries<double> input , bool plotAll)
		{
			return indicator.BoolForDrawingObjectsOnOff(input, plotAll);
		}
	}
}

#endregion
