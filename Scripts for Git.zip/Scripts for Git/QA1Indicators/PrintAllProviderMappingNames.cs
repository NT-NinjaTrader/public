#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.QA1
{
    public class PrintAllProviderMappingNames : Indicator
    {
        int count;

        List<string> providerNames;// = new List<string>();
        private void LoadProviderNames()
        {
            providerNames = new List<string>();
            providerNames.Add("Barchart");
            providerNames.Add("Coinbase");
            providerNames.Add("Continuum");
            providerNames.Add("COT");
            providerNames.Add("CQG");
            providerNames.Add("CQG Server");
            providerNames.Add("cTrader");
            providerNames.Add("ESignal");
            providerNames.Add("External");
            providerNames.Add("FastFill");
            providerNames.Add("Forex.com");
            providerNames.Add("FXCM");
            providerNames.Add("FXCM Server");
            providerNames.Add("Gateway");
            providerNames.Add("IEX");
            providerNames.Add("InteractiveBrokers");
            providerNames.Add("IQFeed");
            providerNames.Add("ISV Simulator");
            providerNames.Add("Kinetick");
            providerNames.Add("Ninjatrader");
            providerNames.Add("NT Continuum");
            providerNames.Add("NT FXCM");
            providerNames.Add("Playback");
            providerNames.Add("Rithmic");
            providerNames.Add("Rithmic for NT Brokerage");
            providerNames.Add("Simulator");
            providerNames.Add("TD Ameritrade");
            providerNames.Add("Tradovate");

        }
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Indicator here.";
                Name = "PrintAllProviderMappingNames";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;
            }
            else if (State == State.Configure)
            {
                count = 0;
            }
            else if (State == State.DataLoaded)
            {
                //NinjaTrader.Gui.Tools.InstrumentsList iList = NinjaTrader.Gui.Tools.InstrumentsList(
                //	foreach(Instrument s in InstrumentsList.

                //LoadProviderNames();
                Print(Instrument.MasterInstrument.Name.ToString());
                for (int i = 0; i < Instrument.MasterInstrument.ProviderNames.Length; i++)
                {
                
                    Print(i.ToString() + "__" + Instrument.MasterInstrument.ProviderNames[i]);
                }
                return;

                foreach (Instrument i in Cbi.Instrument.All)
                {
                    if (i.MasterInstrument.InstrumentType == InstrumentType.Future)
                    {
                        if (count > 10) return;

                        Print(i.FullName.ToString());

                        for (int x = 0; x < Instrument.MasterInstrument.ProviderNames.Length; x++)
                        {

                            string sName = Instrument.MasterInstrument.ProviderNames[x];
                            if (sName.Length < 1)
                                sName = "-";
                            Print(sName);
                        }




                    }



                }
            }
        }


        protected override void OnBarUpdate()
        {
            //Add your custom indicator logic here.
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private QA1.PrintAllProviderMappingNames[] cachePrintAllProviderMappingNames;
		public QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames()
		{
			return PrintAllProviderMappingNames(Input);
		}

		public QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames(ISeries<double> input)
		{
			if (cachePrintAllProviderMappingNames != null)
				for (int idx = 0; idx < cachePrintAllProviderMappingNames.Length; idx++)
					if (cachePrintAllProviderMappingNames[idx] != null &&  cachePrintAllProviderMappingNames[idx].EqualsInput(input))
						return cachePrintAllProviderMappingNames[idx];
			return CacheIndicator<QA1.PrintAllProviderMappingNames>(new QA1.PrintAllProviderMappingNames(), input, ref cachePrintAllProviderMappingNames);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames()
		{
			return indicator.PrintAllProviderMappingNames(Input);
		}

		public Indicators.QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames(ISeries<double> input )
		{
			return indicator.PrintAllProviderMappingNames(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames()
		{
			return indicator.PrintAllProviderMappingNames(Input);
		}

		public Indicators.QA1.PrintAllProviderMappingNames PrintAllProviderMappingNames(ISeries<double> input )
		{
			return indicator.PrintAllProviderMappingNames(input);
		}
	}
}

#endregion
