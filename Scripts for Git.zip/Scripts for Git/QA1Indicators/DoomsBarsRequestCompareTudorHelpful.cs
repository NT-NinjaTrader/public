#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

using SharpDX;
using NinjaTrader.Core;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AlanIndicators
{
	public class DoomsBarsRequestCompareTudorHelpful : Indicator
	{
		
		
		/*
			Jim Dooms Anolog Project.  He overlays an old period of the instrument over the current.
		*/
		private bool doOnce;
		private int CurrentBar2;
		private double FirstSlot;
		private double FirstSlotDiff;
		private DateTime SecondaryStart, SecondaryEnd, BeginCompareAt;
		private NinjaTrader.Data.BarsRequest barsRequest;
		
		private string[] BrushList;
		private Dictionary<string, DXMediaMap> dxmBrushes;
        private SharpDX.Direct2D1.RenderTarget myRenderTarget = null;
        private Brush BarBrushDown
        {
            get { return dxmBrushes["BarBrushDown"].MediaBrush; }
            set { UpdateBrush(value, "BarBrushDown"); }
        }
		private Brush BarBrushUp
        {
            get { return dxmBrushes["BarBrushUp"].MediaBrush; }
            set { UpdateBrush(value, "BarBrushUp"); }
        }
		private Brush ShadowBrush
        {
            get { return dxmBrushes["ShadowBrush"].MediaBrush; }
            set { UpdateBrush(value, "ShadowBrush"); }
        }
		private Brush TransparentBrush
        {
            get { return dxmBrushes["TransparentBrush"].MediaBrush; }
            set { UpdateBrush(value, "TransparentBrush"); }
        }

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "DoomsBarsRequestCompareTudorHelpful";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				BarsRequiredToPlot							= 0;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				// Parameter Defaults
				SecondaryStartDate							= DateTime.Parse("01/05/2015");
				SecondaryEndDate							= DateTime.Parse("01/05/2016");
				BeginCompareAtDate							= DateTime.Parse("01/05/2017");
				
				SecondaryStartTime							= DateTime.Parse("12:00:00 PM");
				SecondaryEndTime							= DateTime.Parse("12:00:00 PM");
				BeginCompareAtTime							= DateTime.Parse("12:00:00 PM");
				
				ShadowWidth     							= 1;
				Opacity										= 100;
				BarColorDown								= Brushes.Red;
        		BarColorUp     								= Brushes.LimeGreen;
        		ShadowColor     							= Brushes.White;
				
				// SharpDX Brushes
				BrushList 									= new string[] { "BarBrushDown", "BarBrushUp", "ShadowBrush", "TransparentBrush" };
				dxmBrushes 									= new Dictionary<string, DXMediaMap>();
				
				foreach (string brushName in BrushList)
            	    dxmBrushes.Add(brushName, new DXMediaMap());
				
				// Plots for Secondary OHLC
				AddPlot(Brushes.Gray, 			"Open2");	// 0
				AddPlot(Brushes.Gray, 			"High2");	// 1
				AddPlot(Brushes.Gray, 			"Low2");	// 2
				AddPlot(Brushes.Gray, 			"Close2");	// 3
				AddPlot(Brushes.Transparent, 	"Time2");	// 4
			}
			else if (State == State.DataLoaded)
			{
				doOnce = true;
				
				// Calculate Start Date
				SecondaryStart 				= SecondaryStartDate;
				SecondaryStart.Add(new TimeSpan(SecondaryStartTime.Hour, SecondaryStartTime.Minute, SecondaryStartTime.Second));
				
				// Calculate End Date
				SecondaryEnd 				= SecondaryEndDate;
				SecondaryEnd.Add(new TimeSpan(SecondaryEndTime.Hour, SecondaryEndTime.Minute, SecondaryEndTime.Second));
				
				// Calculate First Bar to Sync
				BeginCompareAt 				= BeginCompareAtDate;
				BeginCompareAt.Add(new TimeSpan(BeginCompareAtTime.Hour, BeginCompareAtTime.Minute, BeginCompareAtTime.Second));
				FirstSlot 					= ChartBars.GetBarIdxByTime(ChartControl,BeginCompareAt);
				
				// Set DXM Brushes from User Defined Brushes
				BarBrushDown								= BarColorDown;
				BarBrushUp   								= BarColorUp;
				ShadowBrush  								= ShadowColor;
				
				foreach (string brushName in BrushList)
					SetOpacity(brushName);
				
				// Initiate BarsRequest
				DoBarsRequest(Instrument);				
			}
			else if (State == State.Terminated)
			{
				// Dispose BarsRequest
				if(barsRequest != null)
				{
					barsRequest.Update     -= BROnBarUpdate;
					barsRequest.Dispose();
				}
			}
		}
		
		protected override void OnBarUpdate()
		{
				
		}
		
		private void BROnBarUpdate(object sender, NinjaTrader.Data.BarsUpdateEventArgs e)
		{	
			return; // Bug. This should not happen historically. Historical BarsRequest logic goes in the BarsRequest itself. Keeping for now.
			/*
			TriggerCustomEvent(o =>
		    {
				if(doOnce)
				{
					if (Times[0][CurrentBar - (int)FirstSlot].Day != e.BarsSeries.GetTime(e.MaxIndex -1).Day)
					{
						FirstSlotDiff = (Times[0][CurrentBar - (int)FirstSlot].Day - BeginCompareAt.Day);
						FirstSlot -= FirstSlotDiff;
					}
					doOnce = false;	
				}
				
				int idx = CurrentBar - ((int)FirstSlot + CurrentBar2);
				int idx2 = e.MaxIndex - idx - 0 + (int)FirstSlotDiff;
				CurrentBar2++;
				
				Print(idx);
				Print(idx2);
				Print(CurrentBar2);
				
				if(idx < 0 + FirstSlotDiff || idx2 < 0)
					return;
				
				Open2[idx] 	= e.BarsSeries.GetOpen(idx2);
				High2[idx] 	= e.BarsSeries.GetHigh(idx2);
				Low2[idx] 	= e.BarsSeries.GetLow(idx2);
				Close2[idx] = e.BarsSeries.GetClose(idx2);
				Time2[idx] 	= e.BarsSeries.GetTime(idx2).Ticks;
		    }, null);
			*/
		}
		
		private NinjaTrader.Data.BarsRequest DoBarsRequest(Instrument instrument)
		{
			barsRequest 				= new NinjaTrader.Data.BarsRequest(instrument, SecondaryStart, SecondaryEnd);
			barsRequest.BarsPeriod 		= new NinjaTrader.Data.BarsPeriod { BarsPeriodType = BarsPeriod.BarsPeriodType, Value = BarsPeriod.Value };
			barsRequest.TradingHours    = NinjaTrader.Data.TradingHours.Get("Default 24 x 7");
			barsRequest.Update     		+= BROnBarUpdate;
			barsRequest.Request(new Action<NinjaTrader.Data.BarsRequest, ErrorCode, string>((b, errorCode, errorMessage) =>
			{
				Globals.RandomDispatcher.InvokeAsync(new Action(() =>
				{
					if (errorCode != ErrorCode.NoError)
					{
						BarsSeries bs = new BarsSeries(barsRequest.Instrument, barsRequest.BarsPeriod, From, To, TradingHours);
						return;
					}
					
					// Process Historical bars from BarsRequest.
					for (int i = 0; i < b.Bars.Count; i++)
					{
						TriggerCustomEvent(o =>
					    {
							// Correct any offsets when Trading Days do not match
							if(doOnce)
							{
								if (Times[0][CurrentBar - (int)FirstSlot].Day != b.Bars.GetTime(b.Bars.Count-1).Day)
								{
									FirstSlotDiff = Times[0][CurrentBar - (int)FirstSlot].Day - BeginCompareAt.Day;
									if(FirstSlotDiff != 0)
									{
										FirstSlotDiff++;
										FirstSlot -= FirstSlotDiff;
									}
								}
								doOnce = false;	
							}
							
							// Calculate indexes for Plot slots
							int idx = CurrentBar - ((int)FirstSlot + CurrentBar2);
							int idx2 = b.Bars.Count-1 - idx - 0 + (int)FirstSlotDiff;
							CurrentBar2++;
							
							// Make sure indexes are valid before referencing
							if(idx < 0 + FirstSlotDiff || idx2 < 0)
								return;
							
							// Assign OHLC values to Plots
							Open2[idx] 	= b.Bars.GetOpen(idx2);
							High2[idx] 	= b.Bars.GetHigh(idx2);
							Low2[idx] 	= b.Bars.GetLow(idx2);
							Close2[idx] = b.Bars.GetClose(idx2);
							Time2[idx] 	= b.Bars.GetTime(idx2).Ticks;
					    }, null);
					}
				}));
			}));
			return barsRequest;
		}
		
		#region Miscellaneous
		
		public override string FormatPriceMarker(double price)
		{
			for(int i = 0; i < Time2.Count-1; i++)
		    	if(Time2[i] == price)
		    		return new DateTime((long)Time2[i]).ToShortDateString();
			return price.ToString("N2");
		}   
		
       	public override void OnCalculateMinMax()
        {
            base.OnCalculateMinMax();
			
            if (Bars == null || ChartControl == null)
                return;

            for (int idx = ChartBars.FromIndex; idx <= ChartBars.ToIndex; idx++)
            {				
                if (High2.GetValueAt(idx) > MaxValue)
                    MaxValue = High2.GetValueAt(idx);
				
                if (Low2.GetValueAt(idx) < MinValue && Low2.GetValueAt(idx) != 0)
					MinValue = Low2.GetValueAt(idx);
            }
        }		
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {		
            if (Bars == null || ChartControl == null)
                return;

            int barPaintWidth = Math.Max(3, 1 + 2 * ((int)ChartControl.BarWidth - 1) + 2 * ShadowWidth);

            for (int idx = ChartBars.FromIndex; idx <= ChartBars.ToIndex; idx++)
            {
                if (idx - Displacement < 0 || idx - Displacement >= BarsArray[0].Count || ( idx - Displacement < BarsRequiredToPlot))
                    continue;
				
                double valH = High2.GetValueAt(idx);
                double valL = Low2.GetValueAt(idx);
                double valC = Close2.GetValueAt(idx);
                double valO = Open2.GetValueAt(idx);
                int x  = chartControl.GetXByBarIndex(chartControl.BarsArray[0], idx);
                int y1 = chartScale.GetYByValue(valO);
                int y2 = chartScale.GetYByValue(valH);
                int y3 = chartScale.GetYByValue(valL);
                int y4 = chartScale.GetYByValue(valC);

				if(idx > FirstSlot && valO < 1 || idx < FirstSlot)
					continue;

                var xy2 = new Vector2(x, y2);
                var xy3 = new Vector2(x, y3);
				
                RenderTarget.DrawLine(xy2, xy3, dxmBrushes["ShadowBrush"].DxBrush, ShadowWidth);				

                if (y4 == y1)
				    RenderTarget.DrawLine( new Vector2( x - barPaintWidth / 2 - 1, y1),  new Vector2( x + barPaintWidth / 2, y1), dxmBrushes["ShadowBrush"].DxBrush, ShadowWidth);
                else
                {
                    if (y4 > y1)					
                        RenderTarget.FillRectangle( new RectangleF(x - barPaintWidth / 2 - 1, y1, barPaintWidth, y4 - y1), dxmBrushes["BarBrushDown"].DxBrush);
                    else
                        RenderTarget.FillRectangle( new RectangleF(x - barPaintWidth / 2 - 1, y4, barPaintWidth, y1 - y4),dxmBrushes["BarBrushUp"].DxBrush);
                     RenderTarget.DrawRectangle( new RectangleF( x - barPaintWidth / 2 + (float)ShadowWidth / 2 - 1,
                       Math.Min(y4, y1), barPaintWidth - (float)ShadowWidth, Math.Abs(y4 - y1)), dxmBrushes["ShadowBrush"].DxBrush, ShadowWidth);
				}		
            }
        }
		
		public override void OnRenderTargetChanged()
        {
            // Dispose and recreate our DX Brushes
            try
            {
				if (dxmBrushes == null)
					return;
                foreach (KeyValuePair<string, DXMediaMap> item in dxmBrushes)
                {
											
                    if (item.Value.DxBrush != null)
                        item.Value.DxBrush.Dispose();

                    if (RenderTarget != null && item.Value.MediaBrush != null && !RenderTarget.IsDisposed)
                        item.Value.DxBrush = item.Value.MediaBrush.ToDxBrush(RenderTarget);
                }
            }
            catch (Exception exception)
            {
                Log(exception.ToString(), LogLevel.Error);
            }
        }
		
		[Browsable(false)]
        public class DXMediaMap
        {
            public SharpDX.Direct2D1.Brush DxBrush;
            public System.Windows.Media.Brush MediaBrush;
        }

        private void SetOpacity(string brushName)
        {
            if (dxmBrushes[brushName].MediaBrush == null)
                return;
			
			if(dxmBrushes[brushName].MediaBrush.Opacity == Opacity / 100.0)
				return;

            if (dxmBrushes[brushName].MediaBrush.IsFrozen)
                dxmBrushes[brushName].MediaBrush = dxmBrushes[brushName].MediaBrush.Clone();

            dxmBrushes[brushName].MediaBrush.Opacity = Opacity / 100.0;
            dxmBrushes[brushName].MediaBrush.Freeze();
        }
		
		private void UpdateBrush(Brush mediaBrush, string brushName)
        {
            dxmBrushes[brushName].MediaBrush = mediaBrush;
            SetOpacity(brushName);
            if (dxmBrushes[brushName].DxBrush != null)
                dxmBrushes[brushName].DxBrush.Dispose();
            if (RenderTarget != null && !RenderTarget.IsDisposed)
            {
                dxmBrushes[brushName].DxBrush = dxmBrushes[brushName].MediaBrush.ToDxBrush(RenderTarget);
            }       
        }
		#endregion
		
		#region Properties
		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.DateTimeConverter")]
		[Display(Name="Secondary Start Date", Order=1, GroupName="Parameters")]
		public DateTime SecondaryStartDate
		{ get; set; }
		
		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Secondary Start Time", Order=2, GroupName="Parameters")]
		public DateTime SecondaryStartTime
		{ get; set; }

		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.DateTimeConverter")]
		[Display(Name="Secondary End Date", Order=3, GroupName="Parameters")]
		public DateTime SecondaryEndDate
		{ get; set; }
		
		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Secondary End Time", Order=4, GroupName="Parameters")]
		public DateTime SecondaryEndTime
		{ get; set; }

		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.DateTimeConverter")]
		[Display(Name="Begin Compare At Date", Order=5, GroupName="Parameters")]
		public DateTime BeginCompareAtDate
		{ get; set; }
		
		[NinjaScriptProperty]
		[Gui.PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="Begin Compare At Time", Order=6, GroupName="Parameters")]
		public DateTime BeginCompareAtTime
		{ get; set; }
		
		[XmlIgnore]
		[Display(Name="BarColorDown", Description="Color of Down bars", Order=7, GroupName="Visual")]
		public Brush BarColorDown
		{ get; set;	}

		[Browsable(false)]
		public string BarColorDownSerializable
		{
			get { return Serialize.BrushToString(BarColorDown); }
			set { BarColorDown = Serialize.StringToBrush(value); }
		}			

		[XmlIgnore]
		[Display(Name="BarColorUp", Description="Color of Up bars", Order=8, GroupName="Visual")]
		public Brush BarColorUp
		{ get; set; }

		[Browsable(false)]
		public string BarColorUpSerializable
		{
			get { return Serialize.BrushToString(BarColorUp); }
			set { BarColorUp = Serialize.StringToBrush(value); }
		}			

		[XmlIgnore]
		[Display(Name="ShadowColor", Description="Wick/tail color", Order=9, GroupName="Visual")]
		public Brush ShadowColor
		{ get; set; }

		[Browsable(false)]
		public string ShadowColorSerializable
		{
			get { return Serialize.BrushToString(ShadowColor); }
			set { ShadowColor = Serialize.StringToBrush(value); }
		}			

		[Range(1, int.MaxValue)]
		[Display(Name="ShadowWidth", Description="Shadow (tail/wick) width", Order=10, GroupName="Visual")]
		public int ShadowWidth
		{ get; set;	}
		
		[Range(1, 100)]
		[Display(Name="Opacity", Description="Opacity for Secondary Bars", Order=10, GroupName="Visual")]
		public int Opacity
		{ get; set;	}
		
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Open2
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> High2
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Low2
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Close2
		{
			get { return Values[3]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Time2
		{
			get { return Values[4]; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlanIndicators.DoomsBarsRequestCompareTudorHelpful[] cacheDoomsBarsRequestCompareTudorHelpful;
		public AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			return DoomsBarsRequestCompareTudorHelpful(Input, secondaryStartDate, secondaryStartTime, secondaryEndDate, secondaryEndTime, beginCompareAtDate, beginCompareAtTime);
		}

		public AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(ISeries<double> input, DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			if (cacheDoomsBarsRequestCompareTudorHelpful != null)
				for (int idx = 0; idx < cacheDoomsBarsRequestCompareTudorHelpful.Length; idx++)
					if (cacheDoomsBarsRequestCompareTudorHelpful[idx] != null && cacheDoomsBarsRequestCompareTudorHelpful[idx].SecondaryStartDate == secondaryStartDate && cacheDoomsBarsRequestCompareTudorHelpful[idx].SecondaryStartTime == secondaryStartTime && cacheDoomsBarsRequestCompareTudorHelpful[idx].SecondaryEndDate == secondaryEndDate && cacheDoomsBarsRequestCompareTudorHelpful[idx].SecondaryEndTime == secondaryEndTime && cacheDoomsBarsRequestCompareTudorHelpful[idx].BeginCompareAtDate == beginCompareAtDate && cacheDoomsBarsRequestCompareTudorHelpful[idx].BeginCompareAtTime == beginCompareAtTime && cacheDoomsBarsRequestCompareTudorHelpful[idx].EqualsInput(input))
						return cacheDoomsBarsRequestCompareTudorHelpful[idx];
			return CacheIndicator<AlanIndicators.DoomsBarsRequestCompareTudorHelpful>(new AlanIndicators.DoomsBarsRequestCompareTudorHelpful(){ SecondaryStartDate = secondaryStartDate, SecondaryStartTime = secondaryStartTime, SecondaryEndDate = secondaryEndDate, SecondaryEndTime = secondaryEndTime, BeginCompareAtDate = beginCompareAtDate, BeginCompareAtTime = beginCompareAtTime }, input, ref cacheDoomsBarsRequestCompareTudorHelpful);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			return indicator.DoomsBarsRequestCompareTudorHelpful(Input, secondaryStartDate, secondaryStartTime, secondaryEndDate, secondaryEndTime, beginCompareAtDate, beginCompareAtTime);
		}

		public Indicators.AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(ISeries<double> input , DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			return indicator.DoomsBarsRequestCompareTudorHelpful(input, secondaryStartDate, secondaryStartTime, secondaryEndDate, secondaryEndTime, beginCompareAtDate, beginCompareAtTime);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			return indicator.DoomsBarsRequestCompareTudorHelpful(Input, secondaryStartDate, secondaryStartTime, secondaryEndDate, secondaryEndTime, beginCompareAtDate, beginCompareAtTime);
		}

		public Indicators.AlanIndicators.DoomsBarsRequestCompareTudorHelpful DoomsBarsRequestCompareTudorHelpful(ISeries<double> input , DateTime secondaryStartDate, DateTime secondaryStartTime, DateTime secondaryEndDate, DateTime secondaryEndTime, DateTime beginCompareAtDate, DateTime beginCompareAtTime)
		{
			return indicator.DoomsBarsRequestCompareTudorHelpful(input, secondaryStartDate, secondaryStartTime, secondaryEndDate, secondaryEndTime, beginCompareAtDate, beginCompareAtTime);
		}
	}
}

#endregion
