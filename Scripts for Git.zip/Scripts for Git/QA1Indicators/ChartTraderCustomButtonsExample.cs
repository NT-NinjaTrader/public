// Coded by Chelsea Bell. chelsea.bell@ninjatrader.com
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartTraderCustomButtonsExample : Indicator
	{
		System.Windows.Controls.Grid	chartTraderGrid;
		System.Windows.Controls.Grid	chartTraderButtonsGrid;
		System.Windows.Controls.Grid	myButtonsGrid;
		System.Windows.Controls.Button	newButton1;
		System.Windows.Controls.Button	newButton2;
		System.Windows.Controls.Button	newButton3;
		System.Windows.Controls.Button	newButton4;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"Enter the description for your new custom Indicator here.";
				Name = "ChartTraderCustomButtonsExample";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}
			}
		}

		protected override void OnBarUpdate()
		{

		}

		protected void Button1Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 1 Clicked", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			// only invalidate the chart so that the text box will appear even if there is no incoming data
			ChartControl.InvalidateVisual();
		}

		protected void Button2Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 2 Clicked", TextPosition.BottomLeft, Brushes.DarkRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void Button3Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 3 Clicked", TextPosition.BottomLeft, Brushes.DarkOrange, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void Button4Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 4 Clicked", TextPosition.BottomLeft, Brushes.CadetBlue, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void InsertWPFControls()
		{
			chartTraderGrid = (Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader).Content as System.Windows.Controls.Grid;
			chartTraderButtonsGrid = chartTraderGrid.Children[0] as System.Windows.Controls.Grid;
			myButtonsGrid = new System.Windows.Controls.Grid();

			chartTraderGrid.Children.Add(myButtonsGrid);

			// add a new space for our custom grid below the ask and bid prices
			chartTraderGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(45) });

			System.Windows.Controls.Grid.SetRow(myButtonsGrid, 7);

			chartTraderButtonsGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(31)	});
			// spacer row
			myButtonsGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(3) });
			myButtonsGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(31) });
			myButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength(100) });
			// spacer column
			myButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength(6) });
			myButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength(100) });

			newButton1 = new System.Windows.Controls.Button()
			{
				Background = Brushes.Gray,
				BorderBrush = Brushes.DimGray,
				Content = "MyButton1",
				Height = 30
			};

			newButton2 = new System.Windows.Controls.Button()
			{
				Background = Brushes.Gray,
				BorderBrush = Brushes.DimGray,
				Content = "MyButton2",
				Height = 30
			};

			newButton3 = new System.Windows.Controls.Button()
			{
				Background = Brushes.Gray,
				BorderBrush = Brushes.DimGray,
				Content = "MyButton3",
				Height = 30
			};

			newButton4 = new System.Windows.Controls.Button()
			{
				Background = Brushes.Gray,
				BorderBrush = Brushes.DimGray,
				Content = "MyButton4",
				Height = 30
			};

			newButton1.Click += Button1Click;
			System.Windows.Automation.AutomationProperties.SetAutomationId(newButton1, "newButton1");
			chartTraderButtonsGrid.Children.Add(newButton1);
			System.Windows.Controls.Grid.SetRow(newButton1, 12);

			newButton2.Click += Button2Click;
			System.Windows.Automation.AutomationProperties.SetAutomationId(newButton2, "newButton2");
			chartTraderButtonsGrid.Children.Add(newButton2);
			System.Windows.Controls.Grid.SetRow(newButton2, 12);
			System.Windows.Controls.Grid.SetColumn(newButton2, 2);

			newButton3.Click += Button3Click;
			System.Windows.Automation.AutomationProperties.SetAutomationId(newButton3, "newButton3");
			myButtonsGrid.Children.Add(newButton3);
			System.Windows.Controls.Grid.SetColumn(newButton3, 0);
			System.Windows.Controls.Grid.SetRow(newButton3, 1);

			newButton4.Click += Button4Click;
			System.Windows.Automation.AutomationProperties.SetAutomationId(newButton4, "newButton4");
			myButtonsGrid.Children.Add(newButton4);
			System.Windows.Controls.Grid.SetColumn(newButton4, 2);
			System.Windows.Controls.Grid.SetRow(newButton4, 1);
		}

		protected void RemoveWPFControls()
		{
			if (newButton1 != null)
			{
				newButton1.Click -= Button1Click;
				chartTraderButtonsGrid.Children.Remove(newButton1);
			}

			if (newButton2 != null)
			{
				newButton2.Click -= Button2Click;
				chartTraderButtonsGrid.Children.Remove(newButton2);
			}

			if (newButton3 != null)
			{
				newButton3.Click -= Button3Click;
				myButtonsGrid.Children.Remove(newButton3);
			}

			if (newButton4 != null)
			{
				newButton4.Click -= Button4Click;
				myButtonsGrid.Children.Remove(newButton4);
			}

			if (chartTraderButtonsGrid != null)
				chartTraderButtonsGrid.RowDefinitions.RemoveAt(chartTraderButtonsGrid.RowDefinitions.Count - 1);

			if (chartTraderGrid != null && myButtonsGrid != null)
			{
				chartTraderGrid.Children.Remove(myButtonsGrid);
				chartTraderGrid.RowDefinitions.RemoveAt(chartTraderGrid.RowDefinitions.Count - 1);
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartTraderCustomButtonsExample[] cacheChartTraderCustomButtonsExample;
		public ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample()
		{
			return ChartTraderCustomButtonsExample(Input);
		}

		public ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample(ISeries<double> input)
		{
			if (cacheChartTraderCustomButtonsExample != null)
				for (int idx = 0; idx < cacheChartTraderCustomButtonsExample.Length; idx++)
					if (cacheChartTraderCustomButtonsExample[idx] != null &&  cacheChartTraderCustomButtonsExample[idx].EqualsInput(input))
						return cacheChartTraderCustomButtonsExample[idx];
			return CacheIndicator<ChartTraderCustomButtonsExample>(new ChartTraderCustomButtonsExample(), input, ref cacheChartTraderCustomButtonsExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample()
		{
			return indicator.ChartTraderCustomButtonsExample(Input);
		}

		public Indicators.ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample(ISeries<double> input )
		{
			return indicator.ChartTraderCustomButtonsExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample()
		{
			return indicator.ChartTraderCustomButtonsExample(Input);
		}

		public Indicators.ChartTraderCustomButtonsExample ChartTraderCustomButtonsExample(ISeries<double> input )
		{
			return indicator.ChartTraderCustomButtonsExample(input);
		}
	}
}

#endregion
