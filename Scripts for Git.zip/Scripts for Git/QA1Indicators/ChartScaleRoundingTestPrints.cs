#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartScaleRoundingTestPrints : Indicator
	{
		
		/*
		
			User wanted to know why  chartScale.GetYByValue was changing between ticks.\
		
			This is due to Rounding.
		
		
				-780643		72
				-780715		72
				-780787		73
				-780860		72
				-780932		72
				-781004		73
				-781077		72

		
		*/
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ChartScaleRoundingTestPrints";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
	
		}
		
		
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
{
	
	/*
		Using GetYByValueWpf vs GetYByValue, WPF will give you decimal so the difference between prints will be
		exact and not rounded.
	*/
	
	
	
		  // gets the pixel coordinate of the price value passed to the method
//		double     yByValue = chartScale.GetYByValue(2700.00);
//		double     yByValue1 = chartScale.GetYByValue(2700.25);
//		double     yByValue2 = chartScale.GetYByValue(2700.50);
//		double     yByValue3 = chartScale.GetYByValue(2700.75);
//		double     yByValue4 = chartScale.GetYByValue(2701.00);
//		double     yByValue5 = chartScale.GetYByValue(2701.25);
//		double     yByValue6 = chartScale.GetYByValue(2701.50);
//		double     yByValue7 = chartScale.GetYByValue(2701.75);
		 

//		Print(yByValue);
//		Print(yByValue1);
//		Print(yByValue2);
//		Print(yByValue3);
//		Print(yByValue4);

//		Print(yByValue5);
//		Print(yByValue6);
//		Print(yByValue7);
	
	
	
	
		double     yByValue = chartScale.GetYByValueWpf(2700.00);
		double     yByValue1 = chartScale.GetYByValueWpf(2700.25);
		double     yByValue2 = chartScale.GetYByValueWpf(2700.50);
		double     yByValue3 = chartScale.GetYByValueWpf(2700.75);
		double     yByValue4 = chartScale.GetYByValueWpf(2701.00);
		double     yByValue5 = chartScale.GetYByValueWpf(2701.25);
		double     yByValue6 = chartScale.GetYByValueWpf(2701.50);
		double     yByValue7 = chartScale.GetYByValueWpf(2701.75);
		 

		Print(yByValue);
		Print(yByValue1);
		Print(yByValue2);
		Print(yByValue3);
		Print(yByValue4);

		Print(yByValue5);
		Print(yByValue6);
		Print(yByValue7);
	
	
	
	
	
}	
		
		
		
	
	}
	
	
	
	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartScaleRoundingTestPrints[] cacheChartScaleRoundingTestPrints;
		public ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints()
		{
			return ChartScaleRoundingTestPrints(Input);
		}

		public ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints(ISeries<double> input)
		{
			if (cacheChartScaleRoundingTestPrints != null)
				for (int idx = 0; idx < cacheChartScaleRoundingTestPrints.Length; idx++)
					if (cacheChartScaleRoundingTestPrints[idx] != null &&  cacheChartScaleRoundingTestPrints[idx].EqualsInput(input))
						return cacheChartScaleRoundingTestPrints[idx];
			return CacheIndicator<ChartScaleRoundingTestPrints>(new ChartScaleRoundingTestPrints(), input, ref cacheChartScaleRoundingTestPrints);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints()
		{
			return indicator.ChartScaleRoundingTestPrints(Input);
		}

		public Indicators.ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints(ISeries<double> input )
		{
			return indicator.ChartScaleRoundingTestPrints(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints()
		{
			return indicator.ChartScaleRoundingTestPrints(Input);
		}

		public Indicators.ChartScaleRoundingTestPrints ChartScaleRoundingTestPrints(ISeries<double> input )
		{
			return indicator.ChartScaleRoundingTestPrints(input);
		}
	}
}

#endregion
