#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AlanIndicators
{
    public class RightClickChartAddedMenuItem : Indicator
    {
        private MenuItem mySmaMenuItem;
        private MenuItem myEmaMenuItem;

        protected override void OnStateChange()
        {
          
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Indicator here.";
                Name = "RightClickChartAddedMenuItem";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                IsSuspendedWhileInactive = true;

            }
            else if (State == State.Historical)
            {

                if (ChartControl == null) return;
                ChartControl.Dispatcher.InvokeAsync(new Action(() =>
                {
                    ChartControl.ContextMenuOpening += ChartControl_ContextMenuOpening;
                    ChartControl.ContextMenuClosing += ChartControl_ContextMenuClosing;
                    mySmaMenuItem = new MenuItem { Header = "Test SMA Item" };
                    myEmaMenuItem = new MenuItem { Header = "Test EMA Item" };
                    mySmaMenuItem.Click += MySmaMenuItemClick;
                    myEmaMenuItem.Click += MyEmaMenuItem_Click;
                }));
            }
            else if (State == State.Terminated)
            {
                if (ChartControl == null) return;
                if (mySmaMenuItem != null)
                {
                    mySmaMenuItem.Click -= MySmaMenuItemClick;
                }
                if (myEmaMenuItem != null)
                {
                    myEmaMenuItem.Click -= MyEmaMenuItem_Click;
                }

                ChartControl.ContextMenuOpening -= ChartControl_ContextMenuOpening;
                ChartControl.ContextMenuClosing -= ChartControl_ContextMenuOpening;


            }
        }

        protected override void OnBarUpdate() { }
		
		
		
	
        private void ChartControl_ContextMenuClosing(object sender, ContextMenuEventArgs e)
        {
		
            if (ChartControl.ContextMenu != null && ChartControl.ContextMenu.Items.Contains(mySmaMenuItem)) ChartControl.ContextMenu.Items.Remove(mySmaMenuItem);
            if (ChartControl.ContextMenu != null && ChartControl.ContextMenu.Items.Contains(myEmaMenuItem)) ChartControl.ContextMenu.Items.Remove(myEmaMenuItem);
        }

        private void ChartControl_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
			ChartControl.Dispatcher.InvokeAsync(new Action(() =>
                {
                    if (ChartControl.ContextMenu != null) ChartControl.ContextMenu.Items.Add(mySmaMenuItem);
				
					
                }));	
        }

        private void MySmaMenuItemClick(object sender, RoutedEventArgs e)
        {
            Print("MySmaMenuItem Clicked");
        }

        private void MyEmaMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Print("MyEmaMenuItem Clicked");
        }
	
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlanIndicators.RightClickChartAddedMenuItem[] cacheRightClickChartAddedMenuItem;
		public AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem()
		{
			return RightClickChartAddedMenuItem(Input);
		}

		public AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem(ISeries<double> input)
		{
			if (cacheRightClickChartAddedMenuItem != null)
				for (int idx = 0; idx < cacheRightClickChartAddedMenuItem.Length; idx++)
					if (cacheRightClickChartAddedMenuItem[idx] != null &&  cacheRightClickChartAddedMenuItem[idx].EqualsInput(input))
						return cacheRightClickChartAddedMenuItem[idx];
			return CacheIndicator<AlanIndicators.RightClickChartAddedMenuItem>(new AlanIndicators.RightClickChartAddedMenuItem(), input, ref cacheRightClickChartAddedMenuItem);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem()
		{
			return indicator.RightClickChartAddedMenuItem(Input);
		}

		public Indicators.AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem(ISeries<double> input )
		{
			return indicator.RightClickChartAddedMenuItem(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem()
		{
			return indicator.RightClickChartAddedMenuItem(Input);
		}

		public Indicators.AlanIndicators.RightClickChartAddedMenuItem RightClickChartAddedMenuItem(ISeries<double> input )
		{
			return indicator.RightClickChartAddedMenuItem(input);
		}
	}
}

#endregion
