#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
using System.IO;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AlanIndicators
{
	public class AddDataSeriesOfSymbolPulledFromTextFile : Indicator
	{
		protected override void OnStateChange()
		{
			
			/*(
				This indicator will open file "symFile.txt" in NT8 folder, if it doesn't exist it will create it containing 
				the text "TSLA".
			
				When indicator applied to chart, it will pull this symbol and pass this symbol to AdddDataSeries.
			
				Then in OBU, you will see the close price for this secondary series printed which confirms the data 
				series was added.
			
				Written by Alan Palmer.
			
			
			
			*/
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AddDataSeriesOfSymbolPulledFromTextFile";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				string xSym;
				xSym =GetSymbolFromFile();
			
				Print("Adding Data Series for this symbol"+xSym.ToString());
				
				
				AddDataSeries(xSym,BarsPeriodType.Day,1);
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBars[0]<10 || CurrentBars[1]<10) return;
			
			Print(Closes[1][0].ToString());
		}
		
		private string FilePath 	= NinjaTrader.Core.Globals.UserDataDir +"symFile.txt";
		
		public string GetSymbolFromFile()  //C is contract enum, p is Path String
		{
			
				
		string symbolToReturn=null;
			
			
			if (!File.Exists(FilePath))
			{
				
				Print("File does not exist.  Creating it with a symbol TSLA");	// If file does not exist, let the user know			
				
				using (StreamWriter sw = File.CreateText(FilePath)) 
	            {
			
					sw.WriteLine("TSLA");
				
					sw.Close(); 
					sw.Dispose();
				}	
				
				
			
				
			}		
			
			StreamReader s1;
		
			s1 = new System.IO.StreamReader(FilePath);
		
			string Line1;

			int LineCounter = 0;
			
		    using (StreamReader sr = new StreamReader(FilePath)) 
            {
                string line;

                while ((line = sr.ReadLine()) != null) 
                {
                   	symbolToReturn  = line.ToString();
			
		
					break;
                }
			}
		
			
				return symbolToReturn;
		
		}
	
	
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile[] cacheAddDataSeriesOfSymbolPulledFromTextFile;
		public AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile()
		{
			return AddDataSeriesOfSymbolPulledFromTextFile(Input);
		}

		public AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile(ISeries<double> input)
		{
			if (cacheAddDataSeriesOfSymbolPulledFromTextFile != null)
				for (int idx = 0; idx < cacheAddDataSeriesOfSymbolPulledFromTextFile.Length; idx++)
					if (cacheAddDataSeriesOfSymbolPulledFromTextFile[idx] != null &&  cacheAddDataSeriesOfSymbolPulledFromTextFile[idx].EqualsInput(input))
						return cacheAddDataSeriesOfSymbolPulledFromTextFile[idx];
			return CacheIndicator<AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile>(new AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile(), input, ref cacheAddDataSeriesOfSymbolPulledFromTextFile);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile()
		{
			return indicator.AddDataSeriesOfSymbolPulledFromTextFile(Input);
		}

		public Indicators.AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile(ISeries<double> input )
		{
			return indicator.AddDataSeriesOfSymbolPulledFromTextFile(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile()
		{
			return indicator.AddDataSeriesOfSymbolPulledFromTextFile(Input);
		}

		public Indicators.AlanIndicators.AddDataSeriesOfSymbolPulledFromTextFile AddDataSeriesOfSymbolPulledFromTextFile(ISeries<double> input )
		{
			return indicator.AddDataSeriesOfSymbolPulledFromTextFile(input);
		}
	}
}

#endregion
