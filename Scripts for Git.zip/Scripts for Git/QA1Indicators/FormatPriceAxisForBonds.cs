#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AlanIndicators
{
	public class FormatPriceAxisForBonds : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "FormatPriceAxisForBonds";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}
		public override string FormatPriceMarker(double price)
		{
			double trunc = Math.Truncate(price);
			int fraction = Convert.ToInt32(320 * Math.Abs(price - trunc) - 0.0001); // rounding down for ZF and ZT
			string priceMarker = "";
			if (TickSize == 0.03125) 
			{
				fraction = fraction/10;
				if (fraction < 10)
					priceMarker = trunc.ToString() + "'0" + fraction.ToString();
				else 
					priceMarker = trunc.ToString() + "'" + fraction.ToString();
			}
			else if (TickSize == 0.015625 || TickSize == 0.0078125)
			{
				if (fraction < 10)
					priceMarker = trunc.ToString() + "'00" + fraction.ToString();
				else if (fraction < 100)
					priceMarker = trunc.ToString() + "'0" + fraction.ToString();
				else	
					priceMarker = trunc.ToString() + "'" + fraction.ToString();
			}
			else
				priceMarker = priceMarker;
			return priceMarker;
		}
		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlanIndicators.FormatPriceAxisForBonds[] cacheFormatPriceAxisForBonds;
		public AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds()
		{
			return FormatPriceAxisForBonds(Input);
		}

		public AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds(ISeries<double> input)
		{
			if (cacheFormatPriceAxisForBonds != null)
				for (int idx = 0; idx < cacheFormatPriceAxisForBonds.Length; idx++)
					if (cacheFormatPriceAxisForBonds[idx] != null &&  cacheFormatPriceAxisForBonds[idx].EqualsInput(input))
						return cacheFormatPriceAxisForBonds[idx];
			return CacheIndicator<AlanIndicators.FormatPriceAxisForBonds>(new AlanIndicators.FormatPriceAxisForBonds(), input, ref cacheFormatPriceAxisForBonds);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds()
		{
			return indicator.FormatPriceAxisForBonds(Input);
		}

		public Indicators.AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds(ISeries<double> input )
		{
			return indicator.FormatPriceAxisForBonds(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds()
		{
			return indicator.FormatPriceAxisForBonds(Input);
		}

		public Indicators.AlanIndicators.FormatPriceAxisForBonds FormatPriceAxisForBonds(ISeries<double> input )
		{
			return indicator.FormatPriceAxisForBonds(input);
		}
	}
}

#endregion
