#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class TestVolumetricBarsPeriod : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= "TestVolumetricBarsPeriod" ;
				Name										= "TestVolumetricBarsPeriod" ;
				Calculate									= Calculate.OnBarClose ;
				IsOverlay									= true ;
				DisplayInDataBox							= false ;
				DrawOnPricePanel							= true ;
				DrawHorizontalGridLines						= false ;
				DrawVerticalGridLines						= false ;
				PaintPriceMarkers							= false ;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right ;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true ;
				
				BIP	= 0;
			}
			else if (State == State.Configure)
			{
				AddVolumetric("",BarsPeriodType.Minute,1,VolumetricDeltaType.BidAsk,2,true) ;
			}
		}

		protected override void OnBarUpdate()
		{
			if ( ! Bars.BarsType.IsIntraday ) { return ; }
			if( Bars == null ) { return ; }

			if(BarsInProgress == BIP)
			{
				NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType barsType = BarsArray[BarsInProgress].BarsType as NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType ;
				
				if( barsType == null ) { return ; }
				
				ClearOutputWindow();
				Print("CurrentBar: " + CurrentBar) ;
				Print("Time[0]: " + Time[0]) ;
				Print("=================================================") ;
				Print("BIP: " + BIP);
				Print("barsType.BarsPeriod.Value: " + barsType.BarsPeriod.Value);
				Print("BarsArray[BarsInProgress].BarsPeriod.Value: " + BarsArray[BarsInProgress].BarsPeriod.Value);
				for( double price=Low[0] ; price<=High[0] ; price += TickSize * barsType.BarsPeriod.Value)
				{
					long bid_volume = barsType.Volumes[CurrentBar].GetBidVolumeForPrice(price) ;
					long ask_volume = barsType.Volumes[CurrentBar].GetAskVolumeForPrice(price) ;
					long delta = barsType.Volumes[CurrentBar].GetDeltaForPrice(price) ;
					Print( string.Format("Price={0}  BV={1}  AV={2}  Delta={3}", price.ToString("N2"), bid_volume, ask_volume, delta) ) ;
				}
			}
		}

#region Properties
		[NinjaScriptProperty]
		[Range(0, 1)]
		[Display(Name="BIP", Order=1, GroupName="Parameters")]
		public int BIP
		{ get; set; }
#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TestVolumetricBarsPeriod[] cacheTestVolumetricBarsPeriod;
		public TestVolumetricBarsPeriod TestVolumetricBarsPeriod(int bIP)
		{
			return TestVolumetricBarsPeriod(Input, bIP);
		}

		public TestVolumetricBarsPeriod TestVolumetricBarsPeriod(ISeries<double> input, int bIP)
		{
			if (cacheTestVolumetricBarsPeriod != null)
				for (int idx = 0; idx < cacheTestVolumetricBarsPeriod.Length; idx++)
					if (cacheTestVolumetricBarsPeriod[idx] != null && cacheTestVolumetricBarsPeriod[idx].BIP == bIP && cacheTestVolumetricBarsPeriod[idx].EqualsInput(input))
						return cacheTestVolumetricBarsPeriod[idx];
			return CacheIndicator<TestVolumetricBarsPeriod>(new TestVolumetricBarsPeriod(){ BIP = bIP }, input, ref cacheTestVolumetricBarsPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TestVolumetricBarsPeriod TestVolumetricBarsPeriod(int bIP)
		{
			return indicator.TestVolumetricBarsPeriod(Input, bIP);
		}

		public Indicators.TestVolumetricBarsPeriod TestVolumetricBarsPeriod(ISeries<double> input , int bIP)
		{
			return indicator.TestVolumetricBarsPeriod(input, bIP);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TestVolumetricBarsPeriod TestVolumetricBarsPeriod(int bIP)
		{
			return indicator.TestVolumetricBarsPeriod(Input, bIP);
		}

		public Indicators.TestVolumetricBarsPeriod TestVolumetricBarsPeriod(ISeries<double> input , int bIP)
		{
			return indicator.TestVolumetricBarsPeriod(input, bIP);
		}
	}
}

#endregion
