#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class LoadControlFromXamlFileExample : Indicator
	{
		private System.Windows.Controls.Grid	chartGrid, buttonGrid;
		private System.Windows.Controls.Button	button1, button2;
		private ChartTrader						chartTraderControl;
		private	QuantityUpDown					quantityUpDown;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "LoadControlFromXamlFileExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		protected void Button1_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 1 clicked", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void Button2_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 2 clicked", TextPosition.BottomLeft, Brushes.DarkRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void InsertWPFControls()
		{
			chartTraderControl	= Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader;
			chartGrid			= chartTraderControl.Parent as System.Windows.Controls.Grid;

			// a new column is added to the right of the chart
			chartGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			// width of new column is set to the chartTrader's column width
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1].Width = chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width;
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width = new GridLength(100);
			// chartTrader is moved to the new column (our column space is now the old chartTrader column)
			System.Windows.Controls.Grid.SetColumn(chartTraderControl, chartGrid.ColumnDefinitions.Count - 1);

			try
			{
				// load the xaml from a file to a file stream
				System.IO.FileStream fs	= new System.IO.FileStream(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, @"bin\Custom\AddOns\LoadControlFromXamlFileContent.xaml"), System.IO.FileMode.Open);
				
				// save the xaml from the file stream to a wpf control
				buttonGrid				= (System.Windows.Controls.Grid) System.Windows.Markup.XamlReader.Load(fs);
				
				// find the controls from inside of the grid control and set event handlers to the .Clicks
				button1	= LogicalTreeHelper.FindLogicalNode(buttonGrid, "Button1") as System.Windows.Controls.Button;
				if (button1 != null)
					button1.Click += Button1_Click;

				button2	= LogicalTreeHelper.FindLogicalNode(buttonGrid, "Button2") as System.Windows.Controls.Button;
				if (button2 != null)
					button2.Click += Button2_Click;

				quantityUpDown = LogicalTreeHelper.FindLogicalNode(buttonGrid, "quantityUpDown") as QuantityUpDown;
				quantityUpDown.ValueChanged += QuantityUpDown_ValueChanged;

				System.Windows.Controls.Grid.SetColumn(buttonGrid, chartGrid.ColumnDefinitions.Count - 2);
				System.Windows.Controls.Grid.SetRow(buttonGrid, System.Windows.Controls.Grid.GetRow(chartTraderControl));
				chartGrid.Children.Add(buttonGrid);
			}
			catch (Exception e)
			{
				Print("LoadControlFromXamlFileExample: Could not load xaml file");
				Print(e.ToString());
			}
		}

		private void QuantityUpDown_ValueChanged(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", string.Format("quantityUpDownValue: {0}", ((QuantityUpDown)sender).Value), TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void RemoveWPFControls()
		{
			if (button1 != null)
				button1.Click -= Button1_Click;

			if (button2 != null)
				button2.Click -= Button2_Click;

			if (quantityUpDown != null)
				quantityUpDown.ValueChanged -= QuantityUpDown_ValueChanged;
			
			// remove button grid
			chartGrid.Children.Remove(buttonGrid);
			// set chart trader back to the originating column
			System.Windows.Controls.Grid.SetColumn(chartTraderControl, chartGrid.ColumnDefinitions.Count - 2);
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width = chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1].Width;
			// remove the added column
			chartGrid.ColumnDefinitions.Remove(chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1]);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LoadControlFromXamlFileExample[] cacheLoadControlFromXamlFileExample;
		public LoadControlFromXamlFileExample LoadControlFromXamlFileExample()
		{
			return LoadControlFromXamlFileExample(Input);
		}

		public LoadControlFromXamlFileExample LoadControlFromXamlFileExample(ISeries<double> input)
		{
			if (cacheLoadControlFromXamlFileExample != null)
				for (int idx = 0; idx < cacheLoadControlFromXamlFileExample.Length; idx++)
					if (cacheLoadControlFromXamlFileExample[idx] != null &&  cacheLoadControlFromXamlFileExample[idx].EqualsInput(input))
						return cacheLoadControlFromXamlFileExample[idx];
			return CacheIndicator<LoadControlFromXamlFileExample>(new LoadControlFromXamlFileExample(), input, ref cacheLoadControlFromXamlFileExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LoadControlFromXamlFileExample LoadControlFromXamlFileExample()
		{
			return indicator.LoadControlFromXamlFileExample(Input);
		}

		public Indicators.LoadControlFromXamlFileExample LoadControlFromXamlFileExample(ISeries<double> input )
		{
			return indicator.LoadControlFromXamlFileExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LoadControlFromXamlFileExample LoadControlFromXamlFileExample()
		{
			return indicator.LoadControlFromXamlFileExample(Input);
		}

		public Indicators.LoadControlFromXamlFileExample LoadControlFromXamlFileExample(ISeries<double> input )
		{
			return indicator.LoadControlFromXamlFileExample(input);
		}
	}
}

#endregion
