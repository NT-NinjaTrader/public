#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AlanIndicators
{
	public class PlotDailySeriesOpenOnIntradayChartLoop : Indicator
	{
		
		//This indicator will set the plot equal to the open of the Daily Series,
		//which may not equal the ETH.
				
		private double DayDataOpen = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "PlotDailySeriesOpenOnIntradayChartLoop";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
					
				AddPlot(new Stroke(Brushes.Magenta, 2), PlotStyle.Line, "DailyOpen");
			
			}
			else if (State == State.Configure)
			{

			AddDataSeries(BarsPeriodType.Day, 1); //Day Data

			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBars[0] <= 20 ||CurrentBars[1] <= 20  ) return;
			
			DayDataOpen = Opens[1][0];

		//	Print(DayDataOpen.ToString());
			
			DateTime today = Times[0][0];
			for(int i =0; i<100; i++)
			{		
				Values[0][i]= DayDataOpen;	
				if(Times[0][i].Date !=today.Date)
					break;
			}
			
		}

		#region Properties
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DailyOpen
		{
			get { return Values[0]; }
		}
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop[] cachePlotDailySeriesOpenOnIntradayChartLoop;
		public AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop()
		{
			return PlotDailySeriesOpenOnIntradayChartLoop(Input);
		}

		public AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop(ISeries<double> input)
		{
			if (cachePlotDailySeriesOpenOnIntradayChartLoop != null)
				for (int idx = 0; idx < cachePlotDailySeriesOpenOnIntradayChartLoop.Length; idx++)
					if (cachePlotDailySeriesOpenOnIntradayChartLoop[idx] != null &&  cachePlotDailySeriesOpenOnIntradayChartLoop[idx].EqualsInput(input))
						return cachePlotDailySeriesOpenOnIntradayChartLoop[idx];
			return CacheIndicator<AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop>(new AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop(), input, ref cachePlotDailySeriesOpenOnIntradayChartLoop);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop()
		{
			return indicator.PlotDailySeriesOpenOnIntradayChartLoop(Input);
		}

		public Indicators.AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop(ISeries<double> input )
		{
			return indicator.PlotDailySeriesOpenOnIntradayChartLoop(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop()
		{
			return indicator.PlotDailySeriesOpenOnIntradayChartLoop(Input);
		}

		public Indicators.AlanIndicators.PlotDailySeriesOpenOnIntradayChartLoop PlotDailySeriesOpenOnIntradayChartLoop(ISeries<double> input )
		{
			return indicator.PlotDailySeriesOpenOnIntradayChartLoop(input);
		}
	}
}

#endregion
