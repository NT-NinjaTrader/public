#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class TestingRegions : Indicator
	{
		
			protected override void OnStateChange()
			{

				#region OnStateChange
				
					if (State == State.SetDefaults)
					{
						Description									= @"";
						Name										= "TestingRegions";
						Calculate									= Calculate.OnBarClose;
						IsOverlay									= true;
						DisplayInDataBox							= false;
						DrawOnPricePanel							= true;
						DrawHorizontalGridLines						= false;
						DrawVerticalGridLines						= false;
						PaintPriceMarkers							= false;
						ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
						//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
						//See Help Guide for additional information.
						IsSuspendedWhileInactive					= true;
					}
					else if (State == State.Configure)
					{
					}
				}
		
		#endregion
		
		
		#region OnBarUpdate

			protected override void OnBarUpdate()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
			
		#region Test1

			private void Test1()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
			
		#region Test2

			private void Test2()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
		#region Test3

			private void Test3()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
		#region Test4

			private void Test4()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
		#region Test5

			private void Test5()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
		#region Test6

			private void Test6()
			{
				//Add your custom indicator logic here.
			}
		
		#endregion
			
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TestingRegions[] cacheTestingRegions;
		public TestingRegions TestingRegions()
		{
			return TestingRegions(Input);
		}

		public TestingRegions TestingRegions(ISeries<double> input)
		{
			if (cacheTestingRegions != null)
				for (int idx = 0; idx < cacheTestingRegions.Length; idx++)
					if (cacheTestingRegions[idx] != null &&  cacheTestingRegions[idx].EqualsInput(input))
						return cacheTestingRegions[idx];
			return CacheIndicator<TestingRegions>(new TestingRegions(), input, ref cacheTestingRegions);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TestingRegions TestingRegions()
		{
			return indicator.TestingRegions(Input);
		}

		public Indicators.TestingRegions TestingRegions(ISeries<double> input )
		{
			return indicator.TestingRegions(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TestingRegions TestingRegions()
		{
			return indicator.TestingRegions(Input);
		}

		public Indicators.TestingRegions TestingRegions(ISeries<double> input )
		{
			return indicator.TestingRegions(input);
		}
	}
}

#endregion
