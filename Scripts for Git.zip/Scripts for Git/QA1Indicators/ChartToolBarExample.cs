// Coded by Chelsea Bell. chelsea.bell@ninjatrader.com
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartToolBarExample : Indicator
	{
		private System.Windows.Controls.Grid chartGrid;
		private System.Windows.Shapes.Rectangle[] colorRectangles;

		private SolidColorBrush ActiveBackgroundDarkGray;
		private SolidColorBrush BackGroundMediumGray;
		private SolidColorBrush ControlLightGray;
		private SolidColorBrush TextColor;

		private bool addedFirstRow = false;

		private System.Windows.Controls.Grid leftInnerGrid;
		private System.Windows.Controls.Menu topMenu;
		private System.Windows.Controls.Menu leftMenu1;
		private System.Windows.Controls.Menu leftMenu2;
		private System.Windows.Controls.MenuItem topMenuItem2;
		private System.Windows.Controls.MenuItem leftMenu2Item1;
		private NinjaTrader.Gui.Tools.NTMenuItem topMenuItem1SubItem1;
		private NinjaTrader.Gui.Tools.NTMenuItem topMenuItem1SubItem2;
		private NinjaTrader.Gui.Tools.NTMenuItem leftMenu1Item1SubItem1;
		private NinjaTrader.Gui.Tools.NTMenuItem leftMenu1Item1SubItem2;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Enter the description for your new custom Indicator here.";
				Name								= "ChartToolBarExample";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;
				ActiveBackgroundDarkGray			= new SolidColorBrush(Color.FromRgb(30, 30, 30));
				ActiveBackgroundDarkGray.Freeze();
				BackGroundMediumGray				= new SolidColorBrush(Color.FromRgb(45, 45, 47));
				BackGroundMediumGray.Freeze();
				ControlLightGray					= new SolidColorBrush(Color.FromRgb(64, 63, 69));
				ControlLightGray.Freeze();
				TextColor							= new SolidColorBrush(Color.FromRgb(204, 204, 204));
				TextColor.Freeze();
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		protected void InsertWPFControls()
		{
			chartGrid = (Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader).Parent as System.Windows.Controls.Grid;

			chartGrid.Background = BackBrush;

			chartGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			chartGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			chartGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
			chartGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());

			if (chartGrid.RowDefinitions.Count == 2)
			{
				chartGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
				addedFirstRow = true;
			}

			// shift existing column sizes 2 over to the right
			for (int i = chartGrid.ColumnDefinitions.Count - 1; i > 1; i--)
				chartGrid.ColumnDefinitions[i].Width = chartGrid.ColumnDefinitions[i - 2].Width;

			// shift existing row sizes 2 down
			for (int i = chartGrid.RowDefinitions.Count - 1; i > 1; i--)
				chartGrid.RowDefinitions[i].Height = chartGrid.RowDefinitions[i - 2].Height;

			// left menu column
			chartGrid.ColumnDefinitions[0].Width = new GridLength(28);
			// spacing column
			chartGrid.ColumnDefinitions[1].Width = new GridLength(3);
			// top menu column
			chartGrid.RowDefinitions[0].Height = new GridLength(20);
			// spacing row
			chartGrid.RowDefinitions[1].Height = new GridLength(3);

			// loop over existing items and move those to the newly created columns and rows
			for (int i = 0; i < chartGrid.Children.Count; i++)
			{
				System.Windows.Controls.Grid.SetColumn(chartGrid.Children[i], System.Windows.Controls.Grid.GetColumn(chartGrid.Children[i]) + 2);
				System.Windows.Controls.Grid.SetRow(chartGrid.Children[i], System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) + 2);
			}

			// upper tool bar objects

			// upper tool bar menu
			topMenu = new System.Windows.Controls.Menu()
			{
				Background = ActiveBackgroundDarkGray,
				BorderBrush = ControlLightGray,
				VerticalAlignment = VerticalAlignment.Center,

				Padding = new System.Windows.Thickness(0),
				Margin = new System.Windows.Thickness(0),
			};

			Style mmiStyle = Application.Current.TryFindResource("MainMenuItem") as Style;

			NinjaTrader.Gui.Tools.NTMenuItem topMenuItem1 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				Foreground = TextColor,
				Header = "Menu 1     v",
				Margin = new System.Windows.Thickness(0),
				Padding = new System.Windows.Thickness(1),
				VerticalAlignment = VerticalAlignment.Center,
				Style = mmiStyle
			};

			topMenuItem1SubItem1 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				BorderThickness = new System.Windows.Thickness(0),
				Foreground = TextColor,
				Header = "Submenu Item 1"
			};

			topMenuItem1SubItem1.Click += TopMenuItem1SubItem1_Click;
			topMenuItem1.Items.Add(topMenuItem1SubItem1);

			topMenuItem1SubItem2 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				Foreground = TextColor,
				Header = "Submenu Item 2"
			};
			topMenuItem1SubItem2.Click += TopMenuItem1SubItem2_Click;
			topMenuItem1.Items.Add(topMenuItem1SubItem2);

			topMenu.Items.Add(topMenuItem1);

			// upper tool bar button, has text and image
			topMenuItem2 = new System.Windows.Controls.MenuItem()
			{
				Background = ControlLightGray,
				Foreground = TextColor,
				Padding = new System.Windows.Thickness(1),
				Margin = new System.Windows.Thickness(5, 0, 5, 0),
				FontSize = 12
			};

			// this stackpanel allows us to place text and a picture horizontally in topMenuItem2
			System.Windows.Controls.StackPanel topMenuItem2StackPanel = new System.Windows.Controls.StackPanel()
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal,
				VerticalAlignment = VerticalAlignment.Top,
				HorizontalAlignment = HorizontalAlignment.Right
			};

			System.Windows.Controls.TextBlock newTextBlock = new System.Windows.Controls.TextBlock()
			{
				Text = "B1 ",
				Margin = new System.Windows.Thickness(0, 0, 2, 0),
				VerticalAlignment = VerticalAlignment.Top,
				HorizontalAlignment = HorizontalAlignment.Right,
				ToolTip = "Button 1"
			};

			topMenuItem2StackPanel.Children.Add(newTextBlock);

			// check to see if an image exists in Documents\bin\Custom\Indicators called B1.png.
			// if its there, include this with the button
			System.Windows.Media.Imaging.BitmapImage buttonImage = new System.Windows.Media.Imaging.BitmapImage();

			try
			{
				buttonImage = new System.Windows.Media.Imaging.BitmapImage(new Uri(NinjaTrader.Core.Globals.UserDataDir + @"bin\Custom\Indicators\B1.png"));
			}
			catch (Exception e) { }

			System.Windows.Controls.Image imageControl = new System.Windows.Controls.Image();

			if (buttonImage != null)
			{
				imageControl = new System.Windows.Controls.Image()
				{
					Source = buttonImage,
					Height = 10,
					Width = 10
				};
			}

			if (buttonImage != null)
				topMenuItem2StackPanel.Children.Add(imageControl);

			topMenuItem2.Header = topMenuItem2StackPanel;
			topMenuItem2.Click += TopMenuItem2_Click;
			topMenu.Items.Add(topMenuItem2);

			chartGrid.Children.Add(topMenu);

			System.Windows.Controls.Grid.SetColumn(topMenu, 2);
			System.Windows.Controls.Grid.SetColumn(topMenu, chartGrid.ColumnDefinitions.Count - 2);
			System.Windows.Controls.Grid.SetRow(topMenu, 0);

			// left toolbar objects
			// each vertical object needs its own menu

			leftInnerGrid = new System.Windows.Controls.Grid();

			leftInnerGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
			leftInnerGrid.RowDefinitions[0].Height = new GridLength(1, GridUnitType.Star);

			leftInnerGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
			leftInnerGrid.RowDefinitions[1].Height = new GridLength(30);

			leftMenu1 = new System.Windows.Controls.Menu()
			{
				Background = ActiveBackgroundDarkGray,
				Margin = new System.Windows.Thickness(0),
				Padding = new System.Windows.Thickness(0)
			};

			leftMenu2 = new System.Windows.Controls.Menu()
			{
				Background = ActiveBackgroundDarkGray,
				Margin = new System.Windows.Thickness(0),
				Padding = new System.Windows.Thickness(0)
			};

			// this allows us to make our menus stack vertically
			System.Windows.Controls.VirtualizingStackPanel VerticalStackPanel = new System.Windows.Controls.VirtualizingStackPanel()
			{
				Background = ActiveBackgroundDarkGray,
				Orientation = System.Windows.Controls.Orientation.Vertical,
				VerticalAlignment = VerticalAlignment.Stretch,
				HorizontalAlignment = HorizontalAlignment.Stretch
			};

			NinjaTrader.Gui.Tools.NTMenuItem leftMenu1Item1 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				Foreground = TextColor,
				Header = "M2 v",
				Margin = new System.Windows.Thickness(0),
				Padding = new System.Windows.Thickness(0),
				VerticalAlignment = VerticalAlignment.Stretch,
				HorizontalAlignment = HorizontalAlignment.Stretch,
				ToolTip = "Menu 2"
				/*Style = Application.Current.TryFindResource("MainMenuItem") as Style*/
			};

			leftMenu1Item1SubItem1 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				BorderThickness = new System.Windows.Thickness(0),
				Foreground = TextColor,
				Header = "Submenu Item 1"
			};

			leftMenu1Item1SubItem1.Click += LeftMenu1Item1SubItem1_Click;
			leftMenu1Item1.Items.Add(leftMenu1Item1SubItem1);

			NinjaTrader.Gui.Tools.NTMenuItem leftMenu1Item1SubItem2 = new Gui.Tools.NTMenuItem()
			{
				Background = ControlLightGray,
				Foreground = TextColor,
				Header = "Submenu Item 2"
			};

			leftMenu1Item1SubItem2.Click += LeftMenu1Item1SubItem2_Click;
			leftMenu1Item1.Items.Add(leftMenu1Item1SubItem2);

			leftMenu1.Items.Add(leftMenu1Item1);
			VerticalStackPanel.Children.Add(leftMenu1);

			leftMenu2Item1 = new System.Windows.Controls.MenuItem()
			{
				Background = ControlLightGray,
				FontSize = 12,
				Foreground = TextColor,
				Header = "B2",
				Padding = new System.Windows.Thickness(0),
				Margin = new System.Windows.Thickness(0),
				VerticalAlignment = VerticalAlignment.Stretch,
				HorizontalAlignment = HorizontalAlignment.Stretch
			};

			leftMenu2.Items.Add(leftMenu2Item1);

			VerticalStackPanel.Children.Add(leftMenu2);
			leftInnerGrid.Children.Add(VerticalStackPanel);

			chartGrid.Children.Add(leftInnerGrid);
			System.Windows.Controls.Grid.SetRow(leftInnerGrid, chartGrid.RowDefinitions.Count - 1);
			System.Windows.Controls.Grid.SetColumn(leftInnerGrid, 0);

			leftMenu2Item1.Click += LeftMenu2Item1_Click;
		}

		protected void RemoveWPFControls()
		{
			if (topMenuItem1SubItem1 != null)
				topMenuItem1SubItem1.Click -= TopMenuItem1SubItem1_Click;

			if (topMenuItem1SubItem2 != null)
				topMenuItem1SubItem2.Click -= TopMenuItem1SubItem2_Click;

			if (topMenuItem2 != null)
				topMenuItem2.Click -= TopMenuItem2_Click;

			if (leftMenu1Item1SubItem1 != null)
				leftMenu1Item1SubItem1.Click -= LeftMenu1Item1SubItem1_Click;

			if (leftMenu1Item1SubItem2 != null)
				leftMenu1Item1SubItem2.Click -= LeftMenu1Item1SubItem2_Click;

			if (leftMenu2Item1 != null)
				leftMenu2Item1.Click -= LeftMenu2Item1_Click;

			if (topMenu != null)
				chartGrid.Children.Remove(topMenu);

			if (leftInnerGrid != null)
				chartGrid.Children.Remove(leftInnerGrid);

			if (chartGrid != null)
			{
				//// shift all but last 2 column sizes 2 over to the left
				for (int i = 0; i < chartGrid.ColumnDefinitions.Count - 2; i++)
					chartGrid.ColumnDefinitions[i].Width = chartGrid.ColumnDefinitions[i + 2].Width;

				//// shift all but last 2 row sizes 2 up
				for (int i = 0; i < chartGrid.RowDefinitions.Count - 2; i++)
					chartGrid.RowDefinitions[i].Height = chartGrid.RowDefinitions[i + 2].Height;

				for (int i = 0; i < chartGrid.Children.Count; i++)
				{
					if ((System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) - 2) >= 0)
						System.Windows.Controls.Grid.SetRow(chartGrid.Children[i], System.Windows.Controls.Grid.GetRow(chartGrid.Children[i]) - 2);

					if ((System.Windows.Controls.Grid.GetColumn(chartGrid.Children[i]) - 2) >= 0)
						System.Windows.Controls.Grid.SetColumn(chartGrid.Children[i], System.Windows.Controls.Grid.GetColumn(chartGrid.Children[i]) - 2);
				}

				if (chartGrid.ColumnDefinitions.Count > 0)
					chartGrid.ColumnDefinitions.RemoveRange(chartGrid.ColumnDefinitions.Count - 2, 2);

				if (addedFirstRow && chartGrid.RowDefinitions.Count > 2)
					chartGrid.RowDefinitions.RemoveRange(chartGrid.RowDefinitions.Count - 3, 3);
				else if (chartGrid.RowDefinitions.Count > 0)
					chartGrid.RowDefinitions.RemoveRange(chartGrid.RowDefinitions.Count - 2, 2);
			}
		}

		protected void TopMenuItem1SubItem1_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M1I1 - Top menu subitem 1 selected", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void TopMenuItem1SubItem2_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M1I2 - Top menu subitem 2 selected", TextPosition.BottomLeft, Brushes.ForestGreen, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void TopMenuItem2_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "B1 - Top button clicked", TextPosition.BottomLeft, Brushes.OrangeRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			// only invalidate the chart so that the text box will appear even if there is no incoming data
			ChartControl.InvalidateVisual();
		}

		protected void LeftMenu1Item1SubItem1_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M2I1 - Left menu subitem 1 selected", TextPosition.BottomLeft, Brushes.DarkMagenta, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void LeftMenu1Item1SubItem2_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M2I2 - Left menu subitem 2 selected", TextPosition.BottomLeft, Brushes.DarkOrchid, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void LeftMenu2Item1_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "B2 - Left button clicked", TextPosition.BottomLeft, Brushes.MediumTurquoise, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartToolBarExample[] cacheChartToolBarExample;
		public ChartToolBarExample ChartToolBarExample()
		{
			return ChartToolBarExample(Input);
		}

		public ChartToolBarExample ChartToolBarExample(ISeries<double> input)
		{
			if (cacheChartToolBarExample != null)
				for (int idx = 0; idx < cacheChartToolBarExample.Length; idx++)
					if (cacheChartToolBarExample[idx] != null &&  cacheChartToolBarExample[idx].EqualsInput(input))
						return cacheChartToolBarExample[idx];
			return CacheIndicator<ChartToolBarExample>(new ChartToolBarExample(), input, ref cacheChartToolBarExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartToolBarExample ChartToolBarExample()
		{
			return indicator.ChartToolBarExample(Input);
		}

		public Indicators.ChartToolBarExample ChartToolBarExample(ISeries<double> input )
		{
			return indicator.ChartToolBarExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartToolBarExample ChartToolBarExample()
		{
			return indicator.ChartToolBarExample(Input);
		}

		public Indicators.ChartToolBarExample ChartToolBarExample(ISeries<double> input )
		{
			return indicator.ChartToolBarExample(input);
		}
	}
}

#endregion
