#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChangeQuantityExample : Indicator
	{
		private System.Windows.Controls.Grid	buttonGrid;
		private System.Windows.Controls.Button	changeButton;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ChangeQuantityExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null && !UserControlCollection.Contains(buttonGrid))
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveControls();
					}));
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		protected void OnButtonClick(object sender, RoutedEventArgs rea)
		{
			ChartControl.Dispatcher.InvokeAsync((Action)(() =>
			{
				NinjaTrader.Gui.Tools.QuantityUpDown quantitySelector = (Window.GetWindow(ChartControl.Parent).FindFirst("ChartTraderControlQuantitySelector") as NinjaTrader.Gui.Tools.QuantityUpDown);

				quantitySelector.Value = 5;
			}));
		}

		protected void InsertControls()
		{
			buttonGrid = new System.Windows.Controls.Grid
			{
				Name = "MyCustomGrid",
				HorizontalAlignment = HorizontalAlignment.Right,
				VerticalAlignment = VerticalAlignment.Top
			};

			System.Windows.Controls.ColumnDefinition column1 = new System.Windows.Controls.ColumnDefinition();

			buttonGrid.ColumnDefinitions.Add(column1);

			changeButton = new System.Windows.Controls.Button
			{
				Name = "ChangeQuantity",
				Content = "Change Quantity",
				Foreground = Brushes.White,
				Background = Brushes.Green
			};

			changeButton.Click += OnButtonClick;

			System.Windows.Controls.Grid.SetColumn(changeButton, 0);

			buttonGrid.Children.Add(changeButton);

			UserControlCollection.Add(buttonGrid);
		}

		protected void RemoveControls()
		{
			if (changeButton != null)
			{
				changeButton.Click -= OnButtonClick;
				buttonGrid.Children.Remove(changeButton);
				changeButton = null;
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChangeQuantityExample[] cacheChangeQuantityExample;
		public ChangeQuantityExample ChangeQuantityExample()
		{
			return ChangeQuantityExample(Input);
		}

		public ChangeQuantityExample ChangeQuantityExample(ISeries<double> input)
		{
			if (cacheChangeQuantityExample != null)
				for (int idx = 0; idx < cacheChangeQuantityExample.Length; idx++)
					if (cacheChangeQuantityExample[idx] != null &&  cacheChangeQuantityExample[idx].EqualsInput(input))
						return cacheChangeQuantityExample[idx];
			return CacheIndicator<ChangeQuantityExample>(new ChangeQuantityExample(), input, ref cacheChangeQuantityExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChangeQuantityExample ChangeQuantityExample()
		{
			return indicator.ChangeQuantityExample(Input);
		}

		public Indicators.ChangeQuantityExample ChangeQuantityExample(ISeries<double> input )
		{
			return indicator.ChangeQuantityExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChangeQuantityExample ChangeQuantityExample()
		{
			return indicator.ChangeQuantityExample(Input);
		}

		public Indicators.ChangeQuantityExample ChangeQuantityExample(ISeries<double> input )
		{
			return indicator.ChangeQuantityExample(input);
		}
	}
}

#endregion
