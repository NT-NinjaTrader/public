#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class aTestHLineOnLast : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "aTestHLineOnLast";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			Draw.HorizontalLine(this,"CurrentPrice", true, Close[0], Brushes.DarkGray, DashStyleHelper.DashDotDot, 1);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private aTestHLineOnLast[] cacheaTestHLineOnLast;
		public aTestHLineOnLast aTestHLineOnLast()
		{
			return aTestHLineOnLast(Input);
		}

		public aTestHLineOnLast aTestHLineOnLast(ISeries<double> input)
		{
			if (cacheaTestHLineOnLast != null)
				for (int idx = 0; idx < cacheaTestHLineOnLast.Length; idx++)
					if (cacheaTestHLineOnLast[idx] != null &&  cacheaTestHLineOnLast[idx].EqualsInput(input))
						return cacheaTestHLineOnLast[idx];
			return CacheIndicator<aTestHLineOnLast>(new aTestHLineOnLast(), input, ref cacheaTestHLineOnLast);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.aTestHLineOnLast aTestHLineOnLast()
		{
			return indicator.aTestHLineOnLast(Input);
		}

		public Indicators.aTestHLineOnLast aTestHLineOnLast(ISeries<double> input )
		{
			return indicator.aTestHLineOnLast(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.aTestHLineOnLast aTestHLineOnLast()
		{
			return indicator.aTestHLineOnLast(Input);
		}

		public Indicators.aTestHLineOnLast aTestHLineOnLast(ISeries<double> input )
		{
			return indicator.aTestHLineOnLast(input);
		}
	}
}

#endregion
