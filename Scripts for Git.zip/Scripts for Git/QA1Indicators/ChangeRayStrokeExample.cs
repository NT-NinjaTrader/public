#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChangeRayStrokeExample : Indicator
	{
        private int barCount;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"Draws a ray in historical data. Changes the color of the line to blue after the first bar close.";
				Name						= "ChangeRayStrokeExample";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive	= true;
				
				PrintTo						= PrintTo.OutputTab1;
			}
			else if (State == State.Historical)
			{
                barCount = BarsArray[0].Count;
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar == barCount-3)
				Draw.Ray(this, "rayTag", Time[10], High[10], Time[0], High[0], Brushes.Green, DashStyleHelper.Solid, 2);
		}

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            // here we wait for the first live bar to close
			if (CurrentBar == barCount-1)
			{
	            foreach (IDrawingTool draw in DrawObjects)
	            {
	                if (draw is Ray)
	                {
	                    Ray aRay = (Ray)draw;
                        // changes to drawing objects must be done while rendering.
	                    if (aRay.Stroke.Brush == Brushes.Green)
	                        aRay.Stroke = new Stroke() { Brush = Brushes.Blue, DashStyleHelper = DashStyleHelper.Dash, Width = 4 };
	                }
	            }
			}
        }

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChangeRayStrokeExample[] cacheChangeRayStrokeExample;
		public ChangeRayStrokeExample ChangeRayStrokeExample()
		{
			return ChangeRayStrokeExample(Input);
		}

		public ChangeRayStrokeExample ChangeRayStrokeExample(ISeries<double> input)
		{
			if (cacheChangeRayStrokeExample != null)
				for (int idx = 0; idx < cacheChangeRayStrokeExample.Length; idx++)
					if (cacheChangeRayStrokeExample[idx] != null &&  cacheChangeRayStrokeExample[idx].EqualsInput(input))
						return cacheChangeRayStrokeExample[idx];
			return CacheIndicator<ChangeRayStrokeExample>(new ChangeRayStrokeExample(), input, ref cacheChangeRayStrokeExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChangeRayStrokeExample ChangeRayStrokeExample()
		{
			return indicator.ChangeRayStrokeExample(Input);
		}

		public Indicators.ChangeRayStrokeExample ChangeRayStrokeExample(ISeries<double> input )
		{
			return indicator.ChangeRayStrokeExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChangeRayStrokeExample ChangeRayStrokeExample()
		{
			return indicator.ChangeRayStrokeExample(Input);
		}

		public Indicators.ChangeRayStrokeExample ChangeRayStrokeExample(ISeries<double> input )
		{
			return indicator.ChangeRayStrokeExample(input);
		}
	}
}

#endregion
