#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ParametersOrderedByOrder : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ParametersOrderedByOrder";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		[NinjaScriptProperty]
		[Display(Name="A", Description="A", Order=2, GroupName="Parameters")]
		public bool A
		{ get; set; }
		
		
		
			[NinjaScriptProperty]
		[Display(Name="B", Description="B", Order=0, GroupName="Parameters")]
		public bool B
		{ get; set; }
		
		
			[NinjaScriptProperty]
		[Display(Name="C", Description="C", Order=1, GroupName="Parameters")]
		public bool C
		{ get; set; }
		
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ParametersOrderedByOrder[] cacheParametersOrderedByOrder;
		public ParametersOrderedByOrder ParametersOrderedByOrder(bool a, bool b, bool c)
		{
			return ParametersOrderedByOrder(Input, a, b, c);
		}

		public ParametersOrderedByOrder ParametersOrderedByOrder(ISeries<double> input, bool a, bool b, bool c)
		{
			if (cacheParametersOrderedByOrder != null)
				for (int idx = 0; idx < cacheParametersOrderedByOrder.Length; idx++)
					if (cacheParametersOrderedByOrder[idx] != null && cacheParametersOrderedByOrder[idx].A == a && cacheParametersOrderedByOrder[idx].B == b && cacheParametersOrderedByOrder[idx].C == c && cacheParametersOrderedByOrder[idx].EqualsInput(input))
						return cacheParametersOrderedByOrder[idx];
			return CacheIndicator<ParametersOrderedByOrder>(new ParametersOrderedByOrder(){ A = a, B = b, C = c }, input, ref cacheParametersOrderedByOrder);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ParametersOrderedByOrder ParametersOrderedByOrder(bool a, bool b, bool c)
		{
			return indicator.ParametersOrderedByOrder(Input, a, b, c);
		}

		public Indicators.ParametersOrderedByOrder ParametersOrderedByOrder(ISeries<double> input , bool a, bool b, bool c)
		{
			return indicator.ParametersOrderedByOrder(input, a, b, c);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ParametersOrderedByOrder ParametersOrderedByOrder(bool a, bool b, bool c)
		{
			return indicator.ParametersOrderedByOrder(Input, a, b, c);
		}

		public Indicators.ParametersOrderedByOrder ParametersOrderedByOrder(ISeries<double> input , bool a, bool b, bool c)
		{
			return indicator.ParametersOrderedByOrder(input, a, b, c);
		}
	}
}

#endregion
