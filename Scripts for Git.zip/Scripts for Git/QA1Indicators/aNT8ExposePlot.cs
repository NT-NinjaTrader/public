// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
    public class aNT8ExposePlot : Indicator
    {
		private Series<double> bearIndication;
		private Series<double> bullIndication;
		
		/// <summary>
		/// To add this indicator to the market analyzer Add Column>Select
		/// </summary>
		
        protected override void OnStateChange()
        {
			if(State == State.SetDefaults)
			{
				Name					= "aNT8ExposePlot";
	            Calculate				= Calculate.OnBarClose;
	            IsOverlay				= true;
			}
			
			else if(State == State.Configure)
			{
	
			
			}
	
			else if(State ==State.DataLoaded)
			{
				bearIndication 			= new Series<double>(this);
				bullIndication			= new Series<double>(this);
			}
        }
		

        protected override void OnBarUpdate()
        {
//	if(State==State.Historical) return;
		  if (bullIndication == null) bullIndication = new Series<double>(this);
          if (bearIndication == null) bearIndication = new Series<double>(this);
			
	
			if (bullIndication == null)
            bullIndication[0] = High[0];
			 
			 if (bearIndication == null) 
            bearIndication[0] = Low[0];
		
        }

		// Important code segment in the Properties section. Please expand to view.
        #region Properties
		// Creating public properties that access our internal Series<bool> allows external access to this indicator's Series<bool>
//		[Browsable(false)]
		[XmlIgnore]
        public Series <double> BearIndication
        {
            get { return bearIndication; }	// Allows our public BearIndication Series<bool> to access and expose our interal bearIndication Series<bool>
        }
		
		[Browsable(false)]
		[XmlIgnore]		
        public Series < double> BullIndication
        {
            get { return bullIndication; }	// Allows our public BullIndication Series<bool> to access and expose our interal bullIndication Series<bool>
        }


        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private aNT8ExposePlot[] cacheaNT8ExposePlot;
		public aNT8ExposePlot aNT8ExposePlot()
		{
			return aNT8ExposePlot(Input);
		}

		public aNT8ExposePlot aNT8ExposePlot(ISeries<double> input)
		{
			if (cacheaNT8ExposePlot != null)
				for (int idx = 0; idx < cacheaNT8ExposePlot.Length; idx++)
					if (cacheaNT8ExposePlot[idx] != null &&  cacheaNT8ExposePlot[idx].EqualsInput(input))
						return cacheaNT8ExposePlot[idx];
			return CacheIndicator<aNT8ExposePlot>(new aNT8ExposePlot(), input, ref cacheaNT8ExposePlot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.aNT8ExposePlot aNT8ExposePlot()
		{
			return indicator.aNT8ExposePlot(Input);
		}

		public Indicators.aNT8ExposePlot aNT8ExposePlot(ISeries<double> input )
		{
			return indicator.aNT8ExposePlot(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.aNT8ExposePlot aNT8ExposePlot()
		{
			return indicator.aNT8ExposePlot(Input);
		}

		public Indicators.aNT8ExposePlot aNT8ExposePlot(ISeries<double> input )
		{
			return indicator.aNT8ExposePlot(input);
		}
	}
}

#endregion
