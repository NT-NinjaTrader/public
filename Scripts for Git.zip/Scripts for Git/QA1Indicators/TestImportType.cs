#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Data;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.ImportTypes;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class TestShareService : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "TestShareService";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Historical)
			{
				ImportType selectedItem = new TextImportType();

				selectedItem.SetState(State.SetDefaults);
				selectedItem.SetState(State.Configure);
				foreach (var timeZoneInfo in Globals.TimeZoneInfoDictionary)
				{
					Print(timeZoneInfo.Key);
				}
				

					selectedItem.Import(MarketDataType.Last, Globals.TimeZoneInfoDictionary["Central Pacific Standard Time"], false,false, null);

			
			}
		}

		protected override void OnBarUpdate()
		{
			 
                 
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TestShareService[] cacheTestShareService;
		public TestShareService TestShareService()
		{
			return TestShareService(Input);
		}

		public TestShareService TestShareService(ISeries<double> input)
		{
			if (cacheTestShareService != null)
				for (int idx = 0; idx < cacheTestShareService.Length; idx++)
					if (cacheTestShareService[idx] != null &&  cacheTestShareService[idx].EqualsInput(input))
						return cacheTestShareService[idx];
			return CacheIndicator<TestShareService>(new TestShareService(), input, ref cacheTestShareService);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TestShareService TestShareService()
		{
			return indicator.TestShareService(Input);
		}

		public Indicators.TestShareService TestShareService(ISeries<double> input )
		{
			return indicator.TestShareService(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TestShareService TestShareService()
		{
			return indicator.TestShareService(Input);
		}

		public Indicators.TestShareService TestShareService(ISeries<double> input )
		{
			return indicator.TestShareService(input);
		}
	}
}

#endregion
