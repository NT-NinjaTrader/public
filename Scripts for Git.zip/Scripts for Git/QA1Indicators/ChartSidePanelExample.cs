#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartSidePanelExample : Indicator
	{
		private System.Windows.Controls.Grid	chartGrid, buttonGrid;
		private System.Windows.Controls.Button	button1, button2;
		private ChartTrader						chartTraderControl;
		
	
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"Enter the description for your new custom Indicator here.";
				Name						= "ChartSidePanelExample";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive	= true;
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.Historical)
			{ 
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}
			}
		}
			
		

		private int myCurrentBar = 0;
		
		protected override void OnBarUpdate()
		{
			myCurrentBar = CurrentBar;

		}

		protected void Button1_Click(object sender, RoutedEventArgs e)
		{

			//Draw.TextFixed(this, "infobox", "Button 1 clicked", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			Draw.Rectangle(this, "Rec",   Bars.GetTime(myCurrentBar-10), Bars.GetLow(myCurrentBar-10), Bars.GetTime(myCurrentBar), Bars.GetHigh(myCurrentBar), Brushes.Red);
		
			// dont use this, this == crashes
			//ChartControl.InvalidateVisual();
			
			//do this instead
			Draw.ArrowUp(this, "dummy", false, 0,0,Brushes.Transparent);
			RemoveDrawObject("dummy");
		}


		protected void Button2_Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 2 clicked", TextPosition.BottomLeft, Brushes.DarkRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}


		protected void InsertWPFControls()
		{
			chartTraderControl = Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader;
			chartGrid = chartTraderControl.Parent as System.Windows.Controls.Grid;
// why does chartGrid.ColumnDefinitions.Insert(chartGrid.ColumnDefinitions.Count - 1, new System.Windows.Controls.ColumnDefinition() { Width = new GridLength(100) }); cause the column to be overwritten instead of added?

			// a new column is added to the right of the chart
			chartGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			// width of new column is set to the chartTrader's column width
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1].Width = chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width;
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width = new GridLength(100);
			// chartTrader is moved to the new column (our column space is now the old chartTrader column)
			System.Windows.Controls.Grid.SetColumn(chartTraderControl, chartGrid.ColumnDefinitions.Count - 1);

			buttonGrid = new System.Windows.Controls.Grid();
			chartGrid.Children.Add(buttonGrid);
			System.Windows.Controls.Grid.SetColumn(buttonGrid, chartGrid.ColumnDefinitions.Count - 2);
			System.Windows.Controls.Grid.SetRow(buttonGrid, System.Windows.Controls.Grid.GetRow(chartTraderControl));

			buttonGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(50) });
			buttonGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition() { Height = new GridLength(50) });

			button1 = new System.Windows.Controls.Button()
			{
				Content = "Button 1"
			};
			button1.Click += Button1_Click;

			button2 = new System.Windows.Controls.Button()
			{
				Content = "Button 2",
			};
			button2.Click += Button2_Click;

			buttonGrid.Children.Add(button1);
			buttonGrid.Children.Add(button2);
			System.Windows.Controls.Grid.SetRow(button2, 1);
		}

		protected void RemoveWPFControls()
		{
			button1.Click -= Button1_Click;
			button2.Click -= Button2_Click;

			chartGrid.Children.Remove(buttonGrid);
			System.Windows.Controls.Grid.SetColumn(chartTraderControl, chartGrid.ColumnDefinitions.Count - 2);

			
			///Removing from b9ottom, adding to bottom, easier.
			chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 2].Width = chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1].Width;
			chartGrid.ColumnDefinitions.Remove(chartGrid.ColumnDefinitions[chartGrid.ColumnDefinitions.Count - 1]);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartSidePanelExample[] cacheChartSidePanelExample;
		public ChartSidePanelExample ChartSidePanelExample()
		{
			return ChartSidePanelExample(Input);
		}

		public ChartSidePanelExample ChartSidePanelExample(ISeries<double> input)
		{
			if (cacheChartSidePanelExample != null)
				for (int idx = 0; idx < cacheChartSidePanelExample.Length; idx++)
					if (cacheChartSidePanelExample[idx] != null &&  cacheChartSidePanelExample[idx].EqualsInput(input))
						return cacheChartSidePanelExample[idx];
			return CacheIndicator<ChartSidePanelExample>(new ChartSidePanelExample(), input, ref cacheChartSidePanelExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartSidePanelExample ChartSidePanelExample()
		{
			return indicator.ChartSidePanelExample(Input);
		}

		public Indicators.ChartSidePanelExample ChartSidePanelExample(ISeries<double> input )
		{
			return indicator.ChartSidePanelExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartSidePanelExample ChartSidePanelExample()
		{
			return indicator.ChartSidePanelExample(Input);
		}

		public Indicators.ChartSidePanelExample ChartSidePanelExample(ISeries<double> input )
		{
			return indicator.ChartSidePanelExample(input);
		}
	}
}

#endregion
