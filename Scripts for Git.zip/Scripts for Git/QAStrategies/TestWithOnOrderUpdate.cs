#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion


namespace NinjaTrader.NinjaScript.Strategies
{
	public class TestWithOnOrderUpdate : Strategy
	{
        
        protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is a template for Unmanaged strategies that can be used as reference for developing your own Unmanaged strategy.";
				Name										= "TestWithOnOrderUpdate NT8 Scenario";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				IsUnmanaged 								= true;
				IsAdoptAccountPositionAware 				= true;
                IsInstantiatedOnEachOptimizationIteration	= true;
            }
			else if (State == State.Realtime)
			{
                if (_entryOrder != null)
                    _entryOrder = GetRealtimeOrder(_entryOrder);
				if(_exitMarketOrder != null)
					_exitMarketOrder = GetRealtimeOrder(_exitMarketOrder);
            }
		}

		protected override void OnBarUpdate()
        {
            if (CurrentBar < 1)
                return;

            if (Close[0] > Open[1] && Position.MarketPosition == MarketPosition.Flat)
            {
                PlaceEntryOrder(High[0] + TickSize*10);
            }
            if (Close[0] < Open[1] && Position.MarketPosition == MarketPosition.Long)
            {
                ClosePosition();
            }
		}

        private Order _entryOrder;
        private Order _exitMarketOrder;
		private const string EnterLongName = "EntryLong";
        private const string MarketExitLongName = "Market Exit Long";

		private void PlaceEntryOrder(double price)
        {
//            if (_entryOrder != null)
//            {
//                CancelOrder(_entryOrder);
//            }

			if (_entryOrder == null)
            	_entryOrder = SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, 1, 0, price, "", EnterLongName);
			else
				ChangeOrder(_entryOrder, 1, 0, price);
		}

        private void ClosePosition()
        {
            _exitMarketOrder = SubmitOrderUnmanaged(0, OrderAction.Sell,
                OrderType.Market, 1, 0, 0, "", MarketExitLongName);
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, 
            double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
			if (execution.Order.OrderState != OrderState.Filled)
                return;

            if (execution.Order.Name == MarketExitLongName)
            {
				PlaceEntryOrder(High[0] + TickSize * 10);
			}
		}
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			if (order == _entryOrder && Order.IsTerminalState(_entryOrder.OrderState))
				_entryOrder = null;
			if (order == _exitMarketOrder && Order.IsTerminalState(_exitMarketOrder.OrderState))
				_exitMarketOrder = null;
		}
		
		
	}
}
