#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class Submit3OrdersThenCancelOverAndOverUnmanaged : Strategy
	{
		private Order entryOrder = null;
		private bool xOrderFilled;
		private bool xMoved;
		private int xCurrentBar;
		

		private Order entryOrder2 = null;
	private Order entryOrder3 = null;
		private bool xMoved2;
		private int xCurrentBar2;
	private bool xMoved3;
		private int xCurrentBar3;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "Submit3OrdersThenCancelOverAndOverUnmanaged";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
					IsUnmanaged = true;
			}
			else if (State == State.Configure)
			{
				xMoved=false;
				 movedOrder=false;
 CanceledOrder=false;
				
				xMoved2=false;
				 movedOrder2=false;
 CanceledOrder2=false;
			}
		}
		
		//This strategy will submit an entry order and if that limit order is not filled in
		//60 seconds.  Of course the time series this is applied to woudl have to be less than 60 seconds otherwise it would be 
		//on the next bar close...unless this was COBC==false.

		protected override void OnBarUpdate()
		{
			
			if(State == State.Historical) return;
			if(CurrentBar<10) return;
			
		    if (xMoved == false)
			{
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 50 *TickSize,0,"", "BuyentryOrder");
	
			//	EnterShortLimit(0, true, 0, High[0]+30*TickSize, "myEntryOrder"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
				xMoved =true;
				xCurrentBar = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
				CanceledOrder=false;
			
			} 
			else if(CurrentBar> xCurrentBar +2)
				{
					if(CanceledOrder == false)
					{
						Print("Canceling order BuyentryOrder");
						CancelOrder(entryOrder);
					CanceledOrder=true;
						
					}
				}
			
			
			
		    if (xMoved2 == false)
			{
							
				SubmitOrderUnmanaged(0, OrderAction.SellShort, OrderType.Limit, 1,  GetCurrentAsk(0) + 50 *TickSize,0,"", "Sell1");
	
			//	EnterShortLimit(0, true, 0, High[0]+20*TickSize, "myEntryOrder2"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
				xMoved2 =true;
				xCurrentBar2 = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
				CanceledOrder2=false;
			
			} 
			else if(CurrentBar> xCurrentBar2+2)
			{
				if(CanceledOrder2 == false)
				{
					Print("Canceling order myEntryOrder2");
					CancelOrder(entryOrder2);
				CanceledOrder2=true;
					
				}
			
			
			}

            if (xMoved3 == false)
            {

                SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, 1, 0, GetCurrentAsk(0) + 50 * TickSize, "", "BuyStop1");

                //	EnterShortLimit(0, true, 0, High[0]+20*TickSize, "myEntryOrder2"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
                xMoved3 = true;
                xCurrentBar3 = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
                CanceledOrder3 = false;

            }
            else if (CurrentBar > xCurrentBar3 + 2)
            {
                if (CanceledOrder3 == false)
                {
                    Print("Canceling order BuyStop1");
                    CancelOrder(entryOrder3);
                    CanceledOrder3 = true;

                }

            }


        }
		bool movedOrder		=	false;
		bool CanceledOrder	=	false;
	
			bool movedOrder2		=	false;
		bool CanceledOrder2	=	false;
		bool movedOrder3		=	false;
		bool CanceledOrder3=	false;
			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			


			
	
			if (order.Name =="BuyStop1" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				Print("BuyStop1 assigned");
					
				entryOrder3 = order;
			
				
			}
			
			if (order.Name == "BuyStop1" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
					Print("BuyStop1 set to null");
			xMoved3=false;
				entryOrder3 = null;  //Should I do this here?

	
			}
			

			if (order.Name =="BuyentryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				Print("BuyentryOrder assigned");
					
				entryOrder = order;
			
				
			}
			
			if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
					
				Print("BuyentryOrder set to null");
		
				xMoved=false;
				entryOrder = null;  //Should I do this here?

	
			}
			
			
			if (order.Name =="Sell1" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				Print("Sell1 assigned");
				
				entryOrder2 = order;
			
				
			}
			
			if (order.Name == "Sell1" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
				
				Print("Sell1 set to null");
		
				xMoved2=false;
				entryOrder2 = null;  //Should I do this here?

	
			}
		}


	}
}
