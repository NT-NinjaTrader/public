#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class SubmitMarketOrderThenTryCanceling : Strategy
	{
		private Order entryOrder = null;
		private bool xOrderFilled;
		private bool xMoved;
		private int xCurrentBar;
		

		private Order entryOrder2 = null;
	private Order entryOrder3 = null;
		private bool xMoved2;
		private int xCurrentBar2;
	private bool xMoved3;
		private int xCurrentBar3;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SubmitMarketOrderThenTryCanceling";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
					IsUnmanaged = true;
			}
			else if (State == State.Configure)
			{
				xMoved=false;
				 movedOrder=false;
 CanceledOrder=false;
				
				xMoved2=false;
				 movedOrder2=false;
 CanceledOrder2=false;
			}
		}
		
		//This strategy will submit an entry order and if that limit order is not filled in
		//60 seconds.  Of course the time series this is applied to woudl have to be less than 60 seconds otherwise it would be 
		//on the next bar close...unless this was COBC==false.

		protected override void OnBarUpdate()
		{
			
			if(State == State.Historical) return;
			if(CurrentBar<10) return;
			
		    if (xMoved == false)
			{
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market,1, 5,0,"", "BuyentryOrder");
	
			//	EnterShortLimit(0, true, 0, High[0]+30*TickSize, "myEntryOrder"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
				xMoved =true;
				xCurrentBar = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
				CanceledOrder=false;
			
			} 
			else if(CurrentBar> xCurrentBar +1)
				if(entryOrder!=null)
				{
					Print("Calling cancel");
							CancelOrder(entryOrder);
				}
		
			
		


        }
		bool movedOrder		=	false;
		bool CanceledOrder	=	false;
	
			bool movedOrder2		=	false;
		bool CanceledOrder2	=	false;
		bool movedOrder3		=	false;
		bool CanceledOrder3=	false;
			
		protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
			   Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);

			
		}
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			Print(order.OrderId+"__"+order.OrderState.ToString());
		
			if (order.Name =="BuyentryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				Print("BuyentryOrder assigned");
					
				entryOrder = order;
			}
	
			if (order.Name =="BuyentryOrder" && order.OrderState == OrderState.Filled)
			{
				//   SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, order.AverageFillPrice -50 *TickSize, "", "SellStop");
				//   SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, 1, 0, order.AverageFillPrice +50 *TickSize, "", "LimitSell");
			
			
				SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, 1,  order.AverageFillPrice + 50 * TickSize,0, "", "SellLimitOrder");
            
				SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, order.AverageFillPrice - 50 * TickSize, "", "SellStopOrder");

			}
                
//			filledCounterOrderUpdate = filledCounterOrderUpdate + quantity;
//			if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
//			{
				
					
//				Print("BuyentryOrder set to null");
		
//				xMoved=false;
//				entryOrder = null;  //Should I do this here?

	
//			}
			
		
		}


	}
}
