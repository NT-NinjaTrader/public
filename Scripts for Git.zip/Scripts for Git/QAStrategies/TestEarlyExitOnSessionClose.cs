#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class TestEarlyExitOnSessionClose : Strategy
	{
        private RSI rsi;
        private StreamWriter _LogWriter = null;
        private DateTime _TheTime = DateTime.MinValue;

        private void WriteLog(string line, int bip = -1)
        {
            return;

            if (_LogWriter != null)
            {
                _LogWriter.WriteLine(line);
            }
            else
            {
                System.Diagnostics.Trace.WriteLine(line);
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sample code showing early Exit On Session Close";
                Name = "TestEarlyExitOnSessionClose";

                Calculate = Calculate.OnEachTick;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                IncludeTradeHistoryInBacktest = true;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false; // NOTE: Should only be TRUE when testing
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 14;

                // This strategy has been designed to take advantage of performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
            }
            else if (State == State.Configure)
            {
                //String basePath = "D:\\logs\\";
                //Directory.CreateDirectory(basePath);
                //String logFilePath = System.IO.Path.Combine(basePath, String.Format("{0:yyyyMMddHHmmss}", DateTime.Now) + ".log");
                //_LogWriter = new StreamWriter(logFilePath);

                _TheTime = new DateTime(2021, 09, 09, 12, 8, 0);

                SetStopLoss("testOrder", CalculationMode.Ticks, 10, false);
                AddDataSeries(Data.BarsPeriodType.Tick, 1);
                AddDataSeries(Data.BarsPeriodType.Minute, 60 * 4); // 4 hours
            }
            else if (State == State.DataLoaded)
            {
                rsi = RSI(BarsArray[2], 1, 3);
            }
            else if (State == State.Terminated)
            {
                if (_LogWriter != null)
                {
                    _LogWriter.Flush();
                    _LogWriter.Close();
                }
            }
        }

		protected override void OnBarUpdate()
		{
			if (BarsInProgress == 0 && CurrentBar < BarsRequiredToTrade)
				return;

            if ((BarsInProgress == 0 && IsFirstTickOfBar) || BarsInProgress != 0)
            {
                WriteLog(String.Format("{0:dd/MM/yyyy HH:mm:ss.ffffff}", Bars.GetTime(CurrentBar)) + " BP=" + BarsPeriods[BarsInProgress].BarsPeriodType.ToString() + "-" + BarsPeriods[BarsInProgress].Value.ToString() + ", " + Calculate.ToString() + ", BIP=" + BarsInProgress + ", CurBar=" + CurrentBar + ", 1stTick=" + (IsFirstTickOfBar ? "Y" : "N") + ", O=" + Bars.GetOpen(CurrentBar) + ", H=" + Bars.GetHigh(CurrentBar) + ", L=" + Bars.GetLow(CurrentBar) + ", C=" + Bars.GetClose(CurrentBar) + (BarsInProgress == 2 && CurrentBars[2] > 0 ? ", rsi=" + rsi[0] : string.Empty));
            }

            if (BarsInProgress == 0 && IsFirstTickOfBar && CurrentBars[2] > 2)
            {
                double startVal = rsi[0];
                double endVal = rsi[1];
                double slope = Slope(rsi, 1, 0);
                double angle = Math.Atan(slope) * 180 / Math.PI;

                if (Bars.GetTime(CurrentBar) == _TheTime)
                {
                    if (Position.MarketPosition == MarketPosition.Flat)
                        EnterLong(1, 1, "testOrder");
                }
            }
		}

        protected override void OnOrderTrace(DateTime timestamp, string message)
        {
            WriteLog(string.Format("{0} OnOrderTrace: {1}", String.Format("{0:dd/MM/yyyy HH:mm:ss.ffffff}", timestamp), message));
        }

        protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
        {
            WriteLog(String.Format("{0:dd/MM/yyyy HH:mm:ss.ffffff}", Bars.GetTime(CurrentBar)) + " OnOrderUpdate: " + order.ToString());
        }

        protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
            WriteLog(String.Format("{0:dd/MM/yyyy HH:mm:ss.ffffff}", Bars.GetTime(CurrentBar)) + " OnExecutionUpdate: " + execution.ToString());
        }
	}
}
