#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class OnPositionUpdateSubmitSLTP : Strategy
    {


        //Apply to 5 second chart, MYM
        /*
			Goes long, submits PT/SL in OnPositionUpdate, then closes 3 bars later if no error.
		
			The error here is OnPositionUpdate not firing on entry order.  https://ninjatrader.atlassian.net/browse/NTEIGHT-15078
		
		Wait till error goes off, this find when OnPositionupdate is not fired.
		
		
		 * */


        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "OnPositionUpdateSubmitSLTP";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
            }
            else if (State == State.Configure)
            {
				   filledCounterExecution = 0;
                filledCounterOrderUpdate = 0;
                triggeredError = false;
                OPUCalled = false;
                orderSentOn = 0;
                doonce = false;
                restartBar = 0;
            }
        }
       int filledCounterExecution;
        int filledCounterOrderUpdate;
        private bool doonce;
        bool triggeredError;

        int orderSentOn;
        protected override void OnBarUpdate()
        {			
			if(triggeredError == true) 
			{
				Print("ERRORRRR HIT, returning to exam if PT/SL are working");
				return;
            
			}
			
            if (State == State.Realtime && doonce ==false)
            {
                orderSentOn = CurrentBar;
                triggeredError = false;
                OPUCalled = false;
                EnterLong("TestLong");
                doonce = true;
            }
            else
            {
                if (doonce == true)
                {

                    if (OPUCalled == false)
                    {
                        if (CurrentBar > orderSentOn) //wait 15 seconds

                            if (triggeredError == false)
                            {

                                triggeredError = true;
								
								Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed a position update"+"__"+Name+"__"+Instruments[0].FullName);
								
								
                                Task.Run(() => MessageBox.Show("Hit Issue, OnPositionUpdate not called on entry order,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));


                            }
                    }



                    else
                    {
                        if (restartBar + 5 > CurrentBar && OPUCalled == true)
                        {

                            ExitLong("TestLong");
                            doonce = false;
                            restartBar = 0;

                        }
                    }
                }

            }
        }
        int restartBar = 0;
        bool OPUCalled;
		
	
        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
			Print("OPU");
			
            if (position.MarketPosition == MarketPosition.Long)
            {
                ExitLongLimit(0, true, Position.Quantity, averagePrice + 50, "TestLongProfit", "TestLong");
                ExitLongStopMarket(0, true, Position.Quantity, averagePrice - 50, "TestLongSL", "TestLong");

                restartBar = CurrentBar;


            }
            OPUCalled = true;
            Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);
        }
 
	
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {
            Print("OOU " + order.OrderState + "__" + order.OrderType + "_" + order.AverageFillPrice);

            if (order.OrderState == OrderState.Filled)
                filledCounterOrderUpdate = filledCounterOrderUpdate + quantity;
		}
   
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
            filledCounterExecution = filledCounterExecution + quantity;

        }

    }
}
