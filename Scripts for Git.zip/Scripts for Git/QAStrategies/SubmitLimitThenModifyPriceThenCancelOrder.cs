#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class SubmitLimitThenModifyPriceThenCancelOrder : Strategy
	{
		private Order entryOrder = null;
		private bool xOrderFilled;
		private bool xMoved;
		private int xCurrentBar;
		
		private DateTime xSentTime;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SubmitLimitThenModifyPriceThenCancelOrder";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				xMoved=false;
				 movedOrder=false;
 CanceledOrder=false;
				
			}
		}
		
		//This strategy will submit an entry order and if that limit order is not filled in
		//60 seconds.  Of course the time series this is applied to woudl have to be less than 60 seconds otherwise it would be 
		//on the next bar close...unless this was COBC==false.

		protected override void OnBarUpdate()
		{
			
			if(State == State.Historical) return;
			if(CurrentBar<10) return;
			
		    if (xMoved != true)
			{
				EnterLongLimit(0, true, 0, Low[0]-22*TickSize, "myEntryOrder"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
				xMoved =true;
				xCurrentBar = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
				
			
			}
			
		
			else
			{
				Print("Order Not Filled");
				if(movedOrder == false)
				{
					if(CurrentBar> xCurrentBar+3)
						
					{
						movedOrder=true;
						ChangeOrder(entryOrder, 1, Low[0]-80*TickSize, 0); //Will adjust working limit to 10 ticks from current low.
						Print("Order Changed");
					}
				}
				if(movedOrder)
				{
					if(CurrentBar> xCurrentBar+4)
					{
						if(CanceledOrder == false)
						{
							
						CancelOrder(entryOrder);
					CanceledOrder=true;
						}
					}
				}
				
			}
			
		}
		bool movedOrder		=	false;
		bool CanceledOrder	=	false;
	
		
			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
					
					Print("Unable To Change Order");

				}
			}


	

			if (order.Name =="myEntryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				Print("myEntryOrder assigned");
					entryOrder = order;
			
				
			}
			
			if (order.Name == "myEntryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
			
				entryOrder = null;  //Should I do this here?

	
			}
		}


	}
}
