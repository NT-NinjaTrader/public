#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class IBMissingPositionUpdate2OrdersDiffInstruments : Strategy
    {

		
		/*
			Displays a popup for missed order update.
		
			Goes Long 1 in BIP0, and Long 1 in BIP1, then reverses.  Will submit stop for each position.
		
			Will send a pop up if we miss an order update.
		*/
		
		
        private bool doOnce = true;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "IBMissingPositionUpdate2OrdersDiffInstruments";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 5;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
                IsUnmanaged = true;
				OutputWindow2=false;
            }
            else if (State == State.Configure)
            {
				orderQ=0;
//				SetStopLoss(CalculationMode.Ticks, 20);
                orderCounter = 0;
                AddDataSeries("ES 12-22");
//                AddDataSeries("NQ 09-22");
//                AddDataSeries("RTY 09-22");

              //  waitingPositionUpdate_0 = false;

                waitingPositionUpdate_1 = false;
                Golong_BIP1 = false;

                waitingPositionUpdate_2 = false;
waitingForSubmissionBIP0=false;

            }
        }

        int orderCounter;
        string orderName0;
        string orderName1;
        string orderName2;
int orderQ;

        bool waitingPositionUpdate_1;


        bool waitingPositionUpdate_2;

        int barSubmission = 0;

        bool Golong_BIP1;
		int positionUpdateCounter;
        protected override void OnBarUpdate()
        {

            //Format before submission!!!!!!!!!!!  VS, 
            if (State != State.Realtime)
                return;
			
			if(BarsInProgress!=0) return;

            orderCounter++;

            if (CurrentBar > barSubmission)
            {

                barSubmission = CurrentBar + 1;
				
				
				
                if (positionUpdateCounter == 0)
                {

					if(OutputWindow2)
					{
						NinjaTrader.Code.Output.Process("______________________________ ", PrintTo.OutputTab2);			
					}						
					else
					{
						Print("______________________________");
					}

                    if (Golong_BIP1)
                    {
						if(orderQ==0)
							orderQ=1;
						else if(orderQ == 1)
							orderQ=2;
						
						
                        Golong_BIP1 = false;
                        orderName0 = "Buy" + Instruments[1].FullName + orderCounter+"1";
                     	positionUpdateCounter++;
						SubmitOrderUnmanaged(1, OrderAction.Buy, OrderType.Market, orderQ, 0, 0, "", orderName0);
						    
					
						orderName1 = "Buy" + Instruments[0].FullName + orderCounter+"2";
						positionUpdateCounter++;
						SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, orderQ, 0, 0, "", orderName1);


                    }
                    else
                    {
						
						if(orderQ==0)
							orderQ=1;
						else if(orderQ == 1)
							orderQ=2;
						 
                        Golong_BIP1 = true;
                        orderName0 = "Sell" + Instruments[1].FullName + orderCounter+"1";
						positionUpdateCounter++;
                        SubmitOrderUnmanaged(1, OrderAction.Sell, OrderType.Market, orderQ, 0, 0, "", orderName0);
						
						orderName1 = "Sell" + Instruments[0].FullName + orderCounter+"2";
						positionUpdateCounter++;
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, orderQ, 0, 0, "", orderName1);
                    }
                }
                else
                {					
						
					if(positionUpdateCounter>0)
					{
							if(OutputWindow2)
							{
										
								Task.Run(() => MessageBox.Show("Missed Position Update, Output Window 2,", "BAD!", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));
					
								Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed a position update"+"__"+Name+"__"+Instruments[0].FullName);
								
								NinjaTrader.Code.Output.Process("ERRORRRR HIT!!!!!!!!!!!!!!!!!!! "+"__"+Name+"__"+Instruments[0].FullName, PrintTo.OutputTab2);					
					

							}
							else
							{
									Task.Run(() => MessageBox.Show("Missed Position Update, Output Window 1,", "BAD!", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));
	
								Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed a position update"+"__"+Name+"__"+Instruments[0].FullName);
				
							}
							
							
                   
							if (waitingForFill_0)  		
							{
							   
								if(OutputWindow2)
								{										
								
									NinjaTrader.Code.Output.Process("Error waitingForFill_0, missed OnOrderUpdate", PrintTo.OutputTab2);
								}
								else
								{										  
									Print("Error waitingForFill_0, missed OnOrderUpdate");	                     
							
								}							
	
							}		 
							if (waitingForFill_1)  								
							{								
									if(OutputWindow2)
									{								 
										NinjaTrader.Code.Output.Process("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed OnOrderUpdate update.   waitingForFill_1 true", PrintTo.OutputTab2);					
													
									}
									else
									{									  
										Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed a OnOrderUpdate update.   waitingForFill_1 true");

									}
									
							}    
					}
				}         	
			}
        }


        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {

		 Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);

			
	
            if (position.Instrument.FullName == Instruments[0].FullName)
            {
				
            	if(Golong_BIP1 ==false)
				{
					if(BuyStopBIP0!= null)
						CancelOrder(BuyStopBIP0);
					
					
							
					if(SellStopBIP0==null)
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, GetCurrentBid() - 20*TickSize, "", "SellStopBIP0");
					
				
				
				}
				else
				{	
						
					if(SellStopBIP0!= null)
						CancelOrder(SellStopBIP0);
						
					if(BuyStopBIP0==null)
						SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, 1, 0, GetCurrentAsk() + 20*TickSize, "", "BuyStopBIP0");
							
				
					
				}
				
				positionUpdateCounter--;
            }
 
			if (position.Instrument.FullName == Instruments[1].FullName)
            {
            
				if(Golong_BIP1 ==false)
				{
					if(BuyStopBIP1!= null)
						CancelOrder(BuyStopBIP1);
					
					
							
					if(SellStopBIP1==null)
						SubmitOrderUnmanaged(1, OrderAction.Sell, OrderType.StopMarket, 1, 0, GetCurrentBid() - 20*TickSize, "", "SellStopBIP1");
					
				
				
				}
				else
				{	
						
					if(SellStopBIP1!= null)
						CancelOrder(SellStopBIP1);
						
					if(BuyStopBIP1==null)
						SubmitOrderUnmanaged(1, OrderAction.Buy, OrderType.StopMarket, 1, 0, GetCurrentAsk() + 20*TickSize, "", "BuyStopBIP1");
							
				
					
				}
				
				
				positionUpdateCounter--;
            }
	
			if(OutputWindow2)
				  NinjaTrader.Code.Output.Process("onPositionUpdate", PrintTo.OutputTab2);
			else					
				Print("onPositionUpdate");



        }
        bool waitingForSubmissionBIP0;
		   bool waitingForSubmissionBIP1;
			   bool waitingForSubmissionBIP2;
        bool waitingForFill_0;

        bool waitingForFill_1;
        bool waitingForFill_2;
		
		Order SellStopBIP0, SellStopBIP1, BuyStopBIP0, BuyStopBIP1;
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {

           
			if (order.Name == "SellStopBIP0" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {


            //    Print("myEntryOrder assigned");
                SellStopBIP0 = order;


            }

			if (order.Name == "SellStopBIP0" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
				
				SellStopBIP0 = null;  //Should I do this here?

	
			}
			if (order.Name == "SellStopBIP1" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {


               
                SellStopBIP1 = order;


            }

			if (order.Name == "SellStopBIP1" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
				
				SellStopBIP1 = null;  //Should I do this here?

	
			}
			
			
			if (order.Name == "BuyStopBIP0" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {


              
                BuyStopBIP0 = order;


            }

			if (order.Name == "BuyStopBIP0" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
				
				BuyStopBIP0 = null;  //Should I do this here?

	
			}
			if (order.Name == "BuyStopBIP1" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {


               
                BuyStopBIP1 = order;


            }

			if (order.Name == "BuyStopBIP1" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
				
				
				BuyStopBIP1 = null;  //Should I do this here?

	
			}
						
			if(OutputWindow2)
				  NinjaTrader.Code.Output.Process(order.OrderState.ToString(), PrintTo.OutputTab2);
			else
				Print(order.OrderState.ToString());

            if (order.Name == orderName0 && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {
                waitingForFill_0 = true;
            }
            if (order.Name == orderName0 && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                waitingForFill_0 = false;

            }
			 if (order.Name == orderName1 && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {

                waitingForFill_1 = true;

            }
            if (order.Name == orderName1 && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                waitingForFill_1 = false;

            }
			
			
			
			
        }
					
		[NinjaScriptProperty]
		[Display( Name = "OutputWindow2", GroupName = "NinjaScriptParameters", Order = 2)]
		public bool OutputWindow2
		{ get; set; }

    }
}
