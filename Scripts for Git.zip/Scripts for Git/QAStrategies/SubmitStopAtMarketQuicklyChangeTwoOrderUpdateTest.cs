#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class SubmitStopAtMarketQuicklyChangeTwoOrderUpdateTest : Strategy
	{
		
		//Strategy will submit Stopmarket on the market, then keep changing it back and forth 1-2 ticks from best bid/offer trying to get a rejection.
		// trying to reproduce OnOrderUpdate being called twice for fill because of order rejection, causing scan_Obj.Posiiton object not to match actual position.
		private Order entryOrder = null;

		
		private DateTime xSentTime;
				bool  issueHit;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SubmitStopAtMarketQuicklyChangeTwoOrderUpdateTest";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				filledCounterExecution=0;
					filledCounterOrderUpdate=0;
				issueHit=false;
	xMoved=false;
				tickDiff=1;
		
			}
		}
		

bool xMoved;
		protected override void OnBarUpdate()
		{
			if(State == State.Historical) return;
			
				
			if(filledCounterOrderUpdate!=filledCounterExecution)
			{
				Print("Execution fill count does nto match that of OnOrderUpdate");
				Print("filledCounterOrderUpdate!=filledCounterExecution");
				
			}
		
			
			
			if(CurrentBar<10) return;
			
			if(issueHit)
			{
				Print("issue hit, returning.  LOOK FOR ORDER = XXXX | nAME=SELLSHORTlIMITbEAR | NEW STATE == FILLED");	
				return;
			}
			
		    if (xMoved != true)
			{
				EnterShortStopMarket(GetCurrentBid() -3*TickSize,"myEntryOrder");					
			
			}					
			else
			{		
					
				if(CurrentBar % 2 == 0)		
					ChangeOrder(entryOrder, 1, 0,GetCurrentBid()-3*TickSize);	
				
				if(CurrentBar % 2 == 0)		
					ChangeOrder(entryOrder, 1, 0,GetCurrentBid()-2*TickSize);	
			
		
			}
			
		}
		int tickDiff=0;

	
		      protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
			    Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);
		}
			
		int filledCounterExecution;
		int	filledCounterOrderUpdate;
				int filledCounter;
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
			filledCounterExecution = filledCounterExecution + quantity;
         
        }
		
	
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if(order.OrderState ==OrderState.Filled)
				filledCounterOrderUpdate = filledCounterOrderUpdate + quantity;
			
			if(order.OrderState == OrderState.Rejected)
			{
				Print("order Rejected");
				Print("Issue hit, strop running strategy");
				issueHit=true;
				return;
			}
			
			Print("OOU"+order.OrderType +"__"+order.OrderState+"_"+order.AverageFillPrice);
			if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
					
					Print("Unable To Change Order");

				}
			}


	

			if (order.Name =="myEntryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				xMoved=true;
				Print("myEntryOrder assigned");
					entryOrder = order;
			
			}
			
			if (order.Name == "myEntryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
			{
			
				entryOrder = null;  //Should I do this here?

	
			}
		}


	}
}
