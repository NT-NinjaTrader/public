#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class MITConnectionLossTest : Strategy
	{
		private Order myOrder;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name										= "MITConnectionLossTest";
				Calculate									= Calculate.OnBarClose;
				BarsRequiredToTrade							= 0;
			}
		}

		protected override void OnBarUpdate()
		{
			if (State != State.Realtime)
				return;

			if (myOrder == null)
			{
				Print(string.Format("{0} Submitting MIT order", Time[0]));
				EnterLongMIT(0, true, 1, Close[0] - 3000 * TickSize, "longEntry");
			}
			else
			{
				Print(string.Format("{0} | myOrder.Name: {1}, myOrder.OrderState: {2}, myOrder.StopPrice: {3}",
					Time[0], myOrder.Name, myOrder.OrderState, myOrder.StopPrice));
			}
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled,
			double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
		{
			if (order.Name == "longEntry" && myOrder != order)
			{
				Print("Assigning order to variable");
				myOrder = order;
			}

			Print(order.ToString());
		}
	}
}
