#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class IBMissingSubmitStops : Strategy
    {

        private bool doOnce = true;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "IBMissingSubmitStops";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
                IsUnmanaged = true;
            }
            else if (State == State.Configure)
            {
                orderCounter = 0;


                waitingPositionUpdate_1 = false;
                Golong_BIP1 = false;

                waitingPositionUpdate_2 = false;
waitingForSubmissionBIP0=false;

            }
        }

        int orderCounter;
        string orderName0;
        string orderName1;
        string orderName2;


        bool waitingPositionUpdate_1;


        bool waitingPositionUpdate_2;

        int barSubmission = 0;

        bool Golong_BIP1;
		int positionUpdateCounter;
        protected override void OnBarUpdate()
        {

            //Format before submission!!!!!!!!!!!  VS, 
            if (State != State.Realtime)
                return;

            orderCounter++;

            if (CurrentBar > barSubmission)
            {

                barSubmission = CurrentBar + 2;
				
				
				
                if (positionUpdateCounter == 0)
                {


                    if (Golong_BIP1)
                    {
                        Golong_BIP1 = false;
                        orderName0 = "Buy" +Name+ Instruments[0].FullName + orderCounter+"1";
                     	positionUpdateCounter++;
						SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, 1, 0, High[0], "", orderName0);
						    
					
						orderName1 = "Buy" +Name+ Instruments[0].FullName + orderCounter+"2";
						positionUpdateCounter++;
						SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0, High[0], "", orderName1);


                    }
                    else
                    {
                        Golong_BIP1 = true;
                        orderName0 = "Sell" + Instruments[0].FullName + orderCounter;
						positionUpdateCounter++;
                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, Low[0], "", orderName0);
						
						orderName1 = "Sell" +Name+ Instruments[0].FullName + orderCounter+"2";
						positionUpdateCounter++;
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, Low[0], "", orderName1);
                    }
                }
                else
                {
					if(waitingForFill_0)
					{
						return;
					}
					
					
					if(positionUpdateCounter>0)
					{
						Print("Missed a position update IBMissingSubmitStops");
					}

                    if (waitingForFill_0)  //Means never got a position update.
					{
                        Print("Missed Order Update for Fill IBMissingSubmitStops");
						
					}
 
					if (waitingForFill_1)  //Means never got a position update.
					{
                        Print("Missed Order Update for Fill IBMissingSubmitStops");
						
					}
//                    if (waitingForSubmissionBIP0)
//                    {
//                        Print("Missed submission of");  //Meaning OnOrderUpdate was missed for the submission.
							
//						Task.Run(() => MessageBox.Show("Hit Error,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));


//                    }

                  //  Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!!");
                }

           
            }


			//Think its realt4ed to get fills right about same time.
//            if (doOnce)
//            {
//                doOnce = false;
//                for (int i = 1; i < 4; i++)
//                    SubmitTrade(i);
//            }
        }


        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {


            if (position.Instrument.FullName == Instruments[0].FullName)
            {
            
				positionUpdateCounter--;
            }





        }
        bool waitingForSubmissionBIP0;
		   bool waitingForSubmissionBIP1;
			   bool waitingForSubmissionBIP2;
        bool waitingForFill_0;

        bool waitingForFill_1;
        bool waitingForFill_2;
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {

            if (order.Name == orderName0 && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {
				
//				waitingPositionUpdate_0 = true;
                waitingForFill_0 = true;
             //   waitingForSubmissionBIP0 = false;
            }
            if (order.Name == orderName0 && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                waitingForFill_0 = false;

            }
			 if (order.Name == orderName1 && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {
//					waitingPositionUpdate_1 = true;
                waitingForFill_1 = true;
             //   waitingForSubmissionBIP1 = false;
            }
            if (order.Name == orderName1 && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                waitingForFill_1 = false;

            }
			
			
			
			
        }

    }
}
