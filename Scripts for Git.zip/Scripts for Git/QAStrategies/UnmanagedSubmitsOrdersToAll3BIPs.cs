#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class UnmanagedSubmitsOrdersToAll3BIPs : Strategy
	{
		private bool doOnce = true;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "UnmanagedSubmitsOrdersToAll3BIPs";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				IsUnmanaged = true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries("GBPAUD");
				AddDataSeries("GBPCAD");
				AddDataSeries("GBPCHF");
			}
		}
		
		private void SubmitTrade(int BIP)
		{
			string oco = Instruments[BIP].FullName + DateTime.Now.ToString();
			SubmitOrderUnmanaged(BIP, OrderAction.Buy, OrderType.StopMarket, 10000, 0, GetCurrentAsk(BIP) + 50 * 0.0001, oco, "Buy"+Instruments[BIP].FullName);
			SubmitOrderUnmanaged(BIP, OrderAction.Sell, OrderType.StopMarket, 10000, 0, GetCurrentBid(BIP) - 50 * 0.0001, oco, "Sell"+Instruments[BIP].FullName);
			
//			SubmitOrderUnmanaged(BIP, OrderAction.Buy, OrderType.StopMarket, 10000, 0, Highs[BIP][0] + 50 * 0.0001, oco, "Buy"+Instruments[BIP].FullName);
//			SubmitOrderUnmanaged(BIP, OrderAction.Sell, OrderType.StopMarket, 10000, 0, Lows[BIP][0] - 50 * 0.0001, oco, "Sell"+Instruments[BIP].FullName);
		}

		protected override void OnBarUpdate()
		{
			if (State != State.Realtime)
				return;
			
			if (doOnce)
			{
				doOnce = false;
				for (int i = 1; i < 4; i++)
					SubmitTrade(i);
			}
		}
		
	}
}
