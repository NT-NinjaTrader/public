//#define BUILD_RELEASE

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
//using NinjaTrader.NinjaScript.Indicators.ATS.VX9.VX9Lib;
using System.Windows.Threading;
using System.IO;
using System.Net;
using SharpDX.DirectWrite;
using SharpDX;
using System.Xml;
using System.Globalization;
using System.Security.Cryptography;
#endregion

namespace NinjaTrader.NinjaScript.Strategies.ATS.VX9
{
	public class DumbStrategy : Strategy
	{
		const bool BROWSE = false;

		const int DEFAULT_MAX_NQ_CONTRACTS = 0;
		const int DEFAULT_MAX_MNQ_CONTRACTS = 2;

		int MAX_NQ_CONTRACTS = DEFAULT_MAX_NQ_CONTRACTS;
		int MAX_MNQ_CONTRACTS = DEFAULT_MAX_MNQ_CONTRACTS;

		EMA sma1;
		SMA sma2, sma3;

		// Time
		protected DateTime m_sessionBeginTime;
		protected DateTime m_sessionEndTime;
		internal DateTime SessionEndTime { get { return m_sessionEndTime; } }
		NinjaTrader.Data.SessionIterator m_sessionIterator;
		TimeSpan m_timeSpanExitOnClose;
		DateTime m_sessionTradingDayExchange;
		int m_nExitOnCloseSeconds = 30;
		// 

		bool m_bPrintedStartUpMessages;

		protected enum EOrderEntryNum { one, two }
		public enum CompoundingType { None, FixedEquity, Progressive }

		MarketPosition myMarketPosition = MarketPosition.Flat;
		HashSet<DateTime> dateTimesSkipped;

		protected int barsAgo = 0;
		protected int barEntered1;
		protected int barEntered2;
		protected int barExited;

		protected double nDailyPnL = 0;
		protected bool bOneRealtimeBar = false;

		protected int m_nChartIndicatorsAdded;

		protected Execution executionLE1;
		protected Execution executionLE2;
		protected Execution executionSE1;
		protected Execution executionSE2;

		protected Position position;

		protected int StartMinutes, BlackOutStartMinutes, BlackOutStartMinutesThursday, BlackOutEndMinutes, EndMinutes, CloseMinutes;

		class OrderTicket
        {
			internal bool _bSubmitOrderNow;
			internal int _entryShares;
			internal String _orderName;
		}

		OrderTicket orderTicketReverseFromLongToShort = null;
		OrderTicket orderTicketReverseFromShortToLong = null;

		public DumbStrategy()
		{
		}

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				// ****************************************************************************
				TraceOrders = true; // DO NOT REMOVE UNLESS YOU WANT TO GET RID OF OnOrderTrace
				// ****************************************************************************

				Description = @"Test orders";
				Name = "DumbStrategy";
				Calculate = Calculate.OnBarClose;
				EntriesPerDirection = 1;
				EntryHandling = EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy = true;
				ExitOnSessionCloseSeconds = 30;
				IsFillLimitOnTouch = false;
				MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution = OrderFillResolution.Standard;
				Slippage = 1;
				StartBehavior = StartBehavior.WaitUntilFlat;
				TimeInForce = TimeInForce.Gtc;
				RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling = StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade = 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration = true;
				IncludeCommission = true;

				LE1Shares = 1;
				SE1Shares = 1;
				LE2Shares = 1;
				SE2Shares = 1;

				Trend1Length = 5;
				Trend2Length = 21;

				ShowEMA = true;
				ShowSMA = true;

				PrintLogTag = "";
			}
			else if (State == State.Configure)
			{
				
				 doOnce=false;
			

				EntriesPerDirection = 1;
				EntryHandling = EntryHandling.UniqueEntries;
			}
			else if (State == State.Historical)
			{
				Print("");
				PrintX("State Historical");
				//stores the sessions once bars are ready, but before OnBarUpdate is called
				m_sessionIterator = new NinjaTrader.Data.SessionIterator(Bars);
				barsAgo = 0;
			}
			else if (State == State.DataLoaded)
			{
			}
			else if (State == State.Transition)
			{
				PrintX("State Transition");
				OnNewSession();
			}
			else if (State == State.Realtime)
			{
				PrintX("State Realtime");
				PrintX("VX9 Instrument " + Instrument.FullName);

			}
			else if (State == State.Terminated)
			{
			}

			OnStateChangeOverride();
		}


#region TRACE_ORDERS
		protected String traceFile = String.Empty;
		protected DateTime dateTimeTraceFile = DateTime.MinValue;

		protected override void OnOrderTrace(DateTime timestamp, string message)
		{
			if (State != State.Realtime)
				return;

			// A bug in NT managed order entry system sometimes makes it forget or lose 
			// the SignalName for an entry signal trading live on a real continuum account.
			// When this happens a call to ExitLong or ExitShort that specifies the
			// FromEntrySignal fails because it can't find the entry signal ( it lost it ).
			// OnOrderTrace will have a message indicating when this happens.
			// To work around this bug we look for the key info in the message
			// and if there then we close the position with the ExitLong or ExitShort
			// overload that doesn't require the entry signal name ( closes all long or short )
			String messageLower = message.ToLower();
			bool bIgnored = messageLower.Contains("ignored");
			if (bIgnored)
			{
				bool bReason = messageLower.Contains("reason='signalname does not have a matching fromentrysignal to exit");
				if (bReason)
				{
					bool bSignalNameSX = messageLower.Contains("signalname='sx");
					if(bSignalNameSX)
                    {
//						ExitShort();
//						PrintX("OnOrderTrace Exited full short position with ExitShort() because SignalName does not have a matching FromEntrySignal to exit");
						PrintX("OnOrderTrace SignalName does not have a matching FromEntrySignal to exit short");
					}
					else
                    {
						bool bSignalNameLX = messageLower.Contains("signalname='lx");
						if(bSignalNameLX)
                        {
//							ExitLong();
//							PrintX("OnOrderTrace Exited full long position with ExitLong() because SignalName does not have a matching FromEntrySignal to exit");
							PrintX("OnOrderTrace SignalName does not have a matching FromEntrySignal to exit long");
						}
					}
					PrintX(message);
				}
			}


#if !BUILD_RELEASE
			try
			{
				if (dateTimeTraceFile < timestamp.Date)//(String.IsNullOrEmpty(traceFile))
				{
					String strFullFilePathPrefix = BuildFullFilePath("VX9Trace " + Name + " " + PrintLogTag + " " + timestamp.ToString("yyyy-MM-dd"));
					String strFullPathNameTemplate = strFullFilePathPrefix + " {0}.txt";
					String strFullFilePath = String.Empty;
					int i = 0;
					while (true)
					{
						strFullFilePath = String.Format(strFullPathNameTemplate, i.ToString());
						if (!File.Exists(strFullFilePath))
						{
							break;
						}
						i++;
					}
					dateTimeTraceFile = timestamp.Date;
					traceFile = strFullFilePath;
				}

				String strMessage = string.Format("{0} {1}", timestamp, message);
				using (StreamWriter sw = new StreamWriter(traceFile, true))
				{
					sw.WriteLine(strMessage);
				}
			} catch(Exception ex)
            {

            }
#endif
		}

		internal String BuildFullFilePath(String fileName)
		{
			String strShadowFolder = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
			const String uri = "file:///";
			if (strShadowFolder.StartsWith(uri))
			{
				strShadowFolder = strShadowFolder.Substring(uri.Length);
			}
			int iCustom = strShadowFolder.IndexOf("NinjaTrader 8");
			String fileNameWithPath = strShadowFolder.Substring(0, iCustom) + "NinjaTrader 8/bin/Custom/" + fileName;
			return fileNameWithPath;
		}

		#endregion

		int dataSeriesToRunAlgo = 0;
		int dataSeriesToTrade = 0;
		bool SubmitOrderNow = true;
bool doOnce=false;
		protected override void OnBarUpdate()
		{
					
			if(State==State.Realtime)
				if(doOnce==false)
				{
					doOnce=true;	
				
					EnterLongEx(1, "LE1");

				}

		}

		protected virtual bool Long1Signal()
		{
			return CrossAbove(sma1, sma2, 1);
		}
		protected virtual bool Short1Signal()
		{
			return CrossBelow(sma1, sma2, 1);
		}
		protected virtual bool Long2Signal()
		{
			return myMarketPosition == MarketPosition.Long
				&& Close[0] < sma1[0];
		}
		protected virtual bool Short2Signal()
		{
			return myMarketPosition == MarketPosition.Short
				&& Close[0] > sma1[0];
		}

		protected virtual bool ExitLongSignal()
		{
			double openPnL = position == null ? 0 : position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Close.GetValueAt(CurrentBar));
			return openPnL > 20;
		}
		protected virtual bool ExitShortSignal()
		{
			double openPnL = position == null ? 0 : position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Close.GetValueAt(CurrentBar));
			return openPnL > 20;
		}

		protected void EnterLongEx(int shares, String name)
		{
		//	if (SubmitOrderNow)
			{
				EnterLong(dataSeriesToTrade, shares, name);
			}
		}

		void ExitLongEx()
		{
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Long)
			{
				if (SubmitOrderNow)
				{
					ExitLongExSubmit();
				}
			}
		}

		void ExitLongExSubmit(String LX1Sell = "LX1Sell", String LX2Sell = "LX2Sell")
		{
			if(State == State.Realtime)
				PrintX(String.Format("ExitLongExSubmit executionLE1.Quantity:{0}, executionLE1.Order.Filled:{0}", executionLE1.Quantity, executionLE1.Order.Filled));

			int totalExecutionQuantity = executionLE1.Order.Filled;
			ExitLong(dataSeriesToTrade, executionLE1.Order.Filled, LX1Sell, "LE1");
			if (executionLE2 != null)
			{
				ExitLong(dataSeriesToTrade, executionLE2.Order.Filled, LX2Sell, "LE2");
				totalExecutionQuantity += executionLE2.Order.Filled;
			}

			int leftOverContracts = Positions[dataSeriesToTrade].Quantity - totalExecutionQuantity;
			if (leftOverContracts > 0)
			{
				PrintX("Sell leftover long contracts: " + leftOverContracts);
				ExitLong(dataSeriesToTrade, leftOverContracts, "LX3Sell", "LE1");
				ExitLong(dataSeriesToTrade, leftOverContracts, "LX4Sell", "LE2");
			}
		}

		void EnterShortEx(int shares, String name, bool bSubmitOrderNow )
		{
			if (bSubmitOrderNow)
			{
				EnterShort(dataSeriesToTrade, shares, name);
			}
		}

		void ExitShortEx()
		{
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Short)
			{
				if (SubmitOrderNow)
				{
					ExitShortExSubmit();
				}
			}
		}

		void ExitShortExSubmit(String SX1BTC = "SX1BTC", String SX2BTC = "SX2BTC")
		{
			if (State == State.Realtime)
				PrintX(String.Format("ExitShortExSubmit executionSE1.Quantity:{0}, executionSE1.Order.Filled:{0}", executionSE1.Quantity, executionSE1.Order.Filled));

			int totalExecutionQuantity = executionSE1.Order.Filled;
			ExitShort(dataSeriesToTrade, executionSE1.Order.Filled, SX1BTC, "SE1");
			if (executionSE2 != null)
			{
				ExitShort(dataSeriesToTrade, executionSE2.Order.Filled, SX2BTC, "SE2");
				totalExecutionQuantity += executionSE2.Order.Filled;
			}

			int leftOverContracts = Positions[dataSeriesToTrade].Quantity - totalExecutionQuantity;
			if (leftOverContracts > 0)
			{
				PrintX("Buy to cover leftover short contracts: " + leftOverContracts);
				ExitShort(dataSeriesToTrade, leftOverContracts, "SX3Sell", "SE1");
				ExitShort(dataSeriesToTrade, leftOverContracts, "SX4Sell", "SE2");
			}
		}
 
		public static void Print2(string s)
        {
            //	NinjaTrader.Code.Output.Process((s.ToString())


            NinjaTrader.Code.Output.Process(s.ToString(), PrintTo.OutputTab2);
            //	NinjaTrader.NinjaScript.NinjaScript.Log(DateTime.Now.ToString()+"__"+s.ToString(), NinjaTrader.Cbi.LogLevel.Error);
        }
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			Print2("OnExecutionUpdate Called ");
			base.OnExecutionUpdate(execution, executionId, price, quantity, marketPosition, orderId, time);

			if (execution.Order.Filled == execution.Order.Quantity)
			{
				switch (execution.Name)
				{
					case "LE1":
						executionLE1 = execution;
						AlertAndEmail(execution, "AtsVX9" + " LE1: " + execution.Price);
						barEntered1 = CurrentBar;
						barEntered2 = 0;
						break;
					case "LE2":
						executionLE2 = execution;
						AlertAndEmail(execution, "AtsVX9" + " LE2: " + execution.Price);
						barEntered2 = CurrentBar;
						break;
					case "SE1":
						executionSE1 = execution;
						AlertAndEmail(execution, "AtsVX9" + " SE1: " + execution.Price);
						barEntered1 = CurrentBar;
						barEntered2 = 0;
						break;
					case "SE2":
						executionSE2 = execution;
						AlertAndEmail(execution, "AtsVX9" + " SE2: " + execution.Price);
						barEntered2 = CurrentBar;
						break;
					case "ReverseLE1":
					case "ReverseLE2":
						if(execution.Position == 0)
                        {
							if(State == State.Realtime)
								PrintX("ExitLong execution complete. ", LogLevel.Information);

							if (orderTicketReverseFromLongToShort != null)
							{
								if (State == State.Realtime)
									PrintX("EnterShort with orderTicket.", LogLevel.Information);

								EnterShortEx(orderTicketReverseFromLongToShort._entryShares,
									orderTicketReverseFromLongToShort._orderName,
									orderTicketReverseFromLongToShort._bSubmitOrderNow);

								orderTicketReverseFromLongToShort = null;
							}
						}
						break;
					case "ReverseSE1":
					case "ReverseSE2":
						if (execution.Position == 0)
						{
							if (State == State.Realtime)
								PrintX("ExitShort execution complete. ", LogLevel.Information);

							if (orderTicketReverseFromShortToLong != null)
							{
								if (State == State.Realtime)
									PrintX("EnterLong with orderTicket.", LogLevel.Information);

								EnterLongEx(orderTicketReverseFromShortToLong._entryShares,
									orderTicketReverseFromShortToLong._orderName);

								orderTicketReverseFromShortToLong = null;
							}
						}
						break;
				}
				bool bIsExitProp = execution.IsExit;
				bool bIsExitStratProp = execution.IsExitStrategy;

				String name = execution.Name.ToLower();
				bool bIsExit = name.Contains("lx") || name.Contains("sx") || name.Contains("close") || name.Contains("sell") || name.Contains("buy to cover");
				if (bIsExit) // doesn't work-> execution.IsExit)
				{
					barExited = CurrentBar;
					if (SystemPerformance.AllTrades.Count > 0)
					{
						Trade tradeAny = SystemPerformance.AllTrades.Last();
						nDailyPnL += tradeAny.ProfitCurrency;
						if (SystemPerformance.AllTrades.Count > 1)
						{
							Trade trade2 = SystemPerformance.AllTrades[SystemPerformance.AllTrades.Count - 2];
							if (tradeAny.Exit == trade2.Exit)
							{
								nDailyPnL += trade2.ProfitCurrency;
							}
						}
					}

					double SessionPnL = 0;
					foreach (Trade tradeInList in SystemPerformance.RealTimeTrades)
					{
						if(tradeInList.Exit.Time > m_sessionBeginTime)
							SessionPnL += tradeInList.ProfitCurrency;
					}
					SessionPnL = Math.Round(SessionPnL, 2);
					if (SystemPerformance.RealTimeTrades.Count > 0)
					{
						Trade trade = SystemPerformance.RealTimeTrades.Last();
						double tradeProfit = trade.ProfitCurrency;
						
						if(SystemPerformance.RealTimeTrades.Count > 1)
						{
							Trade trade2 = SystemPerformance.RealTimeTrades[SystemPerformance.RealTimeTrades.Count - 2];
							if(trade.Exit == trade2.Exit)
							{
								tradeProfit += trade2.ProfitCurrency;
                            }
						}

						String message = "AtsVX9" + " Exit " + execution.Name + " price: " + execution.Price;
						if (trade != null)
						{
							message = message + " TradePnL: " + tradeProfit + " SessionPnL: " + SessionPnL + " DailyPnL: " + nDailyPnL;
						}
						AlertAndEmail(execution, message);
					}
				}
			}

			OnExecutionUpdateOverride(execution, executionId, price, quantity, marketPosition, orderId, time);
		}

        protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
        {
            base.OnPositionUpdate(position, averagePrice, quantity, marketPosition);

			if (position.Instrument == Instrument && marketPosition == MarketPosition.Flat)
				this.position = null;
			else if (position.Instrument == Instrument && marketPosition != MarketPosition.Flat)
				this.position = position;
		}


		void AlertAndEmail(Execution execution, String message)
		{
			if (State != State.Realtime)
				return;
			PrintX(message);
		}

		protected void PrintX(String s, LogLevel logLevel = LogLevel.Information)
		{
			try
			{
				String messageLog = String.Format("AtsVX9 {0} {1} {2}", Instrument.MasterInstrument.Name, PrintLogTag, s);
				DateTime dateTime;
				try
				{
					dateTime = Time[0];
				}
				catch
				{
					dateTime = DateTime.Now;
				}
				String messagePrint = String.Format("{0} {1}", dateTime, messageLog);
				if (EnablePrintLog)
					Print(messagePrint);
				Log(messageLog, logLevel);
			} catch( Exception ex)
            {

            }
		}

		void OnBarUpdateSession()
		{
			// on new bars session, find the next trading session
			if (Bars.IsFirstBarOfSession || m_sessionBeginTime == DateTime.MinValue)
			{
				//Print("Calculating trading day for " + Time[0]);
				// use the current bar time to calculate the next session
				m_sessionIterator.GetNextSession(Time[0], true);

				// store the desired session information
				m_sessionTradingDayExchange = m_sessionIterator.ActualTradingDayExchange;
				m_sessionBeginTime = m_sessionIterator.ActualSessionBegin;
				m_sessionEndTime = m_sessionIterator.ActualSessionEnd;

				m_timeSpanExitOnClose = m_sessionEndTime.Subtract(TimeSpan.FromSeconds(m_nExitOnCloseSeconds)).TimeOfDay;
				//Print(string.Format("The Current Trading Day {0} starts at {1} and ends at {2}",
				//                    m_tradingDay.ToShortDateString(), m_beginTime, m_endTime));
				// Output:
				// Calculating trading day from 9/30/2015 4:01:00 PM
				//The Current Trading Day 10/1/2015 starts at 9/30/2015 4:00:00 PM and ends at 10/1/2015 3:00:00 PM
				if (State != State.Historical || m_bPrintedStartUpMessages == false)
				{
					OnNewSession();
				}

				nDailyPnL = 0;
			}
		}

		void OnNewSession()
		{
			PrintStartupMessages();
		}

		bool IsMinutesAfterSessionStart(int minutesToTest)
		{
			return Time[0] > m_sessionBeginTime.AddMinutes(minutesToTest);
		}

		bool IsTimeEndSession(int minutesFromEnd)
		{
			TimeSpan timeDeadLine = m_sessionEndTime.TimeOfDay - TimeSpan.FromMinutes(minutesFromEnd);
			return Time[0].TimeOfDay < timeDeadLine;
		}

		public bool IsBlackOutSession()
		{
			DateTime dateTimeBlackOutStart = m_sessionBeginTime.AddMinutes(BlackOutStartMinutes);
			DateTime dateTimeBlackOutEnd = m_sessionBeginTime.AddMinutes(BlackOutEndMinutes);
			//Print("blackout start: " + dateTimeBlackOutStart + ", blackout end: " + dateTimeBlackOutEnd);
			return Time[barsAgo] > dateTimeBlackOutStart && Time[barsAgo] < dateTimeBlackOutEnd;
		}

		void PrintStartupMessages()
		{
			DateTime dateTimeStart = m_sessionBeginTime.AddMinutes(StartMinutes);
			DateTime dateTimeBlackOutStart = m_sessionBeginTime.AddMinutes(BlackOutStartMinutes);
			DateTime dateTimeBlackOutStartThursday = m_sessionBeginTime.AddMinutes(BlackOutStartMinutesThursday);
			DateTime dateTimeBlackOutEnd = m_sessionBeginTime.AddMinutes(BlackOutEndMinutes);
			TimeSpan timeSpanStopEnteringPositions = m_sessionEndTime.TimeOfDay - TimeSpan.FromMinutes(EndMinutes);
			TimeSpan timeSpanClosePositions = m_sessionEndTime.TimeOfDay;

			if (EnablePrintLog)
			{
				Print("...");
				Print(Time[0] + " VX9 First Bar of Session");
				Print("AtsVX9 Trading Strategy - AutomaticTradingSignals.com");
				PrintX("Start Trading: " + dateTimeStart.TimeOfDay);
				if (m_sessionEndTime.DayOfWeek == DayOfWeek.Thursday)
					PrintX("Weekly Unemployment. Black out start (no positions initiated): " + dateTimeBlackOutStartThursday.TimeOfDay);
				else
					PrintX("Black out start (no positions initiated): " + dateTimeBlackOutStart.TimeOfDay);
				PrintX("Black out end (resume initiating positions): " + dateTimeBlackOutEnd.TimeOfDay);
				PrintX("Stop entering positions: " + timeSpanStopEnteringPositions);
				PrintX("Close all positions: " + timeSpanClosePositions);
			}
			m_bPrintedStartUpMessages = true;
		}

#region PARAMETERS

		// PARAMETERS

		// ORDER QUANTITY

		[Display(Name = "LE1 Contracts", Description = "number of shares/contracts for 1st long entry", Order = 1, GroupName = "01. Order Quantity"), NinjaScriptProperty]
		public int LE1Shares
		{
			get; set;
		}

		[Display(Name = "LE2 Contracts", Description = "number of shares/contracts for 2nd long entry", Order = 2, GroupName = "01. Order Quantity"), NinjaScriptProperty]
		public int LE2Shares
		{
			get; set;
		}

		[Display(Name = "SE1 Contracts", Description = "number of shares/contracts for 1st short entry", Order = 3, GroupName = "01. Order Quantity"), NinjaScriptProperty]
		public int SE1Shares
		{
			get; set;
		}

		[Display(Name = "SE2 Contracts", Description = "number of shares/contracts for 2nd short entry", Order = 4, GroupName = "01. Order Quantity"), NinjaScriptProperty]
		public int SE2Shares
		{
			get; set;
		}

		[Browsable(false)]
		[Display(Description = "", Order = 6, GroupName = "Order Management")]
		public CalculationMode StopLossCalculationMode
		{
			get; set;
		}

		[Browsable(false)]
		[Display(Description = "Stop Loss Value", Order = 7, GroupName = "Order Management")]
		public double StopLossValue
		{
			get; set;
		}

		[Browsable(false)]
		[Display(Name = "Enable Stop", Description = "Enables the stop loss.", Order = 8, GroupName = "Order Management")]
		public bool EnableStopLoss
		{
			get; set;
		}

		[Browsable(false)]
		[Display(Name = "Enable Trail Stop", Description = "Enables trailing stop loss that moves with the market. Supercedes Enable Stop.", Order = 9, GroupName = "Order Management")]
		public bool EnableTrailStopLoss
		{
			get; set;
		}


		[Browsable(BROWSE)]
		[Range(1, int.MaxValue)]
		[Display(Name = "Trend1Length", Order = 11, GroupName = "07. Trade Time")]
		public int Trend1Length
		{ get; set; }

		[Browsable(BROWSE)]
		[Range(1, int.MaxValue)]
		[Display(Name = "Trend2Length", Order = 12, GroupName = "07. Trade Time")]
		public int Trend2Length
		{ get; set; }


		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Start Entering Positions", Description = "time span from beginning of session to begin trading", Order = 29, GroupName = "07. Trade Time")]
		public TimeSpan StartMinutesTS
		{ get; set; }

		[Browsable(false)]
		public string StartMinutesTSSerialize
		{
			get { return StartMinutesTS.ToString(); }
			set { StartMinutesTS = TimeSpan.Parse(value); }
		}

		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Blackout Begin", Description = "time span from beginning of session to pause entering positions", Order = 31, GroupName = "07. Trade Time")]
		public TimeSpan BlackOutStartMinutesTS
		{ get; set; }

		[Browsable(false)]
		public string BlackOutStartMinutesTSSerialize
		{
			get { return BlackOutStartMinutesTS.ToString(); }
			set { BlackOutStartMinutesTS = TimeSpan.Parse(value); }
		}

		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Blackout Begin Thursday", Description = "time span from beginning of session to pause entering trades on Thursdays", Order = 32, GroupName = "07. Trade Time")]
		public TimeSpan BlackOutStartMinutesThursdayTS
		{ get; set; }

		[Browsable(false)]
		public string BlackOutStartMinutesThursdayTSSerialize
		{
			get { return BlackOutStartMinutesThursdayTS.ToString(); }
			set { BlackOutStartMinutesThursdayTS = TimeSpan.Parse(value); }
		}

		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Blackout End", Description = "time span from beginning of session to resume entering positions", Order = 42, GroupName = "07. Trade Time")]
		public TimeSpan BlackOutEndMinutesTS
		{ get; set; }

		[Browsable(false)]
		public string BlackOutEndMinutesTSSerialize
		{
			get { return BlackOutEndMinutesTS.ToString(); }
			set {  BlackOutEndMinutesTS = TimeSpan.Parse(value); }
		}

		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Stop Entering Positions", Description = "time span from end of session to stop entering positions", Order = 43, GroupName = "07. Trade Time")]
		public TimeSpan EndMinutesTS
		{ get; set; }

		[Browsable(false)]
		public string EndMinutesTSSerialize
		{
			get { return EndMinutesTS.ToString(); }
			set { EndMinutesTS = TimeSpan.Parse(value); }
		}

		[XmlIgnore, NinjaScriptProperty]
		[Display(Name = "Exit Positions", Description = "time span from end of session to close positions", Order = 44, GroupName = "07. Trade Time")]
		public TimeSpan CloseMinutesTS
		{ get; set; }

		[Browsable(false)]
		public string CloseMinutesTSSerialize
		{
			get { return CloseMinutesTS.ToString(); }
			set { CloseMinutesTS = TimeSpan.Parse(value); }
		}

// INDICATORS

		[Browsable(false)]
		[Display(Name = "Show ADX", Description = "", Order = 44, GroupName = "10. Indicators")]
		public bool ShowADX
		{ get; set; }

		[Browsable(false)]
		[Display(Name = "Show EMA", Description = "", Order = 45, GroupName = "10. Indicators")]
		public bool ShowEMA
		{ get; set; }

		[Browsable(false)]
		[Display(Name = "Show SMA", Description = "", Order = 46, GroupName = "10. Indicators")]
		public bool ShowSMA
		{ get; set; }


		// VX9Trend PLOTS

		// ALERTS

		[Display(Name = "Enable Print Log", Description = "", Order = 30, GroupName = "15. Misc"), NinjaScriptProperty]
		public bool EnablePrintLog
		{
			get; set;
		}

		[Display(Name = "Print Log Tag", Description = "Tag log messages with this string to help you figure out which VX9 is which (in case you run multiple instances. Keep it short!", Order = 31, GroupName = "15. Misc"), NinjaScriptProperty]
		public String PrintLogTag
		{
			get; set;
		}

		[Display(Name = "Volatility Filter", Description = "Does not trade if market has been volatile last several sessions", Order = 32, GroupName = "15. Misc"), NinjaScriptProperty]
		public bool EnableDailyDeltaFilter { get; set; }

		#endregion
//	}

	/*
	 *********************************************************************************************
	 *********************************************************************************************
	 *********************************************************************************************
	 *
	 *
	 *	VX9
	 *	VX9
	 *	VX9
	 *
	 *
	 *********************************************************************************************
	 *********************************************************************************************
	 *********************************************************************************************
	 */
//	public class AtsVX9 : AtsVX9Strategy
//	{
		public enum ESwingLevelPolicy { NearestSwing, AverageSwing, Percentage }//, Points, Dollars}
		public enum ETrailStopAlgo{ TrailAlways, TrailOnlyWinning }

		List<Order> listStopOrders = new List<Order>();
		Order orderLE1;
		Order orderLE2;
		Order orderSE1;
		Order orderSE2;

		Order orderLX1Stop;
		Order orderLX2Stop;
		Order orderSX1Stop;
		Order orderSX2Stop;
		Order orderLX1Target;
		Order orderLX2Target;
		Order orderSX1Target;
		Order orderSX2Target;

		int barEnteredLong;
		int barEnteredShort;
		int lowestBarSinceEnteredLong;
		int highestBarSinceEnteredLong;
		int highestBarSinceEnteredShort;
		int lowestBarSinceEnteredShort;
		Execution executionSell;
		int barSold;
		Execution executionBuyToCover;
		int barBoughtToCover;
		int maxSwingsToLookBack = 3;


		protected void OnStateChangeOverride()
		{
			if (State == State.SetDefaults)
			{
				StopSwingLevelPolicy = ESwingLevelPolicy.Percentage;
				TrailStopAlgo = ETrailStopAlgo.TrailAlways;
				StopSwingDeviationValue = .3;
				EnableSwingStop = false;
				SwingStopLossMinimum = 0.0035;
				EnableTriggerStop = false;
				TriggerStopValue = 0.001;

				SwingStopLossCalculationMode = CalculationMode.Percent;
				SwingStopLossMaximum = 0.002;
				SwingTargetCalculationMode = CalculationMode.Percent;

				TargetSwingLevelPolicy = ESwingLevelPolicy.Percentage;
				TargetSwingDeviationValue = .3;
				TargetValue = 0.0025;
				EnableSwingTarget = false;
				EnableSwingTargetTrail = false;
				EnableSwingTargetFade = false;

				SwingPointMargin = 1;
				StopOrderMinimumTicksFromClose = 20;
			}
			else if (State == State.Configure)
			{
				Name = "";
			}
			else if (State == State.DataLoaded)
			{
				MaintainDailyState(GetCurrentBid());
			}
			else if(State == State.Transition)
			{
			}
			else if (State == State.Realtime)
			{
				if (orderLE1 != null)
					orderLE1 = GetRealtimeOrder(orderLE1);

				if (orderLE2 != null)
					orderLE2 = GetRealtimeOrder(orderLE2);

				if (orderSE1 != null)
					orderSE1 = GetRealtimeOrder(orderSE1);

				if (orderSE2 != null)
					orderSE2 = GetRealtimeOrder(orderSE2);

				if (orderLX1Stop != null)
					orderLX1Stop = GetRealtimeOrder(orderLX1Stop);

				if (orderLX2Stop != null)
					orderLX2Stop = GetRealtimeOrder(orderLX2Stop);

				if (orderSX1Stop != null)
					orderSX1Stop = GetRealtimeOrder(orderSX1Stop);

				if (orderSX2Stop != null)
					orderSX2Stop = GetRealtimeOrder(orderSX2Stop);

				if (orderLX1Target != null)
					orderLX1Target = GetRealtimeOrder(orderLX1Target);

				if (orderLX2Target != null)
					orderLX2Target = GetRealtimeOrder(orderLX2Target);

				if (orderSX1Target != null)
					orderSX1Target = GetRealtimeOrder(orderSX1Target);

				if (orderSX2Target != null)
					orderSX2Target = GetRealtimeOrder(orderSX2Target);
			}
		}

		protected void FirstBarOfSessionUpdate()
		{
			if (Bars.IsFirstBarOfSession)
			{
				MaintainDailyState(Closes[dataSeriesToRunAlgo][0]);
			}
		}

		protected void MaintainDailyState(double price)
		{
		}

		protected void PrintTargetAndStopEstimates(double price)
		{
		}

		protected void OnBarUpdateOverride()
		{
			FirstBarOfSessionUpdate();

			// do this last because targets and stops calcs depend on values from prior bar
			MaintainBarCounts();
			CleanOrderLists();
		}

		void CleanOrderLists()
		{
			List<Order> ordersToRemove = new List<Order>();

			foreach (Order order in listStopOrders)
			{
				if (order.OrderAction == OrderAction.BuyToCover && Positions[dataSeriesToTrade].MarketPosition != MarketPosition.Short)
				{
					CancelOrder(order);
					ordersToRemove.Add(order);
				}
				else
				if (order.OrderAction == OrderAction.Sell && Positions[dataSeriesToTrade].MarketPosition != MarketPosition.Long)
				{
					CancelOrder(order);
					ordersToRemove.Add(order);
				}
			}

			foreach (Order orderToRemove in ordersToRemove)
				listStopOrders.Remove(orderToRemove);

			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Long)
			{
				CancelAllShortPositionOrders();
			}
			else
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Short)
			{
				CancelAllLongPositionOrders();
			}
			else
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Flat)
			{
				CancelAllLongPositionOrders();
				CancelAllShortPositionOrders();
			}
		}

		bool IsSwingLevelPolicyStatic(ESwingLevelPolicy swingLevelPolicy)
		{
			return swingLevelPolicy == ESwingLevelPolicy.Percentage;// || swingLevelPolicy == ESwingLevelPolicy.Dollars || swingLevelPolicy == ESwingLevelPolicy.Points;
		}

		void MaintainBarCounts()
		{
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Long)
			{
				double lowestPriceSinceEnteredLong = Closes[dataSeriesToRunAlgo].GetValueAt(lowestBarSinceEnteredLong);
				if (Closes[dataSeriesToRunAlgo][0] < lowestPriceSinceEnteredLong)
					lowestBarSinceEnteredLong = CurrentBar;

				double highestPriceSinceEnteredLong = Closes[dataSeriesToRunAlgo].GetValueAt(highestBarSinceEnteredLong);
				if (Closes[dataSeriesToRunAlgo][0] > highestPriceSinceEnteredLong)
					highestBarSinceEnteredLong = CurrentBar;
			}
			else
			if (Positions[dataSeriesToTrade].MarketPosition == MarketPosition.Short)
			{
				double highestPriceSinceEnteredShort = Closes[dataSeriesToRunAlgo].GetValueAt(highestBarSinceEnteredShort);
				if (Closes[dataSeriesToRunAlgo][0] > highestPriceSinceEnteredShort)
					highestBarSinceEnteredShort = CurrentBar;

				double lowestPriceSinceEnteredShort = Closes[dataSeriesToRunAlgo].GetValueAt(lowestBarSinceEnteredShort);
				if (Closes[dataSeriesToRunAlgo][0] < lowestPriceSinceEnteredShort)
					lowestBarSinceEnteredShort = CurrentBar;
			}
		}

		void CancelAllLongPositionOrders()
		{
			CancelOrder(orderLE1);
			CancelOrder(orderLE2);

			CancelOrder(orderLX1Target);
			CancelOrder(orderLX2Target);
			CancelOrder(orderLX1Stop);
			CancelOrder(orderLX2Stop);

			orderLE1 = null;
			orderLE2 = null;

			orderLX1Target = null;
			orderLX2Target = null;
			orderLX1Stop = null;
			orderLX2Stop = null;
		}

		void CancelAllShortPositionOrders()
		{
			CancelOrder(orderSE1);
			CancelOrder(orderSE2);

			CancelOrder(orderSX1Target);
			CancelOrder(orderSX2Target);
			CancelOrder(orderSX1Stop);
			CancelOrder(orderSX2Stop);

			orderSE1 = null;
			orderSE2 = null;

			orderSX1Target = null;
			orderSX2Target = null;
			orderSX1Stop = null;
			orderSX2Stop = null;
		}

		protected void OnExecutionUpdateOverride(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			//base.OnExecutionUpdate(execution, executionId, price, quantity, marketPosition, orderId, time);
			if (execution.Order.Filled > 0)
			{
				switch (execution.Name)
				{
					case "LE1":
						barEnteredLong = CurrentBar;
						highestBarSinceEnteredLong = lowestBarSinceEnteredLong = CurrentBar;
						SubmitLongTargetAndStop(execution, "LX1Stop");
						break;
					case "LE2":
						SubmitLongTargetAndStop(execution, "LX2Stop");
						break;
					case "SE1":
						barEnteredShort = CurrentBar;
						lowestBarSinceEnteredShort = highestBarSinceEnteredShort = CurrentBar;
						SubmitShortTargetAndStop(execution, "SX1Stop");
						break;
					case "SE2":
						SubmitShortTargetAndStop(execution, "SX2Stop");
						break;
				}
				String name = execution.Name.ToLower();
				bool bIsExit = name.Contains("close") || name.Contains("sell") || name.Contains("buy to cover");
				if (bIsExit)
				{
				}

				if (name.Contains("sell"))
				{
					executionSell = execution;
					barSold = CurrentBar;
				}
				else
				if (name.Contains("buy to cover"))
				{
					executionBuyToCover = execution;
					barBoughtToCover = CurrentBar;
				}
			}
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
		{
			base.OnOrderUpdate(order, limitPrice, stopPrice, quantity, filled, averageFillPrice, orderState, time, error, comment);

			if (order.OrderState == OrderState.Accepted || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Working)
			{
				if (order.Name == "LE1")
					orderLE1 = order;
				else
				if (order.Name == "LE2")
					orderLE2 = order;
				else
				if (order.Name == "SE1")
					orderSE1 = order;
				else
				if (order.Name == "SE2")
					orderSE2 = order;

				if (order.Name == "LX1Target")
					orderLX1Target = order;
				else
				if (order.Name == "SX1Target")
					orderSX1Target = order;
				else
				if (order.Name == "LX2Target")
					orderLX2Target = order;
				else
				if (order.Name == "SX2Target")
					orderSX2Target = order;

				if (order.OrderType == OrderType.StopMarket)
				{
					if (listStopOrders.Contains(order) == false)
						listStopOrders.Add(order);

					if (order.OrderAction == OrderAction.Sell)
					{
						if (order.Name == "LX1Stop")
							orderLX1Stop = order;
						else
						if (order.Name == "LX2Stop")
							orderLX2Stop = order;
					}
					else
					if (order.OrderAction == OrderAction.BuyToCover)
					{
						if (order.Name == "SX1Stop")
							orderSX1Stop = order;
						else
						if (order.Name == "SX2Stop")
							orderSX2Stop = order;
					}
				}
				else
				if (order.OrderType == OrderType.Limit)
				{
					if (order.OrderAction == OrderAction.Sell)
					{
						if(order.Name == "LX1Target")
							orderLX1Target = order;
						else
						if(order.Name == "LX2Target")
							orderLX2Target = order;
					}
					else
					if (order.OrderAction == OrderAction.BuyToCover)
					{
						if(order.Name == "SX1Target")
							orderSX1Target = order;
						else
						if(order.Name == "SX2Target")
							orderSX2Target = order;
					}
				}
			}
		}

		void SubmitLongTargetAndStop(Execution execution, String stopName)
		{
			//if (EnableSwingStop)
			{
				double stopPrice = FindExitLongStopMarketPrice(execution, stopName);
				if (stopPrice > -1)
				{
					double finalPrice = stopPrice;// - SwingPointMargin;

					if (finalPrice > execution.Price - TickSize * StopOrderMinimumTicksFromClose)
						finalPrice = execution.Price - TickSize * StopOrderMinimumTicksFromClose;

					Order orderStop = orderLX1Stop;
					if (stopName == "LX2Stop")
						orderStop = orderLX2Stop;

					if (orderStop != null && (orderStop.OrderState == OrderState.Accepted || orderStop.OrderState == OrderState.Working))
						ChangeOrder(orderStop, execution.Order.Filled, orderStop.LimitPrice, finalPrice);
					else
						ExitLongStopMarket(dataSeriesToTrade, true, execution.Order.Filled, finalPrice, stopName, execution.Name);
				}
			}

			//if (EnableSwingTarget)
			{
				double targetPrice = FindExitLongLimitPrice(execution);
				if (targetPrice > -1)
				{
					String orderName = "LX1Target";
					if (execution.Name == "LE2")
						orderName = "LX2Target";
					ExitLongLimit(dataSeriesToTrade, true, execution.Order.Filled, targetPrice - SwingPointMargin, orderName, execution.Name);
				}
			}
		}

		int stopPointsMinimum = 30;
		int stopPointsMinimumVirtual = 30;
		int targetPoints = 50;
		int targetPointsVirtual = 50;

		double FindExitLongStopMarketPrice(Execution execution, String stopName)
		{
			return FindExitLongStopPrice(execution, stopName, ESwingLevelPolicy.Percentage, stopPointsMinimum);
		}

		double FindExitLongStopMarketVirtualPrice(Execution execution, String stopName)
		{
			return FindExitLongStopPrice(execution, stopName, ESwingLevelPolicy.Percentage, stopPointsMinimumVirtual);
		}

		double FindExitLongStopPrice(Execution execution, String stopName, ESwingLevelPolicy swingLevelPolicy, double minimumStopPoints)
		{
			double stopPrice = -1;

			if (EnableSwingStop)
			{
				if (IsSwingLevelPolicyStatic(swingLevelPolicy))
				{
					stopPrice = execution.Price - minimumStopPoints;
				}
			}
			return stopPrice;
		}

		double FindExitLongLimitPrice(Execution execution)
		{
			return FindExitLongLimitPrice(execution, ESwingLevelPolicy.Percentage, targetPoints);
		}

		double FindExitLongLimitVirtualPrice(Execution execution)
		{
			return FindExitLongLimitPrice(execution, ESwingLevelPolicy.Percentage, targetPointsVirtual);
		}

		double FindExitLongLimitPrice(Execution execution, ESwingLevelPolicy swingLevelPolicy, double _targetPoints)
		{
			double limitPrice = -1;

			if (IsSwingLevelPolicyStatic(swingLevelPolicy))
			{
				limitPrice = Positions[dataSeriesToTrade].AveragePrice + _targetPoints;
			}

			return limitPrice;
		}

		void SubmitShortTargetAndStop(Execution execution, String stopName)
		{
			//if (EnableSwingStop)
			{
				double stopPrice = FindExitShortStopMarketPrice(execution, stopName);
				if (stopPrice > -1)
				{
					double finalPrice = stopPrice;// + SwingPointMargin;
					if (finalPrice < execution.Price + TickSize * StopOrderMinimumTicksFromClose)
						finalPrice = execution.Price + TickSize * StopOrderMinimumTicksFromClose;

					Order orderStop = orderSX1Stop;
					if (stopName == "SX2Stop")
						orderStop = orderSX2Stop;

					if (orderStop != null && (orderStop.OrderState == OrderState.Accepted || orderStop.OrderState == OrderState.Working))
						ChangeOrder(orderStop, execution.Order.Filled, orderStop.LimitPrice, finalPrice);
					else
						ExitShortStopMarket(dataSeriesToTrade, true, execution.Order.Filled, finalPrice, stopName, execution.Name);
				}
			}

			//if (EnableSwingTarget)
			{
				double limitPrice = FindExitShortLimitPrice(execution);
				if (limitPrice > -1)
				{
					String orderName = "SX1Target";
					if (execution.Name == "SE2")
						orderName = "SX2Target";
					ExitShortLimit(dataSeriesToTrade, true, execution.Order.Filled, limitPrice + SwingPointMargin, orderName, execution.Name);
				}
			}
		}

		double FindExitShortStopMarketPrice(Execution execution, String stopName)
		{
			return FindExitShortStopPrice(execution, stopName, ESwingLevelPolicy.Percentage, stopPointsMinimum);
		}

		double FindExitShortStopMarketVirtualPrice(Execution execution, String stopName)
		{
			return FindExitShortStopPrice(execution, stopName, ESwingLevelPolicy.Percentage, stopPointsMinimumVirtual);
		}

		double FindExitShortStopPrice(Execution execution, String stopName, ESwingLevelPolicy swingLevelPolicy, double minimumStopPoints)
		{
			double stopPrice = -1;
			if (IsSwingLevelPolicyStatic(swingLevelPolicy))
			{
				stopPrice = execution.Price + minimumStopPoints;
			}
			return stopPrice;
		}

		double GetPnLStopPriceShort(Execution execution, double currentPnL, double profitTarget, double lossLimit, double existingStopPrice)
		{
			if (currentPnL < profitTarget && currentPnL > -lossLimit)
			{
				double dollarsToStopLoss = currentPnL - (-lossLimit);
				double pointsToStopLoss = dollarsToStopLoss / Instrument.MasterInstrument.PointValue;
				double stopPricePnL = execution.Order.AverageFillPrice + (pointsToStopLoss / execution.Order.Filled);
				stopPricePnL = Instrument.MasterInstrument.RoundToTickSize(stopPricePnL);

				if (stopPricePnL < existingStopPrice || existingStopPrice == -1)
				{
					existingStopPrice = stopPricePnL;
				}
			}
			return existingStopPrice;
		}

		double FindExitShortLimitPrice(Execution execution)
		{
			return FindExitShortLimitPrice(execution, ESwingLevelPolicy.Percentage, targetPoints);
		}

		double FindExitShortLimitVirtualPrice(Execution execution)
		{
			return FindExitShortLimitPrice(execution, ESwingLevelPolicy.Percentage, targetPointsVirtual);
		}

		double FindExitShortLimitPrice(Execution execution, ESwingLevelPolicy swingLevelPolicy, double _targetPoints)
		{
			double limitPrice = -1;
			if (IsSwingLevelPolicyStatic(swingLevelPolicy))
			{
				limitPrice = Positions[dataSeriesToTrade].AveragePrice - _targetPoints;
			}
			return limitPrice;
		}


		/*
		 *	STOPS
		 */

		[Display(Name = "Enable Stop Loss", Description = "", Order = 1, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public bool EnableSwingStop
		{ get; set; }

		[Display(Name = "Trail Stop Loss", Description = "Works only if Stop Loss is on. This will move the stop order with market.", Order = 2, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public bool EnableTrailStop
		{ get; set; }

		[Display(Name = "Trail Stop Algo", Description = "How to move the stop. TrailAlways moves the stop on any favorable price move even if trade is losing. TrailWinning moves the stop only if the trade is better than entry price.", Order = 3, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public ETrailStopAlgo TrailStopAlgo
		{ get; set; }

		[Display(Name = "Price Level Policy", Description = "How to use swings. NearestSwing finds recent swing high or low, AverageSwing averages last 5 swings. Percentage does not use swings- Deviation Value not used, Stop Value Value are Price * Stop value to get price delta.", Order = 4, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public ESwingLevelPolicy StopSwingLevelPolicy
		{ get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "DeviationValue", Description = "Controls sensitivity of swing detection. Used only if Price Level Policy is NearestSwing or AverageSwing. ", GroupName = "03. Stop Loss", Order = 5)]
		public double StopSwingDeviationValue
		{ get; set; }

		[Display(Name = "Stop Value", Description = "Stop loss percentage (for Price level Policy: Percentage, else the minimum stop percentage for any other Price Level Policy)", Order = 7, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public double SwingStopLossMinimum
		{ get; set; }

		[Display(Name = "Trigger Stop", Description = "Trail the stop only after a price level is reached. Works with Trigger Stop Value.", Order = 10, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public bool EnableTriggerStop
		{ get; set; }

		[Display(Name = "Trigger Stop Value", Description = "Profitable price level percentage to reach before moving the stop.", Order = 11, GroupName = "03. Stop Loss"), NinjaScriptProperty]
		public double TriggerStopValue
		{ get; set; }

		/*
		 * TARGETS
		 */

		[Display(Name = "Enable Targets", Description = "", Order = 11, GroupName = "04. Targets"), NinjaScriptProperty]
		public bool EnableSwingTarget
		{ get; set; }

		[Display(Name = "Trail Target", Description = "Works only if Target Limit is on. This will move the limit target toward average price as market moves agains position.", Order = 12, GroupName = "04. Targets"), NinjaScriptProperty]
		public bool EnableSwingTargetTrail
		{ get; set; }

		[Display(Name = "Price Level Policy", Description = "How to use swings. NearestSwing finds recent swing high or low, AverageSwing averages last 5 swings. Percentage does not use swings- Deviation Value not used, Target Value are Price * Target value to get price delta.", Order = 16, GroupName = "04. Targets"), NinjaScriptProperty]
		public ESwingLevelPolicy TargetSwingLevelPolicy
		{ get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation Value", Description = "Controls sensitivity of swing detection. Used only if Price Level Policy is NearestSwing or AverageSwing. ", GroupName = "04. Targets", Order = 17)]
		public double TargetSwingDeviationValue
		{ get; set; }


		[Display(Name = "Target Value", Description = "Target limit percentage (for Price level Policy: Percentage, else the minimum target percentage for any other Price Level Policy)", Order = 20, GroupName = "04. Targets"), NinjaScriptProperty]
		public double TargetValue
		{ get; set; }

		[Browsable(false)]
		[Display(Name = "Fade Target", Description = "Works only if Target Limit is on. This will move the limit target further away from average price as market moves against position.", Order = 22, GroupName = "04. Targets")]
		public bool EnableSwingTargetFade
		{ get; set; }

		[Browsable(false)]
		[Display(Description = "Swing Target Calculation Mode", Order = 23, GroupName = "04. Targets") ]
		public CalculationMode SwingTargetCalculationMode
		{ get; set; }

		[Display(Name = "Trail Speed", Description = "Speed or Initial Speed target moves with market. 1 means (1:1) target moves 1 point for every point market moves. A value of 0.5 means target moves half point for every point market moves. A value of 1.5 means target moves 1.5 points for every point market moves.", Order = 25, GroupName = "04. Targets"), NinjaScriptProperty,Range(-10,10)]
		public double TargetTrailSpeed
		{ get; set; }

		[Display(Name = "Trail Acceleration", Description = "Modifies Trail Speed by this value when trail needs to be moved. A value of 0 will not modify the trail speed. A value of 0.01 will add to trail speed making the trail speed accerate.", Order = 26, GroupName = "04. Targets"), NinjaScriptProperty,Range(0,100)]
		public double TargetTrailAcceleration
		{ get; set; }



		/*
		 * VIRTUAL STOP AND TARGET
		 */

		[Display(Name = "Enable Virtual Stop Target", Description = "When a virtual stop level is hit the target is moved exceptionally close using the target settings in this section.", Order = 1, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public bool EnableVirtualSwingStopAndTarget
		{ get; set; }

		[Display(Name = "Trail Virtual Stop Target", Description = "Trail the Virtual Stop Target with the market. Works only if Virtual Stop Target is enabled.", Order = 2, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public bool VirtualTrailSwingStopAndTarget
		{ get; set; }

		[Display(Name = "Stop Price Level Policy", Description = "How to use swings for the Stop. NearestSwing finds recent swing high or low, AverageSwing averages last 5 swings. Percentage does not use swings- Deviation Value not used, Stop Value Value are Price * Stop value to get price delta.", Order = 3, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public ESwingLevelPolicy VirtualStopSwingLevelPolicy
		{ get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "DeviationValue", Description = "Controls sensitivity of swing detection. Used only if Price Level Policy is NearestSwing or AverageSwing. ", GroupName = "05. Virtual Stop Target", Order = 5)]
		public double VirtualStopSwingDeviationValue
		{ get; set; }

		[Display(Name = "Stop Value", Description = "Stop loss percentage (for Price level Policy: Percentage, else the minimum stop percentage for any other Price Level Policy)", Order = 7, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public double VirtualSwingStopLossMinimum
		{ get; set; }

		[Display(Name = "Trail Target", Description = "Works only if Target Limit is on. This will move the limit target toward average price as market moves agains position..", Order = 12, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public bool VirtualSwingTargetTrail
		{ get; set; }

		[Display(Name = "Trail Speed", Description = "Speed or Initial Speed target moves with market. 1 means (1:1) target moves 1 point for every point market moves. A value of 0.5 means target moves half point for every point market moves. A value of 1.5 means target moves 1.5 points for every point market moves.", Order = 15, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty, Range(-10, 10)]
		public double VirtualTargetTrailSpeed
		{ get; set; }

		[Display(Name = "Target Price Level Policy", Description = "How to use swings for the Target. NearestSwing finds recent swing high or low, AverageSwing averages last 5 swings. Percentage does not use swings- Deviation Value not used, Target Value are Price * Target value to get price delta.", Order = 16, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public ESwingLevelPolicy VirtualTargetSwingLevelPolicy
		{ get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Deviation Value", Description = "Controls sensitivity of swing detection. Used only if Price Level Policy is NearestSwing or AverageSwing. ", GroupName = "05. Virtual Stop Target", Order = 17)]
		public double VirtualSwingDeviationValue
		{ get; set; }


		[Display(Name = "Target Value", Description = "Target limit percentage (for Price level Policy: Percentage, else the minimum target percentage for any other Price Level Policy)", Order = 20, GroupName = "05. Virtual Stop Target"), NinjaScriptProperty]
		public double VirtualTargetValue
		{ get; set; }





		[Browsable(false)]
		[Display(Description = "Swing Stop Loss Calculation Mode", Order = 25, GroupName = "06. Targets and Stops")]
		public CalculationMode SwingStopLossCalculationMode
		{ get; set; }

		[Browsable(false)]
		[Display(Name = "Max Stop Value", Description = "Maximum Stop Loss Value or Don't Trade it.", Order = 27, GroupName = "06. Targets and Stops")]

		public double SwingStopLossMaximum
		{ get; set; }

		[Display(Name = "Swing Point Margin", Description = "Points in front of swing to place target or past swing to place Stop for targets and stops based on swings", Order = 28, GroupName = "06. Targets and Stops"), NinjaScriptProperty]
		public double SwingPointMargin
		{ get; set; }


		[Display(Name = "Min Stop Ticks", Description = "Minimum ticks from entry price to submit stop order. It is risky to make this value small. NT will halt the strategy if the stop order is executable at the time of submission. This will leave your position abandoned.", Order = 29, GroupName = "06. Targets and Stops"), NinjaScriptProperty]
		public double StopOrderMinimumTicksFromClose
		{ get; set; }


		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> VirtualLongStop
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> VirtualShortStop
		{
			get { return Values[1]; }
		}


	}
}