#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class TestZOrderStrategyPrintAdded : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "TestZOrderStrategyPrintAdded";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				AddPlot(Brushes.Red, "BB");
			}
			else if (State == State.Realtime)
			{
				Print(ZOrder);
			}
			if(State == State.Historical)
{
//SetZOrder(5);

	Print(ZOrder);
}
		}

		protected override void OnBarUpdate()
		{
			
				Print(ZOrder);

		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			
			base.OnRender(chartControl, chartScale);
			SharpDX.Vector2 startPoint;
			SharpDX.Vector2 endPoint;
			
			startPoint = new SharpDX.Vector2(ChartPanel.X, ChartPanel.Y);
			endPoint = new SharpDX.Vector2(ChartPanel.X + ChartPanel.W, ChartPanel.Y + ChartPanel.H);
			
			float width = endPoint.X - startPoint.X;
			float height = endPoint.Y - startPoint.Y;
			
			if (!IsInHitTest)
			{
				SharpDX.Direct2D1.Brush areaBrushDx;
				areaBrushDx = Brushes.Red.ToDxBrush(RenderTarget);
				SharpDX.Direct2D1.SolidColorBrush customDXBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
				SharpDX.Color.DodgerBlue);
				
				SharpDX.RectangleF rect = new SharpDX.RectangleF(startPoint.X, startPoint.Y, width, height);
				
				RenderTarget.FillRectangle(rect, areaBrushDx);

				RenderTarget.DrawRectangle(rect, customDXBrush, 2);
				
				areaBrushDx.Dispose();
				customDXBrush.Dispose();
			}
			
		}
	}
}
