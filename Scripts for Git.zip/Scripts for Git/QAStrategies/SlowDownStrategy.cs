#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
using System.Threading;


//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class SlowDownStrategy : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SlowDownStrategy";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Realtime=false;
				DummyVar=5;
			}
			else if (State == State.Configure)
			{
				firstBar=false;
			}
			else if(State==State.DataLoaded)
			{
				Print("Bars are"+Bars.Count.ToString());	
			}
		}
    DateTime timeOfStart = DateTime.MinValue;
		private static int BuyEveryXBars = 0;
        private static int NextBartobuy = 0;
		bool firstBar=false;
		int barToCheckTime=0;
		protected override void OnBarUpdate()
		{
		
			if(firstBar==false)
			{
				
				Print("----------------------------");	
					Print("----------------------------");	
					Print("----------------------------");	
					Print("--------------Time between each 10 bars looped, printed to output window 2--------------");	
					timeOfStart = DateTime.Now;
				Print("Starting Strategy at "+DateTime.Now.ToShortTimeString());
				firstBar=true;	
				barToCheckTime=0;
			}
			else
			{
				
				
				
				barToCheckTime++;
				
				
				if(barToCheckTime>10)
				{
					barToCheckTime=0;
					
					TimeSpan ts = (DateTime.Now - timeOfStart);
					     NinjaTrader.Code.Output.Process(ts.TotalSeconds.ToString(), PrintTo.OutputTab2);
				
					
					timeOfStart = DateTime.Now;
					
				}
				
			}
			
			
		
    
			
			Print(Time[0].ToShortDateString());
			if(Realtime)
				if(State !=State.Realtime)
					return;
			
				double Dummy2= DummyVar;
				
			if(Position.MarketPosition == MarketPosition.Long)
			{
				if(BuyLogic(Close[0]))
					ExitLong();
			}
			else
			{
				if(BuyLogic(Close[0]))
					EnterLong();
			
			
			}
		}
			 
			
		public static bool BuyLogic(double d)
        {
            BuyEveryXBars++;
           
			try
            {           
				Thread.Sleep(50);

                if (IsOdd((int)d))
                {
                    if (BuyEveryXBars > NextBartobuy)
                    {
                        NextBartobuy = BuyEveryXBars + 5;

             
                        return true;
                    }

                        return false;
                  //  Console.WriteLine(i);
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                return false;
            }
        }

 

        private static bool IsOdd(int value)
        {
            return value % 2 != 0;
        }
			
			
					
		[ NinjaScriptProperty]
		[Display(Name = "Realtime", GroupName = "Realtime", Order = 0)]
		public bool Realtime
		{ get; set; }

[ NinjaScriptProperty]
		[Display(Name = "DummyVar", GroupName = "DummyVar", Order = 0)]
		public double DummyVar
		{ get; set; }
		
	}
}
