#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class UnmanagedSubmitMarketOrderCancelItASAP : Strategy
    {
        private Order entryOrder = null;
        private bool xOrderFilled;
        private bool xMoved;
        private int xCurrentBar;


        private Order entryOrder2 = null;
        private Order entryOrder3 = null;
        private bool xMoved2;
        private int xCurrentBar2;
        private bool xMoved3;
        private int xCurrentBar3;
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "UnmanagedSubmitMarketOrderCancelItASAP";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 5;
                EntryHandling = EntryHandling.UniqueEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.IgnoreAllErrors;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;

                IsUnmanaged = true;
            }
            else if (State == State.Configure)
            {
                xMoved = false;
                filledOrderString = "";

            }
        }



        protected override void OnBarUpdate()
        {

            if (State == State.Historical) return;
            if (CurrentBar < 10) return;

            if (xMoved == false)
            {
                SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 5, 0, "", "BuyentryOrder");

             
                xMoved = true;
          
            
            }

        }
    
        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
            Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);


        }
		
		string filledOrderString="";
	
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {
  
			Print(order.OrderId + "__" + order.OrderState.ToString());
			
			if(order.OrderState == OrderState.Filled)
			{	
				
				if(filledOrderString == order.Name.ToString()+ "__"+order.OrderState.ToString()+"__"+order.OrderId.ToString())
				{
               
                    Task.Run(() => MessageBox.Show("Issue hit, same filled order updated twice.", "BINGO", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));

					

				}
                else
                    filledOrderString = order.Name.ToString() + "__" + order.OrderState.ToString() + "__" + order.OrderId.ToString();
	
			}
					
			if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Working))
				      CancelOrder(entryOrder);
						
						
			if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Submitted))
				    entryOrder = order;
			

         

			//Original hitting error with 
//            if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
//            {
//                Print("BuyentryOrder assigned");

//                entryOrder = order;
				
//				Print("Cancel Order being called");
           
//				     CancelOrder(entryOrder);


//            }

            if (order.Name == "BuyentryOrder" && order.OrderState == OrderState.Filled)
            {
				
			
              	
				
				Print(order.Name.ToString()+ "__"+order.OrderState.ToString()+"__"+order.OrderId.ToString());
				

				SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, 1,  order.AverageFillPrice + 50 * TickSize,0, "", "SellLimitOrder");
            
				SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, order.AverageFillPrice - 50 * TickSize, "", "SellStopOrder");
				
			}

            //			filledCounterOrderUpdate = filledCounterOrderUpdate + quantity;
            //			if (order.Name == "BuyentryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            //			{


            //				Print("BuyentryOrder set to null");

            //				xMoved=false;
            //				entryOrder = null;  //Should I do this here?


            //			}


        }


    }
}
