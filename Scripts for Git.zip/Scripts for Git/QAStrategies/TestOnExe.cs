#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class TestOnExe : Strategy
	{


		//Apply to 5 second chart, MYM
		/*
			Wait till error goes off, this find when OnPositionupdate is not fired.
		https://ninjatrader.atlassian.net/browse/NTEIGHT-15116
		
		 * */


		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "TestOnExe";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.ByStrategyPosition;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
			triggeredError=false;
				OPUCalled	=	false;
				orderSentOn=0;
				doonce=false;
				restartBar=0;
			}
		}
		
		private bool doonce;
		bool triggeredError;
		
		int orderSentOn;
		protected override void OnBarUpdate()
		{
			if(State == State.Realtime && !doonce)
			{
				orderSentOn=CurrentBar;
				triggeredError = false;
				OPUCalled=false;
				EnterLong(1, "TestLong");
				doonce = true;
			}
			else
			{
				if(doonce==true)
				{						
					{
						if(restartBar+ 2 > CurrentBar  && OPUCalled ==true )
						{

							ExitLong("TestLong");
							doonce=false;
							restartBar=0;
				
						}
					}
				}
			
			}
		}
		int restartBar=0;
		bool OPUCalled;
		protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
		{
//			if (position.MarketPosition == MarketPosition.Long)
//			{
//				ExitLongLimit(0,true,quantity,averagePrice+ 50, "TestLongProfit", "TestLong");
//				ExitLongStopMarket(0,true,quantity,averagePrice - 50, "TestLongSL", "TestLong");
				
//				restartBar=CurrentBar;
			
			
//			}
			OPUCalled=true;
			Print(Time[0] + "Cbi.Position: " + position   + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);	
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{		
			if (execution.Name == "TestLong")
			{
					//	Print2("execution.Order.Quantity"+execution.Order.Quantity.ToString());
			//	Print2("execution.Order.Filled"+execution.Order.Filled.ToString());
					
				ExitLongLimit(0,true,1,execution.Order.AverageFillPrice+ 20, "TestLongProfit", "TestLong");
				ExitLongStopMarket(0,true,1,execution.Order.AverageFillPrice - 20, "TestLongSL", "TestLong");		
			}
		}
		
			bool waitingOnAllPTs;
		bool waitingOnAllSLs;
		
	private void Print2(string s)
        {
            //	NinjaTrader.Code.Output.Process((s.ToString())


            NinjaTrader.Code.Output.Process(s.ToString(), PrintTo.OutputTab2);
            //	NinjaTrader.NinjaScript.NinjaScript.Log(DateTime.Now.ToString()+"__"+s.ToString(), NinjaTrader.Cbi.LogLevel.Error);
        }

	}
}
