#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class UnmanagedSubmit2Entries2DiffInstrumentsSubmitSLinOPU : Strategy
    {


        //Apply to 1 second chart, MYM
        /*
		
		INCOMPLETE AS OF 9-28-22, still working on it.
		
			Submits 2 entry orders to two different series, then submits SL for each.  
		
			Want to see 1 of those series having an unprotected positoin.
		
		
		
		 * */


        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "UnmanagedSubmit2Entries2DiffInstrumentsSubmitSLinOPU";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 10;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
				 IsUnmanaged = true;
            }
            else if (State == State.Configure)
            {  
					
				AddDataSeries("MNQ 12-22");
				currentPos=0;
				orderCounter = 0;
				   filledCounterExecution = 0;
                filledCounterOrderUpdate = 0;
                triggeredError = false;
                OPUCalled = false;
                orderSentOn = 0;
                doonce = false;
                restartBar = 0;
            }
        }
       int filledCounterExecution;
        int filledCounterOrderUpdate;
        private bool doonce;
        bool triggeredError;
      int orderCounter;
		string orderName0;
        string orderName1;
        int orderSentOn;
        protected override void OnBarUpdate()
        {			
			if(triggeredError == true) 
			{
				Print("ERRORRRR HIT, returning to exam if PT/SL are working");
				return;
            
			}
			if(BarsInProgress != 0) return;
			
			
            if (State == State.Realtime && doonce ==false)
            {
					orderCounter++;
                orderSentOn = CurrentBar;
                triggeredError = false;
                OPUCalled = false;
				 
				SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0, 0, "", "TestLong1");
				SubmitOrderUnmanaged(1, OrderAction.Buy, OrderType.Market, 1, 0, 0, "", "TestLong2");
			//	SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0, 0, "", orderName0);
			//	SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0, 0, "", orderName1);
				 
			

         //       EnterLong(1, "TestLong1");
				  
			//	EnterLong(1, "TestLong2");
                doonce = true;
            }
            else
            {
                return;  //remove, just trying to simplfy script


                if (doonce == true)
                {

                    if (OPUCalled == false)
                    {
                        if (CurrentBar > orderSentOn) //wait 15 seconds

                            if (triggeredError == false)
                            {

                                triggeredError = true;
								
								Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!  Missed a position update"+"__"+Name+"__"+Instruments[0].FullName);
								
								
                                Task.Run(() => MessageBox.Show("Hit Issue, OnPositionUpdate not called on entry order,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));


                            }
                    }



                    else
                    {
                        if (restartBar + 2 > CurrentBar && OPUCalled == true)
                        {

//                            ExitLong("TestLong1");
//							ExitLong("TestLong2");
                            doonce = false;
                            restartBar = 0;

                        }
                    }
                }

            }
        }
        int restartBar = 0;
        bool OPUCalled;
		
	
        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
			 Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);
            
			   if (position.Instrument.FullName == Instruments[0].FullName)
			   {	
				   SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, 1, 0, averagePrice -50 *TickSize, "", "TestLongSL1");
		
				   
			   }
			  if (position.Instrument.FullName == Instruments[1].FullName)
			   {
				   		
				   SubmitOrderUnmanaged(1, OrderAction.Sell, OrderType.StopMarket, 1, 0, averagePrice-60 *TickSize, "", "TestLongSL2");

				   
			   }
			
		

                restartBar = CurrentBar;


            
			
            OPUCalled = true;
            Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);
        }
 
	
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {			
		
            Print("OOU " + order.OrderState + "__" + order.OrderType + "_" + order.AverageFillPrice);

            if (order.OrderState == OrderState.Filled)
                filledCounterOrderUpdate = filledCounterOrderUpdate + quantity;
		}
 
			
		
			
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {  
		
		  int incomingFill = execution.Quantity;

                if (execution.MarketPosition == MarketPosition.Short)
                    incomingFill = execution.Quantity * -1;


            currentPos = currentPos + incomingFill;

       
				
				Print("Current Posiiton is"+ currentPos.ToString());
			
			NinjaTrader.Code.Output.Process("Quantity__"+ quantity.ToString(), PrintTo.OutputTab2);
			
            filledCounterExecution = filledCounterExecution + quantity;

        }
		 
		int currentPos;
	
     
        
    }
}
