#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	
	/*
		Strategy submits OCO's, as they fill it submits more OCO's.  
	Used for testing unexpected position updates for  rithmic testing, 
	https://ninjatrader.atlassian.net/browse/NTEIGHT-15264
			
	
	
	*/
	public class SubmitOCOsThenMoreAsOCOsFill : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SubmitOCOsThenMoreAsOCOsFill";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 20;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				SetStopLoss(CalculationMode.Ticks,10);
				SetProfitTarget(CalculationMode.Ticks,10);
				submitMoreOrders = true;
				orderFillCounter=0;
			}
		}
		

		protected override void OnBarUpdate()
		{
		if(State !=State.Realtime)
			return;
		
		
		if(orderFillCounter>10)
		{
			Print("10 stops or targets filled, so calling close all positions, see if we get postion update after this in trace");
			    CloseStrategy("My Custom Close");
			
		}
		else
			Print("orderFillCounter"+ orderFillCounter.ToString());

		if(submitMoreOrders)
		{
			if(Position.Quantity<8) 
			{
					EnterLong(CurrentBar.ToString());
				
			}			
			else
			{
				submitMoreOrders=false;
			}
		
		
		
		}

		}
			int orderFillCounter;
		bool submitMoreOrders;
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
					
					Print("Unable To Change Order");

				}
			}


			
		if ((order.Name =="Stop Loss" && (order.OrderState == OrderState.Filled) || (order.Name =="Profit Target" && order.OrderState == OrderState.Filled)))
orderFillCounter++;
			
			if (order.Name =="Stop Loss" && (order.OrderState == OrderState.Filled || order.OrderState == OrderState.Cancelled))
			{
			submitMoreOrders=true;
			Print("Stop Loss filled");
				
			}
			
			if (order.Name =="Profit Target" && ( order.OrderState == OrderState.Filled || order.OrderState == OrderState.Cancelled))
			{
					submitMoreOrders=true;
			Print("profit target filled");
			
				
			}
		
		}
	}
}
