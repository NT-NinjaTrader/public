#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class ReversalTestCloseSubmittedAfterEntryThrowsErrorBox : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name						= "ReversalTestCloseSubmittedAfterEntryThrowsErrorBox";
				Calculate					= Calculate.OnBarClose;
				TraceOrders					= true;
				AllowHistorical				= false;
				
					 lastBuyOrderName="";
		 lastSellorderName="";
				
				TicksStop=10;
			}
		}

		protected override void OnBarUpdate()
		{
			if (!AllowHistorical && State != State.Realtime)
				return;
	//Print("BarsSince"+BarsSinceEntryExecution().ToString());
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				EnterLong("entry");
			//	Print("Called EnterLong");
			//	Print("BarsSince"+BarsSinceEntryExecution().ToString());
			}
			else if (Position.MarketPosition == MarketPosition.Long && BarsSinceEntryExecution() > 1)
				EnterShort("reversalshort");

		}

		
		string lastBuyOrderName="";
		string lastSellorderName="";
		
DateTime firstOrderBuyTime;
		DateTime firstOrderSellTime;	
		protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
			Print(Position.MarketPosition+"___"+execution.Order.Name);
			
			
			

			
				if(	execution.Order.OrderAction == OrderAction.Buy  || 	execution.Order.OrderAction == OrderAction.BuyToCover)
				{
					
					if(lastBuyOrderName.Equals(""))
					{
						lastBuyOrderName=execution.Order.Name;
						
						lastSellorderName="";
						firstOrderBuyTime = execution.Time;
					}
					else
					{
						if(execution.Order.Name.Equals("Close position"))
						{
							
							
										
						
							Print2("***************************");
							
							Print2("Bingo, error hit, Close Position came in after other order");
					
										
							Print2(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
							
							Print2(Instrument.FullName);
			
							Print2("First Order"+"__"+firstOrderBuyTime.ToString("yyyy-MM-dd HH:mm:ss.fff") +"__"+ lastBuyOrderName.ToString() );
							Print2("Second Order"+"__"+execution.Time.ToString("yyyy-MM-dd HH:mm:ss.fff")	+"__"+ execution.Order.Name);
							Print2("***************************");
							
							Task.Run(() => MessageBox.Show("Hit Error,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));

						}
//						else
//							Print("good");
					}
				}
								
							
			
			
			if(	execution.Order.OrderAction == OrderAction.SellShort  || 	execution.Order.OrderAction == OrderAction.Sell) 
			{
					
					if(lastSellorderName.Equals(""))
					{
						lastSellorderName	=	execution.Order.Name;
						lastBuyOrderName="";
						firstOrderSellTime = execution.Time;
					}
					else
					{
						if(execution.Order.Name.Equals("Close position"))
						{
							
							Print2("***************************");
							
							Print2("Bingo, error hit, Close Position came in after other order");
				
							Print2(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
								Print2(Instrument.FullName);
						
							Print2("First Order:  "+firstOrderSellTime.ToString("yyyy-MM-dd HH:mm:ss.fff") +"__"+ lastSellorderName.ToString() );
							Print2("Second Order:  "+execution.Time.ToString("yyyy-MM-dd HH:mm:ss.fff")+"__"+ execution.Order.Name);
						
							Print2("***************************");
							
							Task.Run(() => MessageBox.Show("Hit Error,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));
							
						}
//							else
//								Print("good");
					}
				
				
			}
			
			
			
			
			
			
			if((Position.MarketPosition+"___"+execution.Order.Name).Equals("Long___Close position"))
			{
								
						
					
				
				Print("------------------------------------------------");				
				Print("----------------   ISSUE REPLICATED-------------------"+  Instrument.FullName+"__"+DateTime.Now.ToString());
				Print("------------------------------------------------");
				Print(NinjaTrader.Core.Globals.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));	
				Print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
			
				Print(" Close Position execution came after reversallong, causing PT/SL to not be submitted for reversal order");
				Print("------------------------------------------------");
			}
			
			if((Position.MarketPosition+"___"+execution.Order.Name).Equals("Short___Close position"))
			{
					
				//Print2("----------------   ISSUE REPLICATED-------------------"+  Instrument.FullName+DateTime.Now.ToString());			
			//	Print2(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
				
				Print("------------------------------------------------");			
				Print("------------------------------------------------");
				Print("----------------   ISSUE REPLICATED-------------------"+  Instrument.FullName+"__"+DateTime.Now.ToString());			
				Print(NinjaTrader.Core.Globals.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
				Print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));							
				Print(" Close Position execution came after reversalshort, causing PT/SL to not be submitted for reversal order");
				Print("------------------------------------------------");
				
			}
	
			if (execution.Order.Name == "entry")
			{
				ExitLongLimit(0, true, quantity, Position.AveragePrice + TicksStop * TickSize, "target", "entry");
				ExitLongStopMarket(0, true, quantity, Position.AveragePrice - TicksStop * TickSize, "stop", "entry");
			}
			else if (execution.Order.Name == "reversalshort")
			{
				ExitShortLimit(0, true, quantity, Position.AveragePrice - TicksStop* TickSize, "shorttarget", "reversalshort");
				ExitShortStopMarket(0, true, quantity, Position.AveragePrice + TicksStop * TickSize, "shortstop", "reversalshort");
			}
		}

//		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
//		{
//			if (marketPosition == MarketPosition.Long)
//			{
//				ExitLongLimit(0, true, quantity, averagePrice + 30 * TickSize, "target", "entry");
//				ExitLongStopMarket(0, true, quantity, averagePrice - 30 * TickSize, "stop", "entry");
//			}
			
//			if (marketPosition == MarketPosition.Short)
//			{
//				ExitShortLimit(0, true, quantity, averagePrice - 30 * TickSize, "shorttarget", "reversalshort");
//				ExitShortStopMarket(0, true, quantity, averagePrice + 30 * TickSize, "shortstop", "reversalshort");
//			}
//		}
 
		public static void Print2(string s)
        {
            //	NinjaTrader.Code.Output.Process((s.ToString())


            NinjaTrader.Code.Output.Process(s.ToString(), PrintTo.OutputTab2);
            //	NinjaTrader.NinjaScript.NinjaScript.Log(DateTime.Now.ToString()+"__"+s.ToString(), NinjaTrader.Cbi.LogLevel.Error);
        }
		[NinjaScriptProperty]
		public bool AllowHistorical
		{ get; set; }
		
				
		[NinjaScriptProperty]
		public int TicksStop
		{ get; set; }
	}
}
