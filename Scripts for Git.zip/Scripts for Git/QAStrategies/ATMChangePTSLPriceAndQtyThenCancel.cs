#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class ATMChangePTSLPriceAndQtyThenCancel : Strategy
	{
		
		/*
			You can either submit/fill ATM on DOM and apply strategy, or have strategy enter.
		
			ATM should be named ATMForNS.
		
		
			Strategy will modify stop/target quantity 2 times, then it will modify price.
		
		
		
		
		
		*/
		
		
		bool filledEntry=false;
	
		int targetQuantityChangedTo_Round2 = 0;
bool showedError=false;
bool isAtmStrategyCreated;
double originalTargetPrice=0;
int barSubmittedChangeOn=0;
int targetQuantityChangedTo;
int stopQuantityChangedTo;
bool TargetPriceChanged;
bool stopQuantityChanged;
bool submitEntryATM=false;
string orderId="";
int entryBar=0;
		
bool doASecondTime;
			Order targetOrder;
		
		Order stopOrder;
	private string  atmStrategyId			= string.Empty;
		private bool DoOnce=false;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "ATMChangePTSLPriceAndQtyThenCancel";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
				
			else if (State== State.Configure)
			{
				filledEntry=false;
				targetQuantityChangedTo_Round2 = 0;
				doASecondTime=false;
				TargetPriceChanged =false;
				targetQuantityChangedTo =0;
	
				stopQuantityChanged		=	false;
				stopQuantityChangedTo 	=	0;
				
				originalTargetPrice		=	0;
				submitEntryATM=false;
				isAtmStrategyCreated=false;
				 entryBar=0;
				matchedPTSL=false;
				atmStrategyId = string.Empty;

			}
			   else if (State == State.DataLoaded)
            {
				Print("Printing account");
				
				Print(Account.Name.ToString());
							//double plotUnrealizedProfitLoss = Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
			//	lock (Account.All)
           		//   MainAccount = Account.All.FirstOrDefault(a => a.Name == "Sim101");
				//No need to lookup account.
				//Account	=	Account;
				
			     //Account.AccountStatusUpdate += OnAccountStatusUpdate;
//                Account.AccountItemUpdate += OnAccountItemUpdate;
//                Account.ExecutionUpdate += OnAccountExecutionUpdate;
			
                foreach(Order order in Account.Orders) //First foreach loop, to get working orders
                {
					
					if(order.OrderState == OrderState.Working)  //This will print all working orders on the account
						Print("This order is working"+order.ToString());
					
					if (order.GetOwnerStrategy() != null && order.GetOwnerStrategy().Name == "AtmStrategy")
                    {
						
						if(order.Name =="Stop1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
						{
							stopOrder=order;
						//	Print("The order ID of the Stop is"+ order.OrderId.ToString());
						}
						
						if(order.Name =="Target1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
						{
							targetOrder=order;
						//	Print("The order ID of the Stop is"+ order.OrderId.ToString());
						}

                    }
                }
				
				
				//foreach(Position pos in Account.Positions) ///2nd For each loop, which will print open positions on the acccount.
				//{
				//	  	Print("Position is in"+pos.ToString());
				//}
					  
				
					  
            }
		}
bool matchedPTSL=false;
	
		protected override void OnBarUpdate()
		{
			if(State != State.Realtime) return;
		//DateTime EnterTime=new DateTime(2021,12,23,09,1,1);
			//	DateTime endTime=new DateTime(2021,12,23,09,3,1);
			
		//	if(Time[0]> EnterTime && 		Time[0]<endTime)
			if(atmStrategyId.Length<1)
			{
			entryBar=CurrentBar;
				 atmStrategyId = GetAtmStrategyUniqueId();
				string	orderId = GetAtmStrategyUniqueId();
					AtmStrategyCreate(OrderAction.Buy, OrderType.Limit, GetCurrentBid() - 2 * TickSize, 0, TimeInForce.Gtc, orderId, "ATMForNS", atmStrategyId, (atmCallbackErrorCode, atmCallBackId) =>
					{
						//check that the atm strategy create did not result in error, and that the requested atm strategy matches the id in callback
						if (atmCallbackErrorCode == ErrorCode.NoError && atmCallBackId == atmStrategyId)
							isAtmStrategyCreated = true;
					});	
			}
		
				if(isAtmStrategyCreated && matchedPTSL==false)
				{
					foreach(Order order in Account.Orders) //First foreach loop, to get working orders
	                {
								if (order.GetOwnerStrategy() != null)
	
						//if (order.GetOwnerStrategy().Name == atmStrategyId)

                        {


                     
						if(order.OrderState == OrderState.Working || order.OrderState == OrderState.Accepted)  //This will print all working orders on the account
							Print("This order is working"+order.ToString());
						
						try
						{
					
						//	if (order.GetOwnerStrategy().Name == "AtmStrategy")
			                    {
									
									if(order.Name =="Stop1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
									{
										matchedPTSL=true;
										stopOrder=order;
									//	Print("The order ID of the Stop is"+ order.OrderId.ToString());
									}
									
									if(order.Name =="Target1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
									{
										matchedPTSL=true;
										targetOrder=order;
									//	Print("The order ID of the Stop is"+ order.OrderId.ToString());
									}

			                    }
							}
							catch(Exception ex)
							{
								Print(ex.ToString());	
							}
	                }
				}
			}
				
				if(matchedPTSL)
				{
				
						if(CurrentBar + 2 > entryBar)  //entry bar woudl always be zero if strategy ddin't open position
						{
					
							if(DoOnce ==false )  ///On first BarUpdate, the stop price will be modified and reduced by 4 ticks.
							{
								

								DoOnce =true;  //So this block doesnt run again.
								
								if(stopOrder != null)
								{
									barSubmittedChangeOn=CurrentBar;
						
									
									stopQuantityChanged 	= false;
									stopQuantityChangedTo 	=	stopOrder.Quantity	+	2;
								stopOrder.QuantityChanged =	stopQuantityChangedTo;
								Account.Change(new[] { stopOrder });  //Submits change order call.
							
							}
							else
							{
							
									Print("	(stopOrder == null)");
							}
							
							if(targetOrder != null)
							{
								
							
								barSubmittedChangeOn	=	CurrentBar;
							
						
								originalTargetPrice	=	targetOrder.LimitPrice ;
								TargetPriceChanged =	false;
								
									
						
								targetOrder.LimitPriceChanged = targetOrder.LimitPrice + 40 * targetOrder.Instrument.MasterInstrument.TickSize;  //Modifies the stopOrder order object
				
									
						
				
								Account.Change(new[] { targetOrder });  //Submits change order call.

							}
								
							else
							{
							
									Print("	(targetOrder == null)");
							}
						
					
				
					
				
						
						}
			
					else if(doASecondTime == false)
	                {
						doASecondTime = true;  //So this block doesnt run again.

						if (stopOrder != null)
						{
							barSubmittedChangeOn = CurrentBar;


							stopQuantityChanged = false;
							stopQuantityChangedTo = stopOrder.Quantity -1;
							stopOrder.QuantityChanged = stopQuantityChangedTo;
							Account.Change(new[] { stopOrder });  //Submits change order call.

						}
						

						if (targetOrder != null)
						{

					
							//Will add 1 contract to ATM, and subtract 10 ticks from profit price.


							
							barSubmittedChangeOn = CurrentBar;


							originalTargetPrice = targetOrder.LimitPrice;
							TargetPriceChanged = false;

							targetQuantityChangedTo_Round2 = targetOrder.Quantity +1;

							targetOrder.LimitPriceChanged = targetOrder.LimitPrice - 10 * targetOrder.Instrument.MasterInstrument.TickSize;  //Modifies the stopOrder order object



							targetOrder.QuantityChanged = targetQuantityChangedTo_Round2;
							Account.Change(new[] { targetOrder });  //Submits change order call.


						}

					}

					}

						
				
			

	
	
			
			}


		}

		
	
			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{


			Print("OnOrderUPdate"+order.Name.ToString());
				
			if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
						
				}
			}
			
			

			//TARGET AND STOP WOULD BE ASSIGNED ORDER OBJECTS IN STATE.DATA LOADED WHEN THIS ATM WAS SUBMITTED OUTSIDE STRATEGY

			if (OpenATMPositionInsteadOfManageOpenATM == true)
			{
				
				
				if(  filledEntry.Equals("Buy"))
				{
					filledEntry=true;
				}
				
			

				if (order.Name == "Target1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
				{

					if (order.OrderState == OrderState.Filled || (order.OrderState == OrderState.Cancelled))
						targetOrder = null;
					else
						targetOrder = order;



				}
				if (order.Name == "Stop1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
				{

					if (order.OrderState == OrderState.Filled || (order.OrderState == OrderState.Cancelled))
						stopOrder = null;
					else
						stopOrder = order;

				}

			}





			if (order.Name == "Stop1")						
			{

				
				if (order.OrderState == OrderState.Working)
				{
					if(order.Quantity == 3)
					{				
						stopQuantityChanged=true;					
					}
				}
			
			}			
			if (order.Name == "Target1")						
			{
				if (order.OrderState == OrderState.Working)
					{
						if(order.LimitPrice !=originalTargetPrice)
						{				
							TargetPriceChanged=true;					
						}
					}
			
			}		
			
	
		
		
		}


		[NinjaScriptProperty]
		[Display(Name = "OpenATMPositionInsteadOfManageOpenATM", Order = 22, Description = "If checked will open ATM position using ATMforNS template, otherwise you open one on dom and strategy will manage it", GroupName = "ReadDescription")]
		public bool OpenATMPositionInsteadOfManageOpenATM
		{ get; set; }
	
	}
}
