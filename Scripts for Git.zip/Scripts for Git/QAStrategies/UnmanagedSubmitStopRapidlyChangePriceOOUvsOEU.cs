#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class UnmanagedSubmitStopRapidlyChangePriceOOUvsOEU : Strategy
    {

        //Strategy will submit Stopmarket on the market, then keep changing it back and forth 1-2 ticks from best bid/offer trying to get a rejection.
        // trying to reproduce OnOrderUpdate being called twice for fill because of order rejection, causing scan_Obj.Posiiton object not to match actual position.
        //If when order is rejected and OnExecutionUpdate and OnOrderUpdate fills do not matchj, throw a message box.

        //Created for "OnOrderUpdate called twice for same order" Jira https://ninjatrader.atlassian.net/browse/NTEIGHT-15380

        private Order entryOrder = null;

				
		double OEUAvgPrice=0;
		double OOUAvgPrice=0;
				
		int OEUPosition=0;
		int OOUPosition=0;
        private DateTime xSentTime;
        bool issueHit;
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "UnmanagedSubmitStopRapidlyChangePriceOOUvsOEU";
                Calculate = Calculate.OnPriceChange;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
                IsUnmanaged = true;
            }
            else if (State == State.Configure)
            {
				
				OEUAvgPrice=0;
		
				OOUAvgPrice=0;
				OEUPosition=0;
				OOUPosition=0;
                filledCounterExecution = 0;
                filledCounterOrderUpdate = 0;
                issueHit = false;

                printedAlready = false;
                printedAlready2 = false;
                xMoved = false;
            }
        }


        bool xMoved;
        bool printedAlready;
        bool printedAlready2;
        protected override void OnBarUpdate()
        {
			
			
			
            if (State == State.Historical) return;

			if(OOUPosition != OEUPosition)
			{
				Print("OOU Position "+ OOUPosition.ToString()+"___"+"OEUPosition" +OEUPosition.ToString());
				
				
				
			}
			

            if (CurrentBar < 10) return;

            if (filledCounterOrderUpdate != filledCounterExecution)
            {
                if (printedAlready == false)
                {


                    printedAlready = true;

                    Print("Execution fill count does not match that of OnOrderUpdate");

                    Print("OrderUpdate Fill Counter = " + filledCounterOrderUpdate.ToString());
                    Print("OnExecution Fill Counter = " + filledCounterExecution.ToString());

                    //					Print("filledCounterOrderUpdate!=filledCounterExecution");
                }
            }



            if (issueHit)
            {
                if (printedAlready2 == false)
                {
                    printedAlready2 = true;
                    Print("issue hit, returning.  LOOK FOR ORDER = XXXX | nAME=SELLSHORTlIMITbEAR | NEW STATE == FILLED");

                }

                return;
            }

            if (xMoved != true)
            {
                xMoved = true;
                SubmitOrderUnmanaged(0, OrderAction.SellShort, OrderType.StopMarket, 1, 0, GetCurrentAsk(0) - 5 * TickSize, "", "myEntryOrder");
                //	EnterShortStopMarket(,"myEntryOrder");					

            }
            if (entryOrder != null)
            //	else
            {

                if (CurrentBar % 2 == 0)
                    ChangeOrder(entryOrder, 1, 0, GetCurrentBid() - 3 * TickSize);

                else
                    ChangeOrder(entryOrder, 1, 0, GetCurrentBid() - 4 * TickSize);


            }


        }



        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {
            Print(Time[0] + "Cbi.Position: " + position + "	Cbi.MarketPosition: " + marketPosition + "  Strategy Position.MarketPosition: " + Position.MarketPosition);
        }

        int filledCounterExecution;
        int filledCounterOrderUpdate;
        int filledCounter;
        protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
			
			
				
            filledCounterExecution = filledCounterExecution + SetPositionObjectOnFill(execution);
			

     

        }

   
		public  int SetPositionObjectOnFill(NinjaTrader.Cbi.Execution execution)
        {
						
			
			
            int incomingFill = 0;
        //    if (order.OrderState == OrderState.Filled)
            

                incomingFill = execution.Quantity;

                if (execution.MarketPosition == MarketPosition.Short)
                    incomingFill = execution.Quantity * -1;


            
				OEUAvgPrice = execution.Price; 
			
				OEUPosition=	OEUPosition	+	incomingFill;
				
				return incomingFill;

            //    R.Risk.SetPositionObjectOnFill_Child(Scan_Obj, APBars, incomingFill, orderFillPrice);
            
        }
		  
		public  int SetPositionObjectOnFill(NinjaTrader.Cbi.Order order)
        {
            int incomingFill = 0;
            if (order.OrderState == OrderState.Filled)
            {

                incomingFill = order.Filled;

                if (order.IsShort)
                    incomingFill = order.Filled * -1;


              
				OOUAvgPrice = order.AverageFillPrice;

				OOUPosition = OOUPosition + incomingFill;
				
				return incomingFill;
				
               // R.Risk.SetPositionObjectOnFill_Child(Scan_Obj, APBars, incomingFill, orderFillPrice);
            }
			return 0;
        }
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {
            Print("OOU " + order.OrderState + "__" + order.OrderType + "_" + order.AverageFillPrice);

            if (order.OrderState == OrderState.Filled)
			{
//				SetPositionObjectOnFill(order);

				               
				filledCounterOrderUpdate = filledCounterOrderUpdate + SetPositionObjectOnFill(order);
			}

            if (order.OrderState == OrderState.Rejected)
            {
                Print("order Rejected");
                Print("Issue hit, strop running strategy");
                issueHit = true;



                if (filledCounterOrderUpdate != filledCounterExecution)
                {

                    Print("Count of filled orders in On Execution Update do not match Orders Filled in OnOrderUpdate.");
                    Task.Run(() => MessageBox.Show("AWESOME, Issue Hit,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));


                }

                return;


            }



            if (error != ErrorCode.NoError)
            {
                if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{

                    Print("Unable To Change Order");

                }
            }




            if (order.Name == "myEntryOrder" && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {


                Print("myEntryOrder assigned");
                entryOrder = order;


            }

            if (order.Name == "myEntryOrder" && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                entryOrder = null;  //Should I do this here?


            }
        }


    }
}
