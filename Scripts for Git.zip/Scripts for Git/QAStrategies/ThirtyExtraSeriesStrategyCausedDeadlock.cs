#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

namespace NinjaTrader.NinjaScript.Strategies{
	public class ThirtyExtraSeriesStrategyCausedDeadlock : Strategy{
		
		#region Class attributes
		Char sep = ',';
		#endregion
		
		#region System
		protected override void OnStateChange(){
			if (State == State.SetDefaults){
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "ThirtyExtraSeriesStrategyCausedDeadlock";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= false;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				ConfigFile = @"C:\Users\APalmer\Documents\NinjaTrader 8\TEST43.csv";
				SLPercentage = 0.1;
			}
			else if (State == State.Configure)
			{
//				string[] lines = File.ReadAllLines(ConfigFile);
				
//				int lastLine = 1;
//				for (lastLine = 1;lastLine < lines.Length;lastLine++)
//				{
//					if (lines[lastLine].Split(sep)[1] == "") break;
//				}
//				lastLine -= 1;
//				Print(lastLine);
					
//				for (int i = 1;i <= lastLine;i++)
//				{
//					string[] values = lines[i].Split(sep);
					
//					Print("AddDataSeries(\""+values[1]+"\",BarsPeriodType.Minute, 1);");
//					AddDataSeries(values[1],BarsPeriodType.Minute,1);
//					Print("AddDataSeries(\""+values[1]+"\",BarsPeriodType.Tick, 1);");
//					AddDataSeries(values[1],BarsPeriodType.Tick,1);
//				}
				AddDataSeries("NSC",BarsPeriodType.Minute, 1);
				AddDataSeries("NSC",BarsPeriodType.Tick, 1);
				AddDataSeries("COUP",BarsPeriodType.Minute, 1);
				AddDataSeries("COUP",BarsPeriodType.Tick, 1);
				AddDataSeries("CMI",BarsPeriodType.Minute, 1);
				AddDataSeries("CMI",BarsPeriodType.Tick, 1);
				AddDataSeries("IQV",BarsPeriodType.Minute, 1);
				AddDataSeries("IQV",BarsPeriodType.Tick, 1);
				AddDataSeries("MCK",BarsPeriodType.Minute, 1);
				AddDataSeries("MCK",BarsPeriodType.Tick, 1);
				AddDataSeries("GD",BarsPeriodType.Minute, 1);
				AddDataSeries("GD",BarsPeriodType.Tick, 1);
				AddDataSeries("TTWO",BarsPeriodType.Minute, 1);
				AddDataSeries("TTWO",BarsPeriodType.Tick, 1);
				AddDataSeries("ZBH",BarsPeriodType.Minute, 1);
				AddDataSeries("ZBH",BarsPeriodType.Tick, 1);
				AddDataSeries("EXPD",BarsPeriodType.Minute, 1);
				AddDataSeries("EXPD",BarsPeriodType.Tick, 1);
				AddDataSeries("NTRA",BarsPeriodType.Minute, 1);
				AddDataSeries("NTRA",BarsPeriodType.Tick, 1);
				AddDataSeries("ETR",BarsPeriodType.Minute, 1);
				AddDataSeries("ETR",BarsPeriodType.Tick, 1);
				AddDataSeries("PWR",BarsPeriodType.Minute, 1);
				AddDataSeries("PWR",BarsPeriodType.Tick, 1);
				AddDataSeries("LITE",BarsPeriodType.Minute, 1);
				AddDataSeries("LITE",BarsPeriodType.Tick, 1);
				AddDataSeries("BG",BarsPeriodType.Minute, 1);
				AddDataSeries("BG",BarsPeriodType.Tick, 1);
				AddDataSeries("BKI",BarsPeriodType.Minute, 1);
				AddDataSeries("BKI",BarsPeriodType.Tick, 1);
				AddDataSeries("AOS",BarsPeriodType.Minute, 1);
				AddDataSeries("AOS",BarsPeriodType.Tick, 1);
				AddDataSeries("SSNC",BarsPeriodType.Minute, 1);
				AddDataSeries("SSNC",BarsPeriodType.Tick, 1);
				AddDataSeries("TXT",BarsPeriodType.Minute, 1);
				AddDataSeries("TXT",BarsPeriodType.Tick, 1);
				AddDataSeries("THC",BarsPeriodType.Minute, 1);
				AddDataSeries("THC",BarsPeriodType.Tick, 1);
				AddDataSeries("BIGC",BarsPeriodType.Minute, 1);
				AddDataSeries("BIGC",BarsPeriodType.Tick, 1);
				AddDataSeries("LNC",BarsPeriodType.Minute, 1);
				AddDataSeries("LNC",BarsPeriodType.Tick, 1);
				AddDataSeries("EAT",BarsPeriodType.Minute, 1);
				AddDataSeries("EAT",BarsPeriodType.Tick, 1);
				AddDataSeries("BYD",BarsPeriodType.Minute, 1);
				AddDataSeries("BYD",BarsPeriodType.Tick, 1);
				AddDataSeries("OMF",BarsPeriodType.Minute, 1);
				AddDataSeries("OMF",BarsPeriodType.Tick, 1);
				AddDataSeries("SAIL",BarsPeriodType.Minute, 1);
				AddDataSeries("SAIL",BarsPeriodType.Tick, 1);
				AddDataSeries("MMP",BarsPeriodType.Minute, 1);
				AddDataSeries("MMP",BarsPeriodType.Tick, 1);
				Print(BarsArray.Length + " Bars Series Added");
			}
			else if (State == State.DataLoaded)
			{
				Print(BarsArray.Length + " Bars Series Added By State.DataLoaded");
			}
		}
		
		protected override void OnBarUpdate(){
			if (BarsInProgress == 0 || CurrentBars[0] < BarsRequiredToTrade) return;
			
			if (State == State.Historical && !IsInStrategyAnalyzer) return;
			
			int assetIndex = Convert.ToInt32(Math.Floor((BarsInProgress - 1) / 2.0));
			int entryBars = (assetIndex + 1) * 2;
			
			if (CurrentBars[BarsInProgress] < 1 || CurrentBars[entryBars] < 0) return;
			
			if (BarsInProgress % 2 == 1){
				//Logger("\n",BarsInProgress);
			//	Logger("BarsInProgress: "+BarsInProgress.ToString()+", "+entryBars.ToString()+", "+CurrentBars[BarsInProgress].ToString()+", "+CurrentBars[entryBars].ToString()+", "+BarsArray[BarsInProgress].BarsPeriod.BarsPeriodType.ToString()+", "+BarsArray[BarsInProgress].BarsPeriod.Value.ToString(),BarsInProgress);
				
				MACD macd = MACD(BarsArray[BarsInProgress],12,26,9);
				
				int openSignal = macd.Default[0] > macd.Avg[0] && Positions[BarsInProgress].MarketPosition != MarketPosition.Long ? 1 :
								 macd.Default[0] < macd.Avg[0] && Positions[BarsInProgress].MarketPosition != MarketPosition.Short ? -1 : 0;
				
				if (openSignal == 1){
					string signalName = "Long_"+assetIndex.ToString()+"_"+"0";
					EnterLong(entryBars,1,signalName);
				}
				if (openSignal == -1){
					string signalName = "Short_"+assetIndex.ToString()+"_"+"0";
					EnterShort(entryBars,1,signalName);
				}
			}
		}
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment){
			int assetIndexOrder = GetAssetIndexByInstrument(order.Instrument.FullName);
		//	Logger("OnOrderUpdate: "+order.ToString(),(assetIndexOrder + 1) * 2);
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time){
			int assetIndexExecution = GetAssetIndexByInstrument(execution.Instrument.FullName);
			//Logger("OnExecutionUpdate: "+execution.ToString(),(assetIndexExecution + 1) * 2);
			
			string name = execution.Name;
			
			if (execution.Order.OrderState == OrderState.Filled){
				if (name.Contains("Long") && !name.Contains("TP") && !name.Contains("SL")){
					int assetIndex = Convert.ToInt32(name.Split('_')[1]);
					int set = Convert.ToInt32(name.Split('_')[2]);
					
					double sl = BarsArray[execution.BarsInProgress].Instrument.MasterInstrument.RoundToTickSize(execution.Order.AverageFillPrice * (1 - SLPercentage / 100.0));
					if (sl >= GetCurrentBid(BarsInProgress)) sl = GetCurrentBid(BarsInProgress) - 1 * BarsArray[execution.BarsInProgress].Instrument.MasterInstrument.TickSize;
					ExitLongStopMarket(execution.BarsInProgress,true,execution.Order.Quantity,sl,name+" SL", name);

				}
				if (name.Contains("Short") && !name.Contains("TP") && !name.Contains("SL")){
					int assetIndex = Convert.ToInt32(name.Split('_')[1]);
					int set = Convert.ToInt32(name.Split('_')[2]);
					
					double sl = BarsArray[execution.BarsInProgress].Instrument.MasterInstrument.RoundToTickSize(execution.Order.AverageFillPrice * (1 + SLPercentage / 100.0));
					if (sl <= GetCurrentAsk(BarsInProgress)) sl = GetCurrentAsk(BarsInProgress) + 1 * BarsArray[execution.BarsInProgress].Instrument.MasterInstrument.TickSize;
					ExitShortStopMarket(execution.BarsInProgress,true,execution.Order.Quantity,sl,name+" SL", name);
				}
			}
		}
		
		protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition){
			int assetIndexPosition = GetAssetIndexByInstrument(position.Instrument.FullName);
		//	Logger("OnPositionUpdate: "+position.ToString(),(assetIndexPosition + 1) * 2);
		}
		
		int GetAssetIndexByInstrument(string instrumentName){
			int assetIndex = -1;
			for (int i = 1;i < BarsArray.Length;i++){
				if (BarsArray[i].Instrument.FullName == instrumentName){
					assetIndex = Convert.ToInt32(Math.Floor(i / 2.0));
					break;
				}
			}
			return assetIndex;
		}
		#endregion
		
		#region Logger
//		public void Logger(string msg,int barsIndex){
//			string text = this.ToString() + " Logger: "+BarsArray[barsIndex].Instrument.FullName+" "+Times[barsIndex][0]+" "+msg;
//			if (State != State.Historical) Log(text,LogLevel.Information);
//			Print(text);
//		}
		#endregion
		
		#region Properties	
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name="Config file path", Order=0, GroupName="Parameters")]
		public string ConfigFile
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0,double.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name="Stop Loss (%)", Order=1, GroupName="Parameters")]
        public double SLPercentage
        { get; set; }
		#endregion
	}
}
