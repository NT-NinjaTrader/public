#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class Submit5LimitOrdersCancelOnceSubmittedUnmanaged : Strategy
	{
		private Order entryOrder = null;
		private bool xOrderFilled;
		private bool xMoved;
		private int xCurrentBar;
		

		private Order entryOrder2 = null;
	private Order entryOrder3 = null;
		private bool xMoved2;
		private int xCurrentBar2;
	private bool xMoved3;
		private int xCurrentBar3;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "Submit5LimitOrdersCancelOnceSubmittedUnmanaged";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
					IsUnmanaged = true;
			}
			else if (State == State.Configure)
			{
			
			}
		}
		
		//This strategy will submit an entry order and if that limit order is not filled in
		//60 seconds.  Of course the time series this is applied to woudl have to be less than 60 seconds otherwise it would be 
		//on the next bar close...unless this was COBC==false.

		protected override void OnBarUpdate()
		{
			
			if(State == State.Historical) return;
			if(CurrentBar<10) return;
				
			var rand = new Random();


		var bytes = new byte[10];
	string sameOCO=	rand.Next().ToString();
				
				if(BuyentryOrder50 == null)
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 50 *TickSize,0,"", "BuyentryOrder50");

				if(BuyentryOrder60 == null)
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 60 *TickSize,0,"", "BuyentryOrder60");
			
				if( BuyentryOrder65  == null)
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 65 *TickSize,0,"", "BuyentryOrder65");
			
				if( BuyentryOrder70  == null)
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 70 *TickSize,0,"", "BuyentryOrder70");
			
				if(BuyentryOrder75 == null)
					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 75 *TickSize,0,"", "BuyentryOrder75");
				
	
			//	EnterShortLimit(0, true, 0, High[0]+30*TickSize, "myEntryOrder"); //Submits limit order 5 ticks from current low, assigns it to MyOrder Order Object.
				xMoved =true;
				xCurrentBar = CurrentBar;  //Sets value of current bar to build condition we used to modify the order if not filed.
			//	CanceledOrder=false;
			
			
		


        }
		
		
		private Order BuyentryOrder50 = null;
			private Order BuyentryOrder60 = null;
			private Order BuyentryOrder65 = null;
			private Order BuyentryOrder70 = null;
			private Order BuyentryOrder75 = null;

			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
	
			

			if ((order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				if(order.Name =="BuyentryOrder50")
				{
					BuyentryOrder50 = order;
						CancelOrder(BuyentryOrder50);
				}
				if(order.Name =="BuyentryOrder60")
				{
					BuyentryOrder60 = order;
					CancelOrder(BuyentryOrder60);
				}
				if(order.Name =="BuyentryOrder65")
				{
					BuyentryOrder65 = order;
						CancelOrder(BuyentryOrder65);
				}
				if(order.Name =="BuyentryOrder70")
				{
					BuyentryOrder70 = order;
						
						CancelOrder(BuyentryOrder70);
				}
				if(order.Name =="BuyentryOrder75")
				{
					BuyentryOrder75 = order;
						CancelOrder(BuyentryOrder75);
				}



			
					
					
						
				
					
					
			}
			

			
		
			}
		


	}
}
