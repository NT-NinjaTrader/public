#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class EnterAtTime : Strategy
	{
		
			
		public enum DayOfWeekToTrade
		{			
			//Only used by indicators
			All,
			Monday,
			Tuesday,
			Wednesday,
			Thursday,
			Friday,
		
		}
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "EnterAtTime";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
					Start_Hour = 7;
				Start_Minute = 30;
				DateOfTrade= DateTime.MaxValue;
				
				dayOfWeekToTrade =  DayOfWeekToTrade.All;
		
			}
			else if (State == State.Configure)
			{
										
//				StartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, Start_Hour, Start_Minute, 0);
			}
			
			else if (State == State.DataLoaded)
			{
				StartTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, Start_Hour, Start_Minute, 0);	
			}
		}
	TimeSpan TS; 
		DateTime DateOfTrade;
			DateTime StartTime;//
		bool madeTrade;
		protected override void OnBarUpdate()
		{
			
				
			if (TS == null)
			{
				TS = Time[0] - Time[5];
			}

			if (madeTrade == true)
			{
				
				
				if (Time[0].Date > DateOfTrade.Date)
					madeTrade = false;
				
			}
			if (madeTrade == false)
			{

	
						
				if (Time[0].TimeOfDay >= StartTime.TimeOfDay && Time[0].TimeOfDay <= StartTime.TimeOfDay.Add(TS))
				{
					DateOfTrade = Time[0];
				
					madeTrade = true;


					EnterLong(1, "GoLong_" + Name.ToString());

				}

			
			}
	}
			//[NinjaScriptProperty]
		[Display(Name = "DayOfWeekToTrade", Order = 24, Description = "S", GroupName = "Stop1")]
		public DayOfWeekToTrade dayOfWeekToTrade
		{ get; set; }


		[NinjaScriptProperty]
		[Display(Name = "Start_Hour", Description = "Start_Hour", Order = 0, GroupName = " 0")]
		public int Start_Hour
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Start_Minute", Description = "Start_Minute", Order = 1, GroupName = " 0")]
		public int Start_Minute
		{ get; set; }
}

}