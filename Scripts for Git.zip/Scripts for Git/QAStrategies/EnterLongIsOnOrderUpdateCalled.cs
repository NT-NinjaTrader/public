#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class EnterLongIsOnOrderUpdateCalled : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "EnterLongIsOnOrderUpdateCalled";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				
////				SetProfitTarget(CalculationMode.Ticks, 500);
////				SetStopLoss(CalculationMode.Ticks, 500);
			}
		}

		protected override void OnBarUpdate()
		{
			if(State != State.Realtime) return;
		//DateTime EnterTime=new DateTime(2021,12,23,09,1,1);
			//	DateTime endTime=new DateTime(2021,12,23,09,3,1);
			
		//	if(Time[0]> EnterTime && 		Time[0]<endTime)
			if(Position.MarketPosition == MarketPosition.Flat)
			{
				bool isAtmStrategyCreated;
				string atmStrategyId = GetAtmStrategyUniqueId();
				string	orderId = GetAtmStrategyUniqueId();
					AtmStrategyCreate(OrderAction.Buy, OrderType.Limit, GetCurrentBid() - 2 * TickSize, 0, TimeInForce.Gtc, orderId, "ATMForNS", atmStrategyId, (atmCallbackErrorCode, atmCallBackId) =>
					{
						//check that the atm strategy create did not result in error, and that the requested atm strategy matches the id in callback
						if (atmCallbackErrorCode == ErrorCode.NoError && atmCallBackId == atmStrategyId)
							isAtmStrategyCreated = true;
					});	
			}
				
		
		}
		
				Order targetOrder;
		
		Order stopOrder;
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{

Print("OnOrderUPdate"+order.Name.ToString());
				
			if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
						
				}
			}

			//TARGET AND STOP WOULD BE ASSIGNED ORDER OBJECTS IN STATE.DATA LOADED WHEN THIS ATM WAS SUBMITTED OUTSIDE STRATEGY

		//	if (OpenATMPositionInsteadOfManageOpenATM == true)
			{

				if (order.Name == "Target1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
				{

					if (order.OrderState == OrderState.Filled || (order.OrderState == OrderState.Cancelled))
						targetOrder = null;
					else
						targetOrder = order;



				}
				if (order.Name == "Stop1")  //Checks if the order name is Stop1, and if so, assigns it to an order object.
				{

					if (order.OrderState == OrderState.Filled || (order.OrderState == OrderState.Cancelled))
						stopOrder = null;
					else
						stopOrder = order;

				}

			}





			if (order.Name == "Stop1")						
			{

				
				if (order.OrderState == OrderState.Working)
				{
					if(order.Quantity == 3)
					{				
					//	stopQuantityChanged=true;					
					}
				}
			
			}			
			if (order.Name == "Target1")						
			{
				if (order.OrderState == OrderState.Working)
					{
//						if(order.LimitPrice !=originalTargetPrice)
						{				
							//TargetPriceChanged=true;					
						}
					}
			
			}		
			
	
		
		
		}
	}
}
