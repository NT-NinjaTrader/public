#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class SubmitOCOLimitsAndCancelAsTheyreAccepted : Strategy
	{
	
		
		/*

		Apex Rithmic issue sending too many change/cancel requests
		
		https://ninjatrader.atlassian.net/browse/NTEIGHT-15318
		
		
		
		*/
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SubmitOCOLimitsAndCancelAsTheyreAccepted";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
					
				IsUnmanaged = true;
			}
			else if (State == State.Configure)
			{
			
			}
		}
		
		//This strategy will submit an entry order and if that limit order is not filled in
		//60 seconds.  Of course the time series this is applied to woudl have to be less than 60 seconds otherwise it would be 
		//on the next bar close...unless this was COBC==false.

		protected override void OnBarUpdate()
		{
			
			if(State == State.Historical) return;
			if(CurrentBar<10) return;
				
			var rand = new Random();
				
			var bytes = new byte[10];		
			string sameOCO=	rand.Next().ToString();
			
			if(BuyentryOrder50 == null)					
				SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 50 *TickSize,0,"AlanTest"+sameOCO, "BuyentryOrder50");
				
			if(BuyentryOrder60 == null)					
				SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Limit,1, GetCurrentAsk(0) - 60 *TickSize,0,"AlanTest"+sameOCO, "BuyentryOrder60");
				

        }
		
		
		private Order BuyentryOrder50 = null;
			private Order BuyentryOrder60 = null;

			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{			

			if ((order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted  || order.OrderState == OrderState.TriggerPending))
			{
				if(order.Name =="BuyentryOrder50")
				{
					BuyentryOrder50 = order;
						CancelOrder(BuyentryOrder50);
				}
				if(order.Name =="BuyentryOrder60")
				{
					BuyentryOrder60 = order;
					CancelOrder(BuyentryOrder60);
				}



			
					
					
						
				
					
					
			}
			

			
		
			}
		


	}
}
