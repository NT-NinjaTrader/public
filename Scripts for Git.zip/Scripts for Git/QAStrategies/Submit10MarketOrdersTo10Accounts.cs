#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class Submit10MarketOrdersTo10Accounts : Strategy
	{
		
		//Right click on Accounts Tab -> New Account, create 1 to 10 SimAccount10
		
		
		
		Instrument xInstrument;
		Account myAccount;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "Submit10MarketOrdersTo10Accounts";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
			}
			else if( State== State.DataLoaded)
			{
					  
//		foreach (Account sampleAccount in Account.All)
			  {
				  
				  
				  		 
				  string stringInstrument = "ES 12-22";
				  xInstrument = Instrument.GetInstrument(stringInstrument);
				  	  
				
				  Account myAccount_1 = Account.All.FirstOrDefault(a => a.Name == "SimAccount1");		 	
				  Order xOrder_1 = myAccount_1.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_1.Submit(new[] { xOrder_1}); 
				  
				  
				    
				  Account myAccount_2 = Account.All.FirstOrDefault(a => a.Name == "SimAccount1");		 	
				  Order xOrder_2 = myAccount_2.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_2.Submit(new[] { xOrder_2}); 
				  
				  
				   
				  Account myAccount_3 = Account.All.FirstOrDefault(a => a.Name == "SimAccount2");		 	
				  Order xOrder_3 = myAccount_3.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_3.Submit(new[] { xOrder_3}); 
				  
				  
				   
				  Account myAccount_4 = Account.All.FirstOrDefault(a => a.Name == "SimAccount4");		 	
				  Order xOrder_4 = myAccount_4.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_4.Submit(new[] { xOrder_4}); 
				  
				  
				   
				  Account myAccount_5 = Account.All.FirstOrDefault(a => a.Name == "SimAccount5");		 	
				  Order xOrder_5 = myAccount_5.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_5.Submit(new[] { xOrder_5}); 
				  
				  
 
				  Account myAccount_6 = Account.All.FirstOrDefault(a => a.Name == "SimAccount6");		 	
				  Order xOrder_6 = myAccount_6.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_6.Submit(new[] { xOrder_6}); 
				  
				  
				  Account myAccount_7 = Account.All.FirstOrDefault(a => a.Name == "SimAccount7");		 	
				  Order xOrder_7 = myAccount_6.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_7.Submit(new[] { xOrder_7}); 
				  
				   
				  Account myAccount_8 = Account.All.FirstOrDefault(a => a.Name == "SimAccount8");		 	
				  Order xOrder_8 = myAccount_8.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_8.Submit(new[] { xOrder_8}); 
				  
				   
				  Account myAccount_9 = Account.All.FirstOrDefault(a => a.Name == "SimAccount9");		 	
				  Order xOrder_9 = myAccount_9.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_9.Submit(new[] { xOrder_9}); 
				  
				   
				  Account myAccount_10 = Account.All.FirstOrDefault(a => a.Name == "SimAccount10");		 	
				  Order xOrder_10 = myAccount_10.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
				  myAccount_10.Submit(new[] { xOrder_10}); 
				  
				  	 
//				  myAccount = Account.All.FirstOrDefault(a => a.Name == "SimAccount2");
////				  lock (Account.All)
//				  {
 
					  
//					  for(int i=0; i<20; i++)
//					  {
			            	 
//						  myAccount = Account.All.FirstOrDefault(a => a.Name == "Sim101");
							  
							
						 
							  
//						  xInstrument = Instrument.GetInstrument(stringInstrument);
//						Order xOrder = myAccount.CreateOrder(xInstrument, OrderAction.Buy, OrderType.Market, TimeInForce.Day, 1, 0, 0, "", "", null);	
			 			
//						myAccount.Submit(new[] { xOrder}); 
//					  }
//				  }
				  
			
				  
				  
			  }
			  
			  
				}
			
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
		}
	}
}
