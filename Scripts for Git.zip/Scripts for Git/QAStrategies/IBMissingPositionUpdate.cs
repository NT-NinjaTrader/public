#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
    public class IBMissingPositionUpdate : Strategy
    {

        private bool doOnce = true;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "IBMissingPositionUpdate";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                // Disable this property for performance gains in Strategy Analyzer optimizations
                // See the Help Guide for additional information
                IsInstantiatedOnEachOptimizationIteration = true;
                IsUnmanaged = true;
            }
            else if (State == State.Configure)
            {
                orderCounter = 0;
                AddDataSeries("ES 09-22");
                AddDataSeries("NQ 09-22");
                AddDataSeries("RTY 09-22");

                waitingPositionUpdate_0 = false;

                waitingPositionUpdate_1 = false;
                Golong_BIP1 = false;

                waitingPositionUpdate_2 = false;


            }
        }

        int orderCounter;
        string orderName0;
        string orderName1;
        string orderName2;
        private void SubmitTrade(int BIP)
        {
			
          //  string oco = Instruments[BIP].FullName + DateTime.Now.ToString();

			//Submit bid/offer right on bid/ask, to fill soon.
            SubmitOrderUnmanaged(BIP, OrderAction.Buy, OrderType.Limit, 1, 0, GetCurrentAsk(BIP) - 3 * TickSize, "", "Buy" + Instruments[BIP].FullName);
            SubmitOrderUnmanaged(BIP, OrderAction.Sell, OrderType.Limit, 1, 0, GetCurrentBid(BIP) + 3 * TickSize, "", "Sell" + Instruments[BIP].FullName);
			
			//submit market orders to buy/sell.
			SubmitOrderUnmanaged(BIP, OrderAction.Buy, OrderType.Market,1, GetCurrentAsk(BIP) +5 * TickSize,0, "", "Buy" + Instruments[BIP].FullName);
            SubmitOrderUnmanaged(BIP, OrderAction.Sell, OrderType.Market,1, GetCurrentBid(BIP) - 5 * TickSize,0, "", "Sell" + Instruments[BIP].FullName);

            //			SubmitOrderUnmanaged(BIP, OrderAction.Buy, OrderType.StopMarket, 10000, 0, Highs[BIP][0] + 50 * 0.0001, oco, "Buy"+Instruments[BIP].FullName);
            //			SubmitOrderUnmanaged(BIP, OrderAction.Sell, OrderType.StopMarket, 10000, 0, Lows[BIP][0] - 50 * 0.0001, oco, "Sell"+Instruments[BIP].FullName);
        }
        bool waitingPositionUpdate_0;

        bool waitingPositionUpdate_1;


        bool waitingPositionUpdate_2;

        int barSubmission = 0;

        bool Golong_BIP1;
        protected override void OnBarUpdate()
        {

            //Format before submission!!!!!!!!!!!  VS, 
            if (State != State.Realtime)
                return;

            orderCounter++;

            if (CurrentBar > barSubmission)
            {

                barSubmission = CurrentBar + 2;

                if (waitingPositionUpdate_0 == false)
                {

                    waitingPositionUpdate_0 = true;


                    waitingForSubmissionBIP0 = true;  // check its been submitted.

                    if (Golong_BIP1)
                    {
                        Golong_BIP1 = false;
                        orderName0 = "Buy" + Instruments[0].FullName + orderCounter;
                        SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0, 0, "", orderName0);


                    }
                    else
                    {
                        Golong_BIP1 = true;
                        orderName0 = "Sell" + Instruments[0].FullName + orderCounter;
                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, 1, 0, 0, "", orderName0);
                    }
                }
                else
                {

                    if (waitingForFill_0)  //Means never got a position update.
					{
                        Print("Missed Fill for BIP0");
						
					}

                    if (waitingForSubmissionBIP0)
                    {
                        Print("Missed submission of");  //Meaning OnOrderUpdate was missed for the submission.
							
						Task.Run(() => MessageBox.Show("Hit Error,", "Warning", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.ServiceNotification));


                    }

                    Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!!");
                }

                //				if(waitingPositionUpdate_1 == false)
                //				{

                //					orderName1 ="Buy"+Instruments[1].FullName + orderCounter;
                //					waitingPositionUpdate_1 = true;				
                //					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0,0, "", orderName1);			
                //				}
                //				else
                //				{
                //					Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!!");
                //				}

                //				if(waitingPositionUpdate_2 == false)
                //				{

                //					orderName2 ="Buy"+Instruments[2].FullName + orderCounter;
                //					waitingPositionUpdate_2 = true;				
                //					SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, 1, 0,0, "", orderName2);		

                //				}
                //				else
                //				{
                //					Print("ERRORRRR HIT!!!!!!!!!!!!!!!!!!!!");
                //				}
            }


			//Think its realt4ed to get fills right about same time.
            if (doOnce)
            {
                doOnce = false;
                for (int i = 1; i < 4; i++)
                    SubmitTrade(i);
            }
        }


        protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, int quantity, Cbi.MarketPosition marketPosition)
        {


            if (position.Instrument.FullName == Instruments[0].FullName)
            {
                waitingPositionUpdate_0 = false;
            }

            if (position.Instrument.FullName == Instruments[1].FullName)

            {
                waitingPositionUpdate_1 = false;
            }

            if (position.Instrument.FullName == Instruments[2].FullName)
            {
                waitingPositionUpdate_2 = false;

            }



        }
        bool waitingForSubmissionBIP0;
        bool waitingForFill_0;

        bool waitingForFill_1;
        bool waitingForFill_2;
        protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
        {

            if (order.Name == orderName0 && (order.OrderState == OrderState.Working || order.OrderState == OrderState.Submitted || order.OrderState == OrderState.Accepted || order.OrderState == OrderState.TriggerPending))
            {
                waitingForFill_0 = true;
                waitingForSubmissionBIP0 = false;
            }
            if (order.Name == orderName0 && (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled))
            {

                waitingForFill_0 = false;

            }
        }

    }
}
