#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.QA
{
	public class QAOrderTests : Strategy
	{
	private Order	stopExit = null;
		   
		private Order enterLimitOrder        = null;
		  
		private Order enterMarketOrder     = null;
		public static void PrintAndLog(string s)
        {
            NinjaTrader.Code.Output.Process(s.ToString(), PrintTo.OutputTab1);
            NinjaTrader.NinjaScript.NinjaScript.Log("__" + s.ToString(), NinjaTrader.Cbi.LogLevel.Information);
        }
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "QAOrderTests";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				currentBar=0;
				DoOnce=false;
				
			}
		}
		int StartPart2=5;
		int TestsPassed=0;
		int TestsFailed=0;
		bool waitingOnPositionUpdate;
		
		int currentBar;
		
		bool DoOnce=false;
	
		protected override void OnBarUpdate()
		{
			if(State==State.Realtime)
			{
				
				
				
				
				
				
				
				
				
				
				if(DoOnce)
				{
						DoOnce=false;
					Print2("--------------------------");
				
				}
				currentBar++;
				
				if(currentBar==2)
				{	
		
					Print2("EnterLong called in OBU");
				//	waitingOnPositionUpdate=true;
					EnterLong("EnterLong");	
				
		
				}
						
				if(currentBar==4)
				{	
		
					Print2("EnterLong called in OBU");
				//	waitingOnPositionUpdate=true;
					EnterShort("EnterShort");	
				
		
				}
				
				if(currentBar==StartPart2 + 2)
				{	
						Print2("ExitShort called in OBU");
					ExitShort("ExitShort", "EnterShort");
				}
				
				if(currentBar == StartPart2 +4)
				{	
						Print2("EnterLongLimit called in OBU");
					EnterLongLimit(Close[0]-10*TickSize, "EnterLongLimit");
				}
					
				
				if(currentBar == StartPart2 +6)
				{				
				
						Print2("ChangeOrder called in OBU");
					
						ChangeOrder(stopExit, 1, 0, Close[0]-20*TickSize);
								
				}
					
				if(currentBar == StartPart2 +8)
				{				
				
						Print2("CancelOrder called in OBU");
						CancelOrder(stopExit);
								
				}
				
			
				
			}
		}

		protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
				Print2("OnExecutionUpdate");
		}

		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, 
			int quantity, int filled, double averageFillPrice, 
			Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			
	if (error != ErrorCode.NoError)
			{
				if (error == ErrorCode.UnableToChangeOrder)  ///AKA Rejected stop orders for being through the market.
				{
					
				}
			}
						
			Print2("OnOrderUpdate"+order.Name+order.OrderState.ToString() +"__"+comment.ToString());
			if (order.Name == "EnterLongLimit")
                enterLimitOrder = order;
			
            else if (order.Name == "SellStop")
                stopExit      = order;
			    else if (order.Name == "enterMarketOrder")
                enterMarketOrder      = order;
			
			
			
		
		}

		protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, 
			int quantity, Cbi.MarketPosition marketPosition)
		{
			Print2("OnPositionUpdate");
			
			if(waitingOnPositionUpdate)
			{
		
				waitingOnPositionUpdate=false;
				TestsPassed++;
				
			}
			
		}
		  
		public static void Print2(string s)
        {
			
		
            //	NinjaTrader.Code.Output.Process((s.ToString())


            NinjaTrader.Code.Output.Process(s.ToString(), PrintTo.OutputTab2);
            //	NinjaTrader.NinjaScript.NinjaScript.Log(DateTime.Now.ToString()+"__"+s.ToString(), NinjaTrader.Cbi.LogLevel.Error);
        }

		
	}
}
